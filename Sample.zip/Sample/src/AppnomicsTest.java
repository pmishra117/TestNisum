	import java.util.*;
	import java.io.*;

		public class AppnomicsTest {  
 		static Map<String,String> productData = new HashMap<String,String>();

	     

	    public static void main (String[] args) {
	         try {
	            Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
	            while(in.hasNextLine()) {
	                String line = in.nextLine().trim();
	                System.out.println(line);
	                String productName=line.substring(0, line.indexOf(","));
	                int productVersion = Integer.parseInt(line.substring(line.lastIndexOf(',')+2));
	                
	                if (!line.isEmpty())
	                   {
	                	if(!productData.containsKey(productName)) {
	                		productData.put(productName,line.substring(line.lastIndexOf(',')+1));
	                    }
	                   
	                	else {
	                	 String storedVersion = productData.get(productName).substring(1);
	                	 System.out.println("version "+storedVersion);
	                	 int versionStored =Integer.parseInt(storedVersion);
	                	 if(versionStored < productVersion) 
	                		 productData.put(productName,line.substring(line.lastIndexOf(',')+1));
	                	 
	                		 
	                	}
	            }
	            
	           
	        } 
	       processData();
	       }catch (IOException e) {
	            System.err.print("IO error in input.txt or output.txt");
	        }
	    }
	    
	    
	  static void processData() {
		Set<String> s =  productData.keySet();
		Iterator <String> itr  =s.iterator();
		System.out.println("Updated Product Name ");
		
		while(itr.hasNext()) {
			String productName =itr.next();
			System.out.println(  productName   +"    ,  " + productData.get(productName));
		}
	       
	    }

		}
