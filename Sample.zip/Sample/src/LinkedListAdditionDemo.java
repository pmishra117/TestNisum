
public class LinkedListAdditionDemo {
public static void main(String[] args) {
	System.out.println("Hii");
}
}
