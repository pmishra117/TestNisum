import java.util.*;

class UniqueImages {
	 static Map<String,Integer> set = new HashMap<String,Integer>() ;
	    
    public static class Image {
        private String filename;
        private int width;
        private int height;
        public Image(String filename, int width, int height) {
            this.filename = filename;
            this.width = width;
            this.height = height;
        }
        /**
         * Two Images are considered equal if they have
         * the same filename (without the extension), and the
         * same number of pixels.
         * Thus, flag.jpg with width=60 height=40 is
         * equal to flag.gif with width=40 and height=60
         */
        public boolean equals(Object other) {
            Image o = (Image)other;
            if (filename == null || o.filename == null)
                return false;
            String[] components = filename.split("\\.");
            String[] ocomponents = o.filename.split("\\.");
            return components[0].equals(ocomponents[0]) && 
                width * height == o.width * o.height;
        }
        public String toString() {
            return "Image: filename=" + filename + " Size=" + width*height;
        }
    }

    public static void printImages(Set<Image> images) {
    
    	System.out.println(images.size());
        for(Image image: images) {
        	
       
        }
    }

    public static void main(String[] args) {
    	Integer a = null;
    	int b = a;
    	System.out.println(b);
    	    
        Image[] images = {new Image("flag.jpg", 40, 60),
                          new Image("flag.gif", 40, 60),
                          new Image("smile.gif", 100, 200),
                          new Image("smile.gif", 50, 400),
                          new Image("other.jpg", 40, 60),
                          new Image("lenna.jpg", 512, 512),
                          new Image("Lenna.jpg", 512, 512)};
 for(Image image: images) {
	 String fileName=image.filename.substring(0,image.filename.lastIndexOf('.'));
	 int width=image.width;
	 int ht=image.height;
	 int size=width*ht;
	        	if(!set.containsKey(fileName)) {
        		set.put(fileName,size);
        	}
         if(set.get(fileName)==size) {
        	//	System.out.println("Not Unique....");
        	}
         
        		System.out.println("Unique...."+fileName+"  "+size);
        
        }
        // UniqueImages.printImages(set);
    }
}