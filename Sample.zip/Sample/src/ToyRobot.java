package toyrobotsimulator.dengpeng.de;

public class ToyRobot {
	enum Facing{
		NORTH, SOUTH, WEST, EAST
	}   
	
	private int X; //Robot's X coordination
	private int Y; //Robot's X coordination
	private Facing direction; //Robot's facing
	private Board board;

	//return the current X coordination of robot
	public int getX() {
		return X;
	}

	//return the current Y coordination of robot
	public int getY() {
		return Y;
	}

	//return the facing direction of robot
	public Facing getDirection() {
		return direction;
	}

	//return the board that robot is deployed
	public Board getBoard() {
		return board;
	}
	
	public ToyRobot(int X, int Y, Facing direction){
		this.X = X;
		this.Y = Y;
		this.direction = direction;
	}
	
	public ToyRobot(){
	}
	
	//robot reports current location
	public String report(){
		return String.valueOf(this.X) + "," + String.valueOf(this.Y) + "," + this.direction;
	}
	
	//robot moves 1 step ahead
	public void move() {
			switch (direction) {
			case NORTH:
				Y++;
				//if robot move over the edge, it stays at edge
				if (!board.isRobotYPositionValid(Y))
					Y = board.getHeight();
				break;

			case WEST:
				X--;
				if (!board.isRobotXPositionValid(X))
					X = 0;
				break;

			case SOUTH:
				Y--;
				if (!board.isRobotYPositionValid(Y))
					Y = 0;
				break;

			case EAST:
				X++;
				if (!board.isRobotXPositionValid(X))
					X = board.getWidth();
				break;
			}
		}

	//robot turns left from current facing
	public void turnLeft() {
			switch (direction) {
			case NORTH:
				direction = Facing.WEST;
				break;

			case WEST:
				direction = Facing.SOUTH;
				break;

			case SOUTH:
				direction = Facing.EAST;
				break;

			case EAST:
				direction = Facing.NORTH;
				break;
			}
		}

	//robot turns right from current facing
	public void turnRight() {
			switch (direction) {
			case NORTH:
				direction = Facing.EAST;
				break;

			case EAST:
				direction = Facing.SOUTH;
				break;

			case SOUTH:
				direction = Facing.WEST;
				break;

			case WEST:
				direction = Facing.NORTH;
				break;
			}
		}

	//deploy robot to board
	public void deployTo(Board battleField) {
		this.board = battleField;
	}
	
}
