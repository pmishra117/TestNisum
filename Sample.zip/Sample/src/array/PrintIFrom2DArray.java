package array;

public class PrintIFrom2DArray {
public static void main(String[] args) {
	int[][] arr= new int[3][3];
	_init(arr);
	
	for(int i=0;i<4;i++) {
		for(int j=0;j<4;j++) {
			System.out.println(arr[i][j]);
		}
	}
}


	static void _init(int [][]arr){
		int c=0;
	 
		for(int i=0;i<=4;i++) {
			for(int j=0;j<3;j++) {
				arr[i][j]=++c;
			}
	}
	
}
}