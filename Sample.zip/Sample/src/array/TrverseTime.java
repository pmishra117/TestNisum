package geeks.array;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class TrverseTime {
public static void main(String[] args){
	
	test();
}

public static void test(){
	ArrayList<String> al =new ArrayList<String>();
	
	LinkedList<String> ll=new LinkedList<String>();
	
	for(int i=0;i<15000;i++)
	{
		al.add("a");
		ll.add("a");
	}
	System.out.print("array   "+System.currentTimeMillis());
	
	Iterator<String> itr=al.iterator();
	while(itr.hasNext()){
		String oo=itr.next();
	}
	System.out.print("array  end "+System.currentTimeMillis());

	
	Iterator<String> itrL=ll.iterator();

System.out.println("Linked   "+System.currentTimeMillis());
while(itrL.hasNext()){
	String o=itrL.next();
}
System.out.print("linked end   "+System.currentTimeMillis());
}

   

}
