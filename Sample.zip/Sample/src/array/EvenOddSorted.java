package geeks.array;

import java.util.ArrayList;

public class EvenOddSorted {
public static void main(String[] args) {
	    	    int ar[]={1,2,4,3,6,5}; //given array
	    		  
	    	System.out.print("array : ");
	           for (int j = 0; j < ar.length; j++)
	                  System.out.print(ar[j] +" "); // display it
	           
	        // int a[]=  printEvenOddSorted(ar);    
	     new EvenOddSorted(). A();
	    }
public void A(){
	 ArrayList<EvenOddSorted> al=new ArrayList<EvenOddSorted>();
	 
	 for(int i=0;i<10000;i++){
		 al.add(new EvenOddSorted());
		 System.out.println("Pradeep");
			
		 
	 }
	//B();
	
	
}

public void B(){
	 System.out.println("B");
	A();
	
}
 public static int[] printEvenOddSorted(int []a) {
	 int len=a.length;
	 int [] temp=new int[len];
	 int i=0,j=len-1;
	 while(i != j){
		 if(a[i] !=0  && a[j]!= 0){
			 if(a[i]%2==0){
				 //even=a[i];
				 temp[i]=a[i];
				 i++;
				 
			 }
			 else 
				 temp[j]=a[j];
			 j--;
				
		 }
		 
	 }
	 
	    
 return temp;}
}
