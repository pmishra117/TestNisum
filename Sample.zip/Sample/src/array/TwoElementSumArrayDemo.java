package geeks.array;

import java.util.HashMap;

public class TwoElementSumArrayDemo {
public static void main(String[] args) {
	int []a={1,7,6,8};
    //  sumElement(a,13);
      sumElementUsingHashtable(a,13);
	//checkDuplicateInArray(a);
}
public static void sumElement(int []a,int NUMBER) {
	int i=0;
	int j=a.length-1;
	int n=(j+0)/2;
	while(j>n&&i<j) {
		if(a[i]+a[j]==NUMBER){
			System.out.println("Found..."+a[i]+"   "+a[j]);
			return;
		}
		else if((a[i]+a[j])<NUMBER) {
			i+=1;
		}
		else {j-=1;}
			//n-=1;
		}
		return;
	}

public static void sumElementUsingHashtable(int[]A,int SUM)
{
	int N=A.length;
	HashMap<Integer,String> map=new HashMap<Integer,String> ();
	for(int i=0;i<N;i++)  {   	 map.put(A[i], "ABC");      	 }
	for(int i=0;i<N;i++)  {	int J=SUM-A[i];
		if(map.containsKey(J)){
			System.out.println("SUM exits using HashTable "+ J+"  "+A[i]);
			}
		                 else {
		                	 System.out.println("There is no Such Entry");
		                	 }
					}
	}

public static void checkDuplicateInArray(int []A) {
	int N=A.length;
	for(int i=0;i<N;i++)  {
		if(A[Math.abs(A[i])]<0){
			System.out.println("Duplicate Exits..."+A[i]);
			return;
		}
	}
	
}
}
