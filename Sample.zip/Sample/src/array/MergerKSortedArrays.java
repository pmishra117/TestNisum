package array;

import java.util.Arrays;
import java.util.PriorityQueue;


class ArrayContainer implements Comparable<ArrayContainer> {
	int[] arr;
	int index;
 
	public ArrayContainer(int[] arr, int index) {
		this.arr = arr;
		this.index = index;
	}
 
	public int compareTo(ArrayContainer o) {
		return this.arr[this.index] - o.arr[o.index];
	}
}

public class MergerKSortedArrays {
	public static void main(String[] args) {
		int[] arr1 = { 1,4,7 };
		int[] arr2 = { 2,5,8 };
		//int[] arr3 = { 3,6,9 };
		//int[] arr4 = { 12, 13, 14, 15 };
		
   int i=5;
   i=i++ + ++i -i-- - --i;
   System.out.println("i..............."+i);
		int[] result = mergeKSortedArray(new int[][] { arr1, arr2  });
		System.out.println(Arrays.toString(result));
	
	}
	public static int[] mergeKSortedArray(int[][] arr) {
			//PriorityQueue is heap in Java 
			PriorityQueue<ArrayContainer> queue = new PriorityQueue<ArrayContainer>();
			int total=0;
	 
			//add arrays to heap
			for (int i = 0; i < arr.length; i++) {
				queue.add(new ArrayContainer(arr[i], 0));
				total = total + arr[i].length;
			}
	 
			int m=0;
			int result[] = new int[total];
	 
			//while heap is not empty
			while(!queue.isEmpty()){
				System.out.println("queue size...."+queue.size());
				ArrayContainer ac = queue.poll();
			    result[m++]=ac.arr[ac.index];
	 
				if(ac.index < ac.arr.length-1){
					queue.add(new ArrayContainer(ac.arr, ac.index+1));
				}
			}
	 
			return result;
		}
	 
	
	}

