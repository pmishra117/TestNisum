package geeks.array;

import java.util.Arrays;

public class SegrigatingevenOdd {
public static void main(String[] args) {
	int arr[]={1,4,2,5};
	segregateEvenOdd(arr);
}

static void segregateEvenOdd(int arr[]) {
	
	
    /* Initialize left and right indexes */
    Arrays.sort(arr);
	int i=0;
	int j=arr.length-1;
	int temp[]=new int[arr.length];
	
	while(i<=j){
		if(arr[j]%2==0) {
			temp[j]=arr[j];
			j--;
		}
			else {
				temp[i]=arr[j];
				i++;
				j--;
			}
		}
	
	
    for(int ii=0;ii<temp.length;ii++){
    	System.out.println(temp[ii]);
    }
    }
}

