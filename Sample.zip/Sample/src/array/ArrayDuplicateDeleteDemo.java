package geeks.array;

public class ArrayDuplicateDeleteDemo {
public static void main(String[] args) {
	int[] arr = new int[]{1,8,1,8};
	int []op =removeDuplicates(arr);
	for(int i=0;i<op.length;i++){
		System.out.println(op[i]);
	}
}

public static int[] removeDuplicates(int[] arr) {
    boolean[] set = new boolean[1001]; //values must default to false
    int totalItems = 0;

    for (int i = 0; i < arr.length; ++i) {
        if (!set[arr[i]]) {
            set[arr[i]] = true;
            totalItems++;
        }
    }

    int[] ret = new int[totalItems];
    int c = 0;
    for (int i = 0; i < set.length; ++i) {
        if (set[i]) {
            ret[c++] = i;
        }
    }
    return ret;
}
}
