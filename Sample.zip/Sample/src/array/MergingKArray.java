package array;

public class MergingKArray {
	
	public static void main(String[] args) {
		
	}
	
 
	public static void merge(int array[], int left, int mid, int right)
	{
	    int i;
	    int l=left; //If you are passing left, then it should be used here !!
	    int r=mid+1;
	    int arr_sorted[10];

	    for(i=0;(l<=mid)&&(r<=right);i++){ 
	//Your condition for this loop unnecessarily complicates the rest of the code. This is a better way to go about it
	//The loop body is fine
	       if(array[l]<array[r]){
	                arr_sorted[i]=array[l];
	                l++;
	            }
	            else {
	                arr_sorted[i]=array[r];
	                r++;
	            }
	        }

	//Now, checking for remaining elements and adding them to the result
	//The conditions are simple because of the test condition we used in the previous for loop
	        if(l>mid){
	           for(;r<=right;r++,i++) arr_sorted[i]=array[r];
	        }
	        if(r>right){
	            for(;l<=mid;l++,i++)  arr_sorted[i]=array[l];
	        }
	    }
	    for(i=0;i<=right;i++){
	        array[i]=arr_sorted[i];
	    }
	}
}
