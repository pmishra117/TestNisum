package geeks.array;

public class MissingElementInUnsortedArray {
	    static int ar[]={33,27,5,8,44,24,1,5,6,7,4,6,4,6,5,9}; //given array
	    
	    public static void main(String[] args) {
	           System.out.print("given array : ");
	           for (int j = 0; j < ar.length; j++)
	                  System.out.print(ar[j] +" "); // display it
	           
	           displayMissing();       
	    }
	    
	    /*
	     * Method for displaying missing number in given range.
	     */
	    static public void displayMissing(){
	           
	           int tempAr[]=new int[50];
	           for (int j = 0; j < ar.length; j++){  /*make indexes of tempAr corresponding to value found in ar equal to 1.
	                                                                               i.e if i[0]=22, than make tempAr[22]=1;
	                                                                                if i[1]=25, than make tempAr[25]=1; */
	                  tempAr[ar[j]]=1;
	           }
	           
	           System.out.print("\nNumbers missing between 1 to 100 in array :  ");
	           
	           for(int i=1;i<tempAr.length;i++){
	                  if(tempAr[i]==0)
	                        System.out.print(i+" ");
	           }
	           System.out.println(tempAr.length);
	    }
	    
	    
	}
	 
