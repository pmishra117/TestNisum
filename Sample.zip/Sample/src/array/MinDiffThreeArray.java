package geeks.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinDiffThreeArray {
	
	public static void main(String[] args){
		  int arr[] = new int[]{1, 2, 3, 4, 5, 6, 7};
	findMinimumDifference(arr);
	}
	
	void findClosest(int A[], int B[], int C[], int p, int q, int r)
	{
	 
	    int diff = 1;  // Initialize min diff
	 
	    // Initialize result
	    int res_i =0, res_j = 0, res_k = 0;
	 
	    // Traverse arrays
	    int i=0,j=0,k=0;
	    while (i < p && j < q && k < r)
	    {
	        // Find minimum and maximum of current three elements
	        int minimum = min(A[i], min(B[j], C[k]));
	        int maximum = max(A[i], max(B[j], C[k]));
	 
	        // Update result if current diff is less than the min
	        // diff so far
	        if (maximum-minimum < diff)
	        {
	             res_i = i, res_j = j, res_k = k;
	             diff = maximum - minimum;
	        }
	 
	        // We can't get less than 0 as values are absolute
	        if (diff == 0) break;
	 
	        // Increment index of array with smallest value
	        if (A[i] == minimum) i++;
	        else if (B[j] == minimum) j++;
	        else k++;
	    }
	 
	    // Print result
	    System.out.println( A[res_i] +" "+B[res_j]+" " + C[res_k]);;
	}
	private static void findMinimumDifference(int[] arr) {

		Arrays.sort(arr);

		int minimumu=Integer.MAX_VALUE;

		List<Integer>list=new ArrayList();

		for(int i=0;i<arr.length-1;i++){

		int temp=Math.abs(arr[i+1]-arr[i]);

		if(temp<minimumu){

		minimumu=temp;

		list=new ArrayList();

		list.add(arr[i]);list.add(arr[i+1]);

		}

		else if(temp==minimumu){

		list.add(arr[i]);list.add(arr[i+1]);

		}

		}

		for(Integer i:list){

		System.out.print(i+" ");

		}
	}
}
