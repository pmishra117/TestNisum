package array;

public class MergeSortDemo {
	  public static void main(String[] args) {
		   	        int []a = {2,15,22,47,51};
		  	        int []b = {14,18,26,45,49,56,78};
		  	           
		   	        // Array C of sum of size of the two sorted array A and B
		   	        int []cc =new int[a.length+b.length];
		   	        int l=0;
		   	        int h=a.length;
		   	          //merge(a,b, a.length,b.length);
		   	        mergeSort(l,h);
		   	        System.out.print("Array a: ");
		   	        System.out.print("Array c: ");
		   	        printArray(cc);
		   	    }
		   	 
		 public static  void mergeSort(int l,int h) {
			 int mid = 0;
			if(l<h)   
				   mid=(l+h)/2;
			 
			 mergeSort(l,mid);
			 mergeSort(mid+1,h);
			// merge(mid,h);
			 
		 }
		   	    public static void printArray(int []array){
		   	        for(int i : array){
		   	            System.out.print(i+" ");
		   	        }
		   	    }
		   	}
 
