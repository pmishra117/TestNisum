package geeks.array;

public class MaxSumofSubarray {
public static void main(String []  args){
	int []A= {-2, -3, 4, -1, -2, 1, 5, -3};
	System.out.println(maxSubarray(A));
}

public static int   maxSubarray(int []A) {
    int curr_max=A[0];
    int  total_max=A[0];
    for (int i=0;i< A.length;i++){
        curr_max = Math.max(A[i], A[i]+curr_max);
        total_max = Math.max(curr_max, total_max);
  
}
	return total_max;
}
}