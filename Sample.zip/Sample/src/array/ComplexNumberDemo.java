package geeks.array;
//our first class Complex#
public class ComplexNumberDemo {
public static void main(String[] args) {
	System.out.println(new ComplexNumberDemo(12,33).real);
}
//two int variables real and imagine
int real;
int imagine;

//Constructor, no parameters, setting our complex number equal to o + oi
ComplexNumberDemo() {
  real = 0;
  imagine = 0;        }

//Constructor taking two int variables as parameters.
public ComplexNumberDemo(int rePart, int imaginePart) {
  real = rePart;
  imagine = imaginePart;      }

//This is the add method, taking object c2 as parameter, and adding it to .this to return 
public ComplexNumberDemo add(ComplexNumberDemo c2) {
  return new ComplexNumberDemo(this.real + c2.real, this.imagine + c2.imagine);      }

//Now the subtract method, followed by the methods to multiply and divide according to hand-out rules.
public ComplexNumberDemo substract(ComplexNumberDemo c2) {
  return new ComplexNumberDemo(this.real - c2.real, this.imagine - c2.imagine);     }

public ComplexNumberDemo multiply(ComplexNumberDemo c2) {
  ComplexNumberDemo c3 = new ComplexNumberDemo();
  c3.real = this.real * c2.real - this.imagine * c2.imagine;
  c3.imagine = this.real * c2.imagine + this.imagine * c2.real;
  return c3;      }

public ComplexNumberDemo divide(ComplexNumberDemo c2) {
  ComplexNumberDemo c3 = new ComplexNumberDemo();
  c3.real = this.real / c2.real - this.imagine / c2.imagine;
  c3.imagine = this.real / c2.imagine + this.imagine / c2.real;
  return c3;      }

//toString1 method to return "a+bi" as a String.
public String toString1() {
  return this.real + " + " + this.imagine + "i";
}

}