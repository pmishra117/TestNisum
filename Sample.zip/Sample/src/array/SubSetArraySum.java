package array;

import java.util.ArrayList;
import java.util.HashMap;

public class SubSetArraySum {
	static int target=8;
	
public static void main(String[] args) {
	HashMap<Integer,Integer>listMap =new HashMap<Integer,Integer>();
	ArrayList<Integer>res =new ArrayList<Integer>();	
	listMap.put(1,1);
	listMap.put(3,3);
	listMap.put(4,4);
	listMap.put(7,7);
	
	res.add(returnSubSet(listMap,target));
}

public static Integer returnSubSet(HashMap<Integer,Integer> list,int target){
	if(list.containsKey(target)) return  list.get(target);
	else if(!list.containsKey(target)) {
		for(int i=0;i<list.size();) { 
			if( list.get(i)<target) {
				target-=list.get(i);
			}
		return list.get(i);
	}
	}
	
	System.out.println("Hello...");
	return null;
}
}
