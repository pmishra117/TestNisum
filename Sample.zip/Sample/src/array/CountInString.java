package geeks.array;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class CountInString {
public static void main(String[] args){
	String name="pradeep";
	
	Set st=new HashSet();
	char[] a=name.toCharArray();
	char[] a1=name.toCharArray();
	Arrays.sort(a1);

	for(int i=0;i<a.length;i++){
		st.add(a[i]);
		}
	Iterator itr=st.iterator();
	while(itr.hasNext()) {
  	int c=0;
	char ch=(Character) itr.next();
	for(int j=0;j<a1.length;j++){
	 if(ch==a1[j]){
		
	  c++;
	 }
	else {}
	
}
	System.out.println(ch+" is "+c+" times ");
}
}
}
