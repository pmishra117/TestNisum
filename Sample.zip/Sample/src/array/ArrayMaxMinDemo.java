package narshimbhaSirDS.array;

public class ArrayMaxMinDemo {
public static void main(String[] args) {
	int a[]={1,9,5,3,6,4,7,4,7,6};
}

public static void getMaxMin(int[]a){
	int min=0;
	int max=0;
	for(int i=0;i<a.length;i=i+2){
		if((a[i] <a[i+1])){
			min=a[i];
			
		}
		
	}
}

}
