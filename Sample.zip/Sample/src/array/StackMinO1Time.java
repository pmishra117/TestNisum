package array;

import java.util.Stack;

public class StackMinO1Time {
public static void main(String[] args) {
	Stack<Integer> st = new Stack<Integer>();
	st.add(2);st.add(3);st.add(1);st.add(5);st.add(7);
	System.out.println(findMin(st));
	 
}

static int findMin(Stack<Integer> st) {
	Stack<Integer> auxstack=new Stack<Integer>();
	while(!st.isEmpty()){
		int element= st.pop();
		if(auxstack.empty()) 
			auxstack.add(element);
		else if(element >-1) {
			int elementAux= auxstack.peek();
		    if(element <elementAux)
			auxstack.add(element);
		}
	}
	return auxstack.pop();
}


}
