package narshimbhaSirDS.array;

import java.util.HashMap;

public class MaxRepeatEleArray {
public static void main(String[] args) {
	int a[]={1,9,5,3,6,4,7,4,7,6};
	MaxRepeatElementArray(a);
}

public static void MaxRepeatElementArray(int []A) {
	int N=A.length;
	HashMap<Integer,String> map=new HashMap<Integer,String> ();
	for(int i=0;i<N;i++)  {
		if(map.containsKey(A[i])){
			System.out.println("Dublicate exits "+ A[i]);
			}
		                 else {
		                	 map.put(A[i], "ABC");
		                	 }
					}
	}
	
}
