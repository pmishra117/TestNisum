package geeks.cache;

	import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

	public class  LRUCacheDemo<K,V> {
		public static void main(String[] args) {
			LRUCacheDemo1 obj = new LRUCacheDemo1(5);
			
			for (int i = 1; i <= 5; i++) {
				obj.addElement("P", "Mishra");
			}
			for (int i = 1; i <= 5; i++) {
				obj.getElement("P");
				System.out.println(obj.getElement("P"));
			}
			
	}
	}
	class LRUCacheDemo1{	
		private  ConcurrentLinkedQueue concurrentLinkedQueue = new ConcurrentLinkedQueue();
		
		private  ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
		
		private ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
		
		private Lock readLock = readWriteLock.readLock();
		
		private Lock writeLock = readWriteLock.writeLock();
		
		int maxSize=0;
		
		public LRUCacheDemo1(final int MAX_SIZE){
			this.maxSize=MAX_SIZE;
		}
		
		public String getElement(String key){
			
			readLock.lock();
			try {
			String v=null;
			  if(concurrentHashMap.contains(key)){
				  concurrentLinkedQueue.remove(key);
				  v= (String) concurrentHashMap.get(key);
					concurrentLinkedQueue.add(key);
			  }
			  
			
			return v;
			}finally{
				readLock.unlock();
			}
		}
		
		public String removeElement(String key){
			 writeLock.lock();
			 try {
				String v=null;
			if(concurrentHashMap.contains(key)){
			v=(String) concurrentHashMap.remove(key);
				concurrentLinkedQueue.remove(key);
			}
			
			return v;
			 } finally {
				 writeLock.unlock();
			 }
		}
		
		public String addElement(String key,String value){
			writeLock.lock();
			try {
			if(concurrentHashMap.contains(key)){
				 concurrentLinkedQueue.remove(key);
			}
			while(concurrentLinkedQueue.size() >=maxSize){
				String queueKey=(String) concurrentLinkedQueue.poll();
				 concurrentHashMap.remove(queueKey);
			}
			concurrentLinkedQueue.add(key);
			concurrentHashMap.put(key, value);
			
			return value;
			} finally{
				writeLock.unlock();
			}
		}
		
	}	
		