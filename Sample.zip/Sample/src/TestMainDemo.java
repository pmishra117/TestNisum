package com.java;

package com.statestreet.sle.init;

import com.statestreet.sle.framework.util.Initialize;
import java.io.IOException;
import java.io.PrintStream;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InitializerService extends HttpServlet
{
  private boolean _blnInitialized = false;

  public void init(ServletConfig config) throws ServletException
  {
    initializeServer();
  }

  public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
  {
    printmsg(req, resp);
  }

  public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    printmsg(req, resp);
  }

  public void initializeServer()
  {
    String _appserverName = null;
    _appserverName = System.getProperty("appserver") != null ? System.getProperty("appserver") : "ALL";
    Initialize _intialize = null;
    try {
      System.out.println("InitializerService    : Appservername   : " + _appserverName);
      _intialize = new Initialize(_appserverName);
      _intialize.initialize(null);
    } catch (Exception _ex) {
      _ex.printStackTrace();
    }
  }

  public void printmsg(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
  }
}