
public abstract class TestInExtend implements TestIn {
 
public abstract void c();
public void a() {};
public void b() {};

}
