package Dp;

import java.util.HashSet;
import java.util.Set;

public class PermutationDemo {
 
/*
public static Set<String> permutation(String str) {
	Set <String> mySet= new HashSet<String>();
	if(str==null) {
		mySet.add("");
		return mySet;
	}
	 	
	char s =str.charAt(0);
	String restString=str.substring(1);
	
	Set<String>words=permutation(restString);
return null;	
}
*/

 	  public static void main(String args[]) {
	    permuteString("", "cat");
	  }

	  public static void permuteString(String beginningString, String endingString) {
	    if (endingString.length() <= 1)
	      System.out.println(beginningString + endingString);
	    else
	      for (int i = 0; i < endingString.length(); i++) {
	        try {
	             permuteString(beginningString + endingString.charAt(i), endingString.substring(0, i) + endingString.substring(i + 1));
	        } catch (StringIndexOutOfBoundsException exception) {
	          exception.printStackTrace();
	        }
	      }
	  }
	}
 
