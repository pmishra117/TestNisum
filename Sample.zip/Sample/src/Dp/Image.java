package com.demoJava.Dp;

public interface Image {
	  public void display();
	   

}
