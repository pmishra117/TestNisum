package Dp.behavioural;

public class MediatorDemo {

}
