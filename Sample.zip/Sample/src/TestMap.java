import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class TestMap {
		
public static void main(String[] args) {
	List<HashMap<String, Object>>listopt =new ArrayList<HashMap<String, Object>>();

	  HashMap<String, Object> map=new HashMap<String,Object>();

	map.put("funtionid",1);
	map.put("funtion",pupulateFunction());
	
	List<HashMap<String, Object>>list =new ArrayList<HashMap<String, Object>>();
	list.add(map);
	
	Iterator it=list.iterator();
	
	while(it.hasNext()) {
		HashMap<String, Object> mapIn =(HashMap<String, Object> )it.next();
		Set mapInner=mapIn.keySet();
		Iterator itIn=mapInner.iterator();
		
		while(itIn.hasNext()) {
			String key=(String) itIn.next();
			System.out.println(key.toUpperCase());
			System.out.println(mapIn.get(key));
			
			if(mapIn.get(key) instanceof HashMap) {
				System.out.println("Println "+mapIn.get(key));
			}
		}
			
		
		
	}
	
	
}

public static Object pupulateFunction() {
	HashMap<String, Object> map1=new HashMap<String,Object>();

	   map1.put("functionname","abc");
	return map1;

}
}
