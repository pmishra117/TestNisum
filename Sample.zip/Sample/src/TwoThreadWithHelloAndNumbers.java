package com.java.threading;


class PrintHelloNumbers {
	private boolean flag=false;
	public synchronized void printHello(){  try {
		if(flag==true)
		wait();
	} catch(InterruptedException e){}
		System.out.println("Hello..");
		notifyAll();
		flag=true;
		
	}
public synchronized void printOdd(int i){ 
	try {
		 if(flag==false)
			  wait();
	}catch(InterruptedException e) {}
	System.out.println(""+i);
	   notifyAll();
       flag=false;
       }
}
class Thread11 extends Thread {
	PrintHelloNumbers print;
	
	public Thread11(PrintHelloNumbers p) {
		// TODO Auto-generated constructor stub
	   this.print=p;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++){
			if(i%4 != 0)
			print.printOdd(i);
		}
	}
	 
	
}
class Thread22 extends Thread  {
	PrintHelloNumbers print;
		
	public Thread22(PrintHelloNumbers p) {
		// TODO Auto-generated constructor stub
	   this.print=p;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++){
			if(i%4 == 0)
			print.printHello();
		}
	}
	 
	
}
public class TwoThreadWithHelloAndNumbers {
public static void main(String[] args) {
	PrintHelloNumbers print=new PrintHelloNumbers();
    Thread11 th1 =new Thread11(print);
    Thread22 th2=new Thread22(print);
	    th1.start();
        th2.start();
	 
}
}

 
