package demoJava.Concurrency;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

  class MyClass implements Runnable {

    Thread thread;
    public MyClass(int numOfThreads) {
        for(int i=0;i < numOfThreads; i++) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void run() {
        readFile();
    }
    
    public synchronized void readFile() {
        try {
             String line;
            BufferedReader buf = new BufferedReader(new FileReader("/home/ofssgx/NameList.txt"));
            while ((line = buf.readLine()) != null) {
                String[] info = line.split(" ");
                String firstName = info[0];
             //   String secondName = info[1];
           System.out.println(firstName+"  Read by Thread "+Thread.currentThread().getName());     
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                }
            }  
            } catch (IOException e) {
            System.out.println("Error : File not found");
            e.printStackTrace();
        }
    }
}
public class ReadFileByMulTiThreadDemo {
public static void main(String[] args) {
	MyClass myClass = new MyClass(1);
	Thread th=new Thread(myClass);
	th.start();
	Thread th1=new Thread(myClass);
	th1.start();
	Thread th2=new Thread(myClass);
	th2.start();
}
}
