package toyrobotsimulator.dengpeng.de;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import toyrobotsimulator.dengpeng.de.ToyRobot.Facing;

public class ToyRobotSimulator {
	
	//define the size of board, this board is 5 x 5
	public static final int BOARD_WIDTH = 4;
	public static final int BOARD_HEIGHT = 4;

	public static void main(String[] args) {
		ToyRobot dalek = null;
		Board battlefield = new Board(BOARD_WIDTH,BOARD_HEIGHT);
		
		//this application only accepts 1 argument which is input file path
		if (args.length == 1){
			try {
				File file = new File(args[0]);
				
				//check if this file exists or not
				if (file.exists()){
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line;
					int lineCounts = 0;
					
					//read and process the input file one line each time until the end of file
					while ((line = br.readLine()) != null) {
						//if the command is place
						if (line.toUpperCase().startsWith("PLACE")){
							//check if this command is valid
							try{
								String[] initString = line.split(" ");
								String[] initLocation = initString[1].split(",");
								//robot must be placed on board. Outside of board is considered invalid command
								if ((Integer.valueOf(initLocation[0]) >= 0) && (Integer.valueOf(initLocation[0]) <= battlefield.getWidth()) && 
										(Integer.valueOf(initLocation[1]) >= 0 ) && (Integer.valueOf(initLocation[1]) <= battlefield.getHeight())){
									dalek = new ToyRobot(Integer.valueOf(initLocation[0]), Integer.valueOf(initLocation[1]),Facing.valueOf(initLocation[2]));
									dalek.deployTo(battlefield);
								}
							}catch(Exception ex){
								
							}
						}
						
						//if robot is on board, it can be controlled
						if (dalek != null){
							if (line.equalsIgnoreCase("LEFT")){
								dalek.turnLeft();
							}else if (line.equalsIgnoreCase("RIGHT")){
								dalek.turnRight();
							}else if (line.equalsIgnoreCase("MOVE")){
								dalek.move();
							}else if (line.equalsIgnoreCase("REPORT")){
								System.out.println("Output: " + dalek.report());
							}
						}
						
						//remember how many lines of command we have checked
						lineCounts++;
					}
					//close the file
					br.close();
					
					//if the file is empty file, this application reports
					if (lineCounts == 0){
						System.out.println("Empty file: " + args[0]);
					}else{
						//if robot is never placed properlly on board, it is considered to be invalid file
						if (dalek == null)
							System.out.println("Invalid command file: " + args[0]);
					}
				//if file is not found, application reports
				} else {
					System.out.println("File not found: " + args[0]);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}else{
			System.out.println("Only accept 1 argument, " + String.valueOf(args.length) + " given.");
		}
	}

}
