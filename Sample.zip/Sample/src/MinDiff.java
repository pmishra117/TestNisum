import java.util.Arrays;


public class MinDiff {
public static void main(String[] args) {
	int[] a = new int[] {4, 9, 1,4,23,5,6,2,5,32,5,43,5};
	
	int minDiff=minDiff(a);
	System.out.println(minDiff);
}

public static int minDiff(int []a){
	int diffArr[]=new int[(a.length)*a.length];
//	int i=0;
//	int j=a.length-1;
	int c=0;
	for(int i=0;i<a.length-1;i++){
		for(int j=0;j<a.length;j++){
			
			diffArr[c]=a[i]-a[j];
			c++;
		}
	}
	int min=minm(diffArr);
	//System.out.println(min);
	
	return min;
}

public static int minm(int [] diffArr){
	int min=0;
	for(int i=0;i<diffArr.length-1;i++){
		if(min < diffArr[i])
			min=diffArr[i];
	}
	return min;
}
}
