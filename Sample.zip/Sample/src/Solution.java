class Solution {
  public static void main(String[] args) {
   int []a={1,3};
    int[] b={2,4};
   int []c= merge(a,b);
    for(int i=0;i<c.length;i++) System.out.print("sorted  "+c[i]);
  }
  
  public static int [] merge(int []a,int []b) {
       int mergelength=0;
       int n1=a.length-1;
       int n2=a.length-1;
     
      int  merge[]= new int[n1+n2];
     
       if(a==null || b== null) return null;
    else {
      int i=0;int j=0;
     while(i <n1  && j<n2 ) {
         if(a[i]<b[j]) {
           merge[mergelength++]=a[i];
        i++;
        //  j++;
         }
        else if(a[i]>b[j]) {
           merge[mergelength++]=b[j];
          j++;
        // i++;
        } 
        else {}
      } 
     
     // Store remaining elements of first array 
     while (i < n1) 
         merge[mergelength++] = a[i++]; 
   
     // Store remaining elements of second array 
     while (j < n2) 
    	 merge[mergelength++] = b[j++]; 
 } 
   
 
 return merge;
  }  }