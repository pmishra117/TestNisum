package miss;

public class TestCallable {
public static void main(String[] args) {
	System.out.println("hi");
}
}
