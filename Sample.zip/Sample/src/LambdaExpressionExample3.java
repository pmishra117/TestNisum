import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

interface Sayable{  
    public String say();  
}  
public class LambdaExpressionExample3{  
public static void main(String[] args) {  
    Sayable s=()->{  
        return "I have nothing to say......";  
    };  
    System.out.println(s.say()); 
    
    Stream<String> fruitStream = Stream.of("apple", "banana", "pear", "kiwi", "orange");
    fruitStream.filter(ss -> ss.contains("a")).map(x->x.toUpperCase()).sorted().forEach(System.out::println);
    
    IntStream.range(1, 10).filter(a -> a % 2 == 0).forEach(System.out::println);

    Stream.of("apple", "orange", "banana", "apple")
    .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
    .entrySet()
    .forEach(System.out::println);
    
    
 // Generate infinite stream - 1, 2, 3, 4, 5, 6, 7, ...
    IntStream naturalNumbers = IntStream.iterate(1, x -> x + 1);
    // Print out only the first 5 terms
    naturalNumbers.limit(1).forEach(System.out::println);
    
    
    System.out.println(Arrays
    		.asList("apple", "banana", "pear", "kiwi", "orange")
    		.stream()
    		.filter(sn -> sn.contains("p"))
    		.collect(Collectors.toList())
    		);
    
    Supplier<Stream<String>> streamSupplier = () -> Stream.of("apple", "banana","orange", "grapes",
    		"melon","blueberry","blackberry")
    		.map(String::toUpperCase).sorted();
    		streamSupplier.get().filter(sp -> sp.startsWith("A")).forEach(System.out::println);
    		// APPLE
    		streamSupplier.get().filter(sp -> sp.startsWith("B")).forEach(System.out::println);

}  



}  