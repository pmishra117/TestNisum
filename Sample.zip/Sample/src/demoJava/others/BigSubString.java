package demoJava.others;
import java.util.HashMap;

public class BigSubString {
	public static String subStr="";
	public static String str="Pradeep";
	public static String name=null;
    public static String getName() {
		return name;
	}

	public static void setName(String name) {
		BigSubString.name = name;
	}
	static int c=0;
    HashMap myHashmap =new HashMap();
 
public BigSubString(String string) {
		// TODO Auto-generated constructor stub
	}

public static void main(String[] args) {
	
	BigSubString BigSubString =new BigSubString(null);
	BigSubString.demo();
   // String newString = getBiggestSubString(str);
   // System.out.println("new String...   "+newString);
}

public   void demo(){
BigSubString key = new BigSubString("Pankaj"); //assume hashCode=1234
  
myHashmap.put(key, "Value");
	 
	// Below code will change the key hashCode() and equals()
	// but it's location is not changed.
	key.setName("Amit"); //assume new hashCode=7890
	 
	//below will return null, because HashMap will try to look for key
	//in the same index as it was stored but since key is mutated,
	//there will be no match and it will return null.
	System.out.println(myHashmap.get(new BigSubString("Pankaj")));
}
public static String getBiggestSubString(String str) {
	for(int i=0;i<str.length();i++) {
		subStr=str.substring(0,i);
		String SubStrM=subStr.charAt(i)+"";
		if(i>0){
			for(int j=0;j<subStr.length();j++) {
				String newOne=""+subStr.charAt(j);
			    if(SubStrM.equalsIgnoreCase(newOne)) {
			    	++c;
			    	if(c>1)break;
			    }
			}
		}
		
	}
	return str;
}

}