package demoJava.Ds;

public class MergeSortDemo {
	public static void main(String[] args) {
		int[] a = { 5,6,7};
		int[] b = { 3,4 };
		//merge(a,a.length,b,b.length);
		// Array C of sum of size of the two sorted array A and B
		 int[] c = new int[a.length + b.length];
		 mergeA(a, b, c);
		System.out.print("Array a: ");
		printArray(c);
		System.out.println();
		System.out.println("Array b: ");
		printArray(b);
		System.out.println();
		System.out.print("Array c: ");
	 }

	/*
 		public static void merge( int A[ ] , int m, int B [ ] , int n) {
 			int[] c = new int[m + n];
 		while (m > 0 && n > 0) {
		if (A[m-1] > B[n-1]) {
		c[m+n-1] = A[m-1];
		m--;
		} else {
		c[m+n-1] = B[n-1];
		n--;
		}
		}
		while (n > 0) {
		c[m+n-1] = B[n-1];
		n--;
		}
		while (m > 0) {
			c[m+n-1] = A[m-1];
			m--;
			}
		printArray(c);
		}
	*/ 
	 public static void mergeA(int[] a, int[] b, int[] c) {
		int i = 0, j = 0, k = 0;
		int sizeA = a.length;
		int sizeB = b.length;
 	// Runs until neither array is empty
		while (i < sizeA && j < sizeB) {
			// Compare the items of two arrays and copy the smaller item into to
			// third array
			if (a[i] < b[j]) {
				c[k++] = a[i++];
			} else {
				c[k++] = b[j++];
			}
		}

		// If array B's cursor scanned and compared all the items of the array
		// but array A's is not
		while (i < sizeA) {
			c[k++] = a[i++];
		}

		// If array A's cursor scanned and compared all the items of the array
		// but array B's is not
		while (j < sizeB) {
			c[k++] = b[j++];
		}
	}
 
	public static void printArray(int[] array) {
		for (int i : array) {
			System.out.print(i + " ");
		}
	}
}