package math;

public class PermutationCombinationDemo {
  public static void main(String[] args) {
	permutation("", "ABC");
}

/*
 *  * Recursive method which actually prints all permutations * of given
 * String, but since we are passing an empty String * as current permutation
 * to start with, * I have made this method private and didn't exposed it to
 * client.
 */

private static void permutation(String perm, String word) {
	if (word.isEmpty()) {
		System.err.println(perm + word);
	} else {
		for (int i = 0; i < word.length(); i++) {
			char firstChar=word.charAt(i);
						
			permutation(perm + firstChar,word.substring(0, i)+ word.substring(i + 1, word.length()));
		}
	}
}}