import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Product {
    public int id;
    public String name;
    public float price;
    public Product(int id, String name, float price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }
    
    public static void main(String[] args) {
    	//or in java 8
    	Map<String, Double> productPrice = new HashMap<>();
    	// add value
    	productPrice.put("Rice", 6.9);
    	productPrice.put("Flour", 3.9);
    	productPrice.put("Sugar", 4.9);
    	productPrice.put("Milk", 3.9);
    	productPrice.put("Egg", 1.9);
    	 	
    	productPrice.forEach((key, value) -> {
    		System.out.print("key: "+ key);
    		System.out.println(", Value: "+ value);
    		}); 
    	
	}
}