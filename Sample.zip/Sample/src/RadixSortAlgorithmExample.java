package geeks;


public class RadixSortAlgorithmExample {
 
    /**
     * Declare initialize array which has to be sorted using Radix sort in java
     */
 
    private int[] arr = { 12, 3, 8, 9, 1, 14, 6, 7, 5, 89 };
 
    /**
     * This method Sort Array using Radix Sort in java
     */
    public void radixSort() {
           int i,
                  j = 1,
                  temp = arr[0];
           int num = arr.length;
           int[] arr2 = new int[20];
           
           for (i = 1; i < num; i++){
                  if (arr[i] > temp){
                        temp = arr[i];
                  }
           }
           
           while (temp / j > 0) {
                  int[] bucketArray = new int[10];
 
                  for (i = 0; i < num; i++){
                        bucketArray[(arr[i] / j) % 10]++;
                  }
                  
                  for (i = 1; i < 10; i++){
                        bucketArray[i] += bucketArray[i - 1];
                  }
                  
                  for (i = num - 1; i >= 0; i--){
                        arr2[--bucketArray[(arr[i] / j) % 10]] = arr[i];
                  }
                  
                  for (i = 0; i < num; i++){
                        arr[i] = arr2[i];
                  }
                  
                  j *= 10; //Always multiply by 10 to move from 0's to 10's to 100's .... 
                  
           } //End while loop
    } //End Radix sort method
 
    
    /**
     * This method Display Array in java
     */
    public void display() {
           for (int i = 0; i < arr.length; i++) {
                  System.out.print(arr[i] + " ");
           }
    }
 
    public static void main(String[] args) {
 
           RadixSortAlgorithmExample radixSort = new RadixSortAlgorithmExample();
 
           System.out.print("Display Array elements before Radix sorting : ");
           radixSort.display(); // display unsorted array
 
           radixSort.radixSort(); // radix sort the array
 
           System.out.print("\nDisplay Array elements after Radix sorting  : ");
           radixSort.display(); // display sorted array
 
    }
 
}
