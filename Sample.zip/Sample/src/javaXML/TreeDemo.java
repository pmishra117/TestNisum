package javaXML;

  class Node {
	int iData;
	double fData;
	Node leftChild;
	Node rightChild;
}

class Tree {
	private Node root; // the only data field in Tree

	public Node getRoot() {
		return root;
	}
 

	public Node find(int key) {
		Node current = root; // start at root
		while (current.iData != key) // while no match,
		{
			if (key < current.iData) // go left?
				current = current.leftChild;
			else
				current = current.rightChild; // or go right?
			if (current == null) // if no child,
				return null; // didn't find it
		}
		return current; // found it
	}

	public void insert(int id, double dd) {
		Node newNode = new Node(); // make new node
		newNode.iData = id; // insert data
		newNode.fData = dd;
		if (root == null) // no node in root
			root = newNode;
		else // root occupied
		{
			Node current = root; // start at root
			Node parent;
			while (true) // (exits internally)
			{
				parent = current;
				if (id < current.iData) // go left?
				{
					current = current.leftChild;
					if (current == null) // if end of the line,
					{ // insert on left
						parent.leftChild = newNode;
						return;
					}
				} // end if go left
				else // or go right?
				{
					current = current.rightChild;
					if (current == null) // if end of the line
					{ // insert on right
						parent.rightChild = newNode;
						return;
					}
				} // end else go right
			} // end while
		} // end else not root
	}

	public void delete(int id) {
	}
	// various other methods
	
	public static   int countLeftNodes(Tree theTree){
	 	int count=0;
		Node current=theTree.root;
		while(current.leftChild != null){
			count++;
			current=current.leftChild;
		}
		return count;
	}
	
	public static   int countAllNodes(Tree theTree){
	 	int count=0;
		Node current=theTree.root;
		Node current1=theTree.root;
		
		while(current.leftChild != null){
			count++;
			current=current.leftChild;
		}
		while(current1.rightChild != null){
			count++;
			current1=current1.rightChild;
		}
		return count;
	}

}

public class TreeDemo {
	public static void main(String[] args) {
		Tree theTree = new Tree(); // make a tree
		theTree.insert(50, 1.5); // insert 3 nodes
		theTree.insert(25, 1.7);
		theTree.insert(75, 1.9);
		theTree.insert(15, 1.7);
		theTree.insert(13, 1.9);
		int count=Tree.countLeftNodes(theTree);
		System.out.println("No of left Nodes are..."+count);
		
		int counta=Tree.countAllNodes(theTree);
		System.out.println("No of   Nodes are..."+counta);
	
		/*Node found = theTree.find(25); // find node with key 25
		if (found != null)
			System.out.println("Found the node with key 25");
		else
			System.out.println("Could not find node with key 25");
	} */// end main()
} 
	}
