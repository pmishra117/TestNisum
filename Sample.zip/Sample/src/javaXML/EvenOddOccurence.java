package javaXML;

import java.util.HashSet;
import java.util.Iterator;

public class EvenOddOccurence {
public static void main(String[] args) {
	int []a={1,6,4,1,4,5,8,8,4,6,8,8,9,7,9,5,9};
	new EvenOddOccurence().evenOccurNumber(a);
}

int count=0;
public void evenOccurNumber(int[] a) {
	for(int i=0;i<a.length;i++) {
		count=0;
		for(int j=0;j<a.length;j++) {
		if(a[i]==a[j]) {
			count++;
		}
		}
		if(count%2==0) {  
		//	break;
		 
			System.out.println("numbers are ");
				}
		//System.out.println(a[i]);
		 
 
HashSet<Integer>set =new HashSet<Integer>();
set.add(1);
set.add(2);
set.add(3);
for (Iterator it = set.iterator(); it.hasNext(); ) {
   Integer element=(Integer) it.next();
	if (element % 2 == 0) {
        it.remove();
     }
    System.out.println(element);
    
} 
}
}
}
