package javaXML;

import java.util.Arrays;
import java.util.Hashtable;

public class OwnArrayListImpl {
public static void main(String[] args) {
	String str="pradeep";
//new OwnArrayListImpl().distict(str);
   ArrayListImpl al=new ArrayListImpl();
	al.add("Pradeep");
	al.add("Pradeep1");
	al.add("Pradeep2");
	al.add("Pradeep3");
	//int[]a={2,3,2,5,2,3};
	//OwnArrayListImpl.duplicate(a);
	
}

public static void duplicate(int[] a){
	@SuppressWarnings("rawtypes")
	Hashtable ht =new Hashtable();
	int c=1;
	for(int i=0;i<a.length-1;i++){
		if(!ht.containsKey(a[i])){
		ht.put(a[i],"ddd");
		}
		else {
			++c;
			System.out.println("Duplicate   "+a[i]);
		}
		
	}
	
}

public void distict(String str) {
 for(int i=0;i<str.length();i++) {
		int count =0;

	 char c=str.charAt(i);
	 for(int j=0;j<str.length();j++) {
       if(c==str.charAt(j)) {
    	   count++;
    	   if(count<=1) {
    		   System.out.println("Distince chars are "+str.charAt(j));
    	   }
       }
	 }
	 }
 } 
}
class ArrayListImpl {
	public static Object[] newData;
	int CAPACITY=2;
	
	public ArrayListImpl(){
		newData=new Object[3];
	}
	
	public void add(Object data){
		if(newData.length-1 <=CAPACITY){
			increaseArray();
		}
		else{
			newData[++CAPACITY]=data;
		}
	}
	
	static void increaseArray(){
		newData=Arrays.copyOf(newData, newData.length*2);
		System.out.println("new size is..."+newData.length);
	}
}

