import java.io.IOException;
 


public class HDFSJavaAPI {
public static void main(String[] args) throws IOException {
	String text = "This - 1243text12 !456 has \\ /allot356 # 9of %2 special % 36characters";
	text = text.replaceAll("[^0-9]", ""); 
	System.out.println(text); 

}

class MyRunnable implements Runnable {

    private static final int LIMIT = 20;
      static final int counter = 0;
    private int id;

    public MyRunnable(int id) {
        this.id = id;
    }

   
    public void run() {
        outer:
        while(counter < LIMIT) {
            while (counter % 5 != id) {
                if(counter == LIMIT) break outer;
            }
            System.out.println("Thread "+Thread.currentThread().getName()+ " printed " + counter);
            counter += 1;
        }
    }
}
}