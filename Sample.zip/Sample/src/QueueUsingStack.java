package geeks;

class Stack {
	public int[] stackArray=null;
    int top=-1;
    public Stack(int size) {
    	stackArray=new int[size];
    }
    public boolean isEmpty() {
    	if(top>=0) {
    		return false;
    	}
    	return true;
    		
    }
    
    public void push(int ii) {
    	if(isFull() != true)
    	stackArray[++top]=ii;
    }
    
    public boolean isFull() {
    	if (top==stackArray.length){
    		return true;
    	}
		return false;  		
    		
    }
    
    public int pop() {
    	if(isEmpty() != true) {
    	return stackArray[top--];
    }
		return 0; 
   }
}
public class QueueUsingStack {
	Stack s1=new Stack(10);
	Stack s2=new Stack(10);
	public void inqueue(int i) {
		s1.push(i);
		System.out.println(s1.pop());
	}
	
	public int dequeue(){
		s2.push(s1.pop());
		
		
		return s2.pop();
	}
public static void main(String[] args) {
	QueueUsingStack QueueUsingStack =new QueueUsingStack();
	for(int i=1;i<6;i++)
	QueueUsingStack.inqueue(i);
}
}
