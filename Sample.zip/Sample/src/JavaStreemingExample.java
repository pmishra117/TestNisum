import java.util.List;
import java.util.stream.IntStream;

public class JavaStreemingExample {
public static void main(String[] args) {
Map<String,List<Integer>> m =IntStream.range(0, 1000).parallel().box	
}
}
