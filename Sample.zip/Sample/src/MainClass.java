package javaXML;

import java.util.ArrayList;

 

	public class MainClass {
		 	public static void main(String[] args) throws Exception
			{ 
				int[] a={0,1,1,0};
				int []b={,};
				int c[]={,};
				int size=a.length-1;
				int zeroLength=0;
				int onelength=size-zeroLength;
		    	    for(int i=0;i<a.length;i++){
			    	if(a[i]==0){
			    		b[zeroLength++]=0;
			    	 }
			    	else{
			    		c[onelength++]=1;
			    	}
			    	
			    }
		    	    a[size]=b[zeroLength]+c[onelength];
		    	 
		    	    for(int j=0;j<size;j++){
					    System.out.println(a[j]);
			}
			}
		 	}