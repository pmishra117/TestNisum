

class PrintDemo {
	public boolean flag=false;
	
	public synchronized void print20F(int i){
		 while(flag==true){
			 try {
				 wait();
			 }catch(InterruptedException e) { } 
			 }
				 System.out.println(Thread.currentThread().getName()+ "  print i "+i);
			 if(i%10==0) {
				 flag=true;
			 notifyAll();
			 }
		 }	 
		 
		 
		 public synchronized void print20S(int j){
				 while(flag==false){
					 try {
						 wait();
					 }catch(InterruptedException e) {}  }
						 System.out.println(Thread.currentThread().getName()+ "  print j "+j);
						 if(j%10==0) // break;
						 {
					 flag=false;
					 notifyAll();
						 }
					 
				 }
	}
	

public class TwoThreadDemo implements Runnable {
	PrintDemo th =new PrintDemo();

	public static void main(String[] args) {
		TwoThreadDemo twoThreadDemo =new TwoThreadDemo();
		Thread t1= new Thread(twoThreadDemo);
		Thread t2= new Thread(twoThreadDemo);
		t1.start();
		t2.start();
		
		}

	public void run() {
		// TODO Auto-generated method stub
		int i=1;
		int j=1;
		while(i <=100 | j<=100) {
	for(i=1;i<=100;i++){
		th.print20F(i); if(i%10==0) break;
	}
	   for(j=1;j<=100;j++){
		   th.print20S(j);
		   if(j%10==0) break;
	   }
		}
	}
	
}