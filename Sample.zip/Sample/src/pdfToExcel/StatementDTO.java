package pdfToExcel;

import java.math.BigDecimal;

public class StatementDTO {
	String Date_Narration;
	String Chq_Ref_No;
	String Value_Dt;
	BigDecimal Withdrawal_Amt;
	BigDecimal Deposit_Amt;
	BigDecimal Closing_Balance;
	
	
	public String getDate_Narration() {
		return Date_Narration;
	}
	public void setDate_Narration(String date_Narration) {
		Date_Narration = date_Narration;
	}
	public String getChq_Ref_No() {
		return Chq_Ref_No;
	}
	public void setChq_Ref_No(String chq_Ref_No) {
		Chq_Ref_No = chq_Ref_No;
	}
	public String getValue_Dt() {
		return Value_Dt;
	}
	public void setValue_Dt(String value_Dt) {
		Value_Dt = value_Dt;
	}
	public BigDecimal getWithdrawal_Amt() {
		return Withdrawal_Amt;
	}
	public void setWithdrawal_Amt(BigDecimal withdrawal_Amt) {
		Withdrawal_Amt = withdrawal_Amt;
	}
	public BigDecimal getDeposit_Amt() {
		return Deposit_Amt;
	}
	public void setDeposit_Amt(BigDecimal deposit_Amt) {
		Deposit_Amt = deposit_Amt;
	}
	public BigDecimal getClosing_Balance() {
		return Closing_Balance;
	}
	public void setClosing_Balance(BigDecimal closing_Balance) {
		Closing_Balance = closing_Balance;
	}
	
}
