package pdfToExcel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteToExcelUtils {
	  //Create blank workbook
    static XSSFWorkbook workbook = new XSSFWorkbook();
  
	  //Create a blank sheet
    static XSSFSheet spreadsheet = workbook.createSheet( " Employee Info ");
    

    //Create row object
    static XSSFRow row;
    static Integer count=1;
    static boolean flag= false;
    static Map <Integer, Object[] > empinfo =null;
    static String Date_Narration=null;
    static String  ChqRefNo  = null;
   static String  ValueDt  = null;
   static String  Withdrawal_Amt  = null; 
   static String  Deposit_Amt   =null;
   static String   Closing_Balance  = null;
  
  	public static void writeToExcel(String line) throws IOException {
	 //This data needs to be written (Object[])
  		
  		 String [] data=line.split(" ");
  	  	  
  	   if(flag!=true &&  !line.isEmpty()) {
  		   empinfo = new TreeMap <Integer, Object[] >();
      empinfo.put( ++count, new Object[] {
      		"Date_Narration", "Chq_Ref_No", "Value_Dt","Withdrawal_Amt", "Deposit_Amt", "Closing_Balance"}
      );
      
      
      
  	  }
  	  if(null != data[0] && data[2]==null && flag==true) {
   		  empinfo.put( count, new Object[] {
   				Date_Narration+data[0], ChqRefNo, ValueDt,Withdrawal_Amt, Deposit_Amt, Closing_Balance});
   	  }
    	 
  	   
  	    if(null != data[0] && data[2]!=null && flag==true){ Date_Narration=data[0];    ChqRefNo=data[1];  Withdrawal_Amt= data[3];Deposit_Amt=data[4];ValueDt=data[2];Closing_Balance=data[5];
		  empinfo.put( count, new Object[] {
     				Date_Narration+data[0], ChqRefNo, ValueDt,Withdrawal_Amt, Deposit_Amt, Closing_Balance});
    
		  flag=true;
		      
    //Iterate over data and write to sheet
    Set<Integer> keyid = empinfo.keySet();
    int rowid = 0;
    
    for (Integer key : keyid) {
       row = spreadsheet.createRow(++rowid);
       Object [] objectArr = empinfo.get(key);
       int cellid = 0;
       
       for (Object obj : objectArr){
          Cell cell = row.createCell(cellid++);
          cell.setCellValue((String)obj);
       }
    }
    //Write the workbook in file system
    FileOutputStream out = new FileOutputStream(
       new File("C:\\poiexcel\\Writesheet.xlsx"));
    
    workbook.write(out);
    out.close();
    System.out.println("Writesheet.xlsx written successfully");
  	   }
	 
 }
  	}
 
