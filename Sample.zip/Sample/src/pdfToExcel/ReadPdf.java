package pdfToExcel;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;

public class ReadPdf {

    public static void main(String[] args) throws IOException {
    	getPdfContent("C:\\\\PdfBox_Examples\\\\Sample_Statement.pdf");
    }

    	private static  String getPdfContent(String pdfFile) {
    		try {
    			PdfReader reader = new PdfReader(pdfFile);
    			StringBuffer sb = new StringBuffer();
    			PdfReaderContentParser parser = new PdfReaderContentParser(reader);
    			TextExtractionStrategy strategy;
    			for (int i = 1; i <= reader.getNumberOfPages(); i++) {
    				strategy = parser.processContent(i, new SimpleTextExtractionStrategy());
    				sb.append(strategy.getResultantText());
    			}
    			reader.close();
    			return sb.toString();
    		} catch (IOException e) {
    			throw new IllegalArgumentException("Not able to read file " + pdfFile, e);
    		}
    	}
}