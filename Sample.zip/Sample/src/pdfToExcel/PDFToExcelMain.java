package pdfToExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import org.apache.poi.hssf.model.Sheet;
import org.apache.poi.hssf.model.Workbook;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;

public class PDFToExcelMain {
	static HSSFRow myRow = null;
	HSSFCell myCell = null;

	public static void main(String[] args) {
		PdfReader reader;
		import java.io.FileInputStream;
		import java.io.*;
		//POI libraries to read Excel 2007 format file
		import org.apache.poi.xssf.usermodel.XSSFWorkbook;
		import org.apache.poi.xssf.usermodel.XSSFSheet; 
		import org.apache.poi.ss.usermodel.*;
		import java.util.Iterator;
		//itext libraries to create PDF table from XLSX
		import com.itextpdf.text.*;
		import com.itextpdf.text.pdf.*;

		public class xlsx2pdf {  
		        public static void main(String[] args) throws Exception{
		                //First we read the XLSX in binary format into FileInputStream
		                FileInputStream input_document = new FileInputStream(new File("C:\\excel_to_pdf.xlsx"));
		                // Read workbook into XSSFWorkbook
		                XSSFWorkbook my_xls_workbook = new XSSFWorkbook(input_document); 
		                // Read worksheet into XSSFSheet
		                XSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0); 
		                // To iterate over the rows
		                Iterator<Row> rowIterator = my_worksheet.iterator();
		                //We will create output PDF document objects at this point
		                Document iText_xls_2_pdf = new Document();
		                PdfWriter.getInstance(iText_xls_2_pdf, new FileOutputStream("PDFOutput.pdf"));
		                iText_xls_2_pdf.open();
		                //we have two columns in the Excel sheet, so we create a PDF table with two columns                
		                PdfPTable my_table = new PdfPTable(2);
		                //cell object to capture data
		                PdfPCell table_cell;
		                //Loop through rows.
		                while(rowIterator.hasNext()) {
		                        Row row = rowIterator.next(); 
		                        Iterator<Cell> cellIterator = row.cellIterator();
		                                while(cellIterator.hasNext()) {
		                                        Cell cell = cellIterator.next(); //Fetch CELL
		                                        switch(cell.getCellType()) { //Identify CELL type
		                                                
		                                        case Cell.CELL_TYPE_STRING:
		                                                //Push the data from Excel to PDF Cell
		                                                 table_cell=new PdfPCell(new Phrase(cell.getStringCellValue()));                                                
		                                                 my_table.addCell(table_cell);
		                                                break;
		                                        }
		                                        //next line
		                                }
		                
		                }
		                //Finally add the table to PDF document
		                iText_xls_2_pdf.add(my_table);                       
		                iText_xls_2_pdf.close();                
		                //we created our pdf file..
		                input_document.close(); //close xlsx
		        }
		}
		 
	
	try {
	    reader = new PdfReader("D:/JDEV_WORK/MANOJ/ItemPriceReport.pdf");
	    PdfReaderContentParser parser = new PdfReaderContentParser(reader);
	    TextExtractionStrategy strategy;
	    String line = null;
	    for (int i = 1; i <= reader.getNumberOfPages(); i++) {
	        strategy = parser.processContent(i,new SimpleTextExtractionStrategy());
	        line = strategy.getResultantText();
	        System.out.println("line --- "+line);
	    }

	//conversion starts here....

	} catch(Exception e) {}
}
	
	
	 public void writeExcel(String filePath,String fileName,String sheetName,String[] dataToWrite) throws IOException{

	        //Create an object of File class to open xlsx file

	        File file =    new File(filePath+"\\"+fileName);

	        //Create an object of FileInputStream class to read excel file

	        FileInputStream inputStream = new FileInputStream(file);

	        HSSFWorkbook workbook = null;
	        XSSFWorkbook workbook1 = null;


	        //Find the file extension by splitting  file name in substring and getting only extension name

	        String fileExtensionName = fileName.substring(fileName.indexOf("."));

	        //Check condition if the file is xlsx file

	      

	        //Check condition if the file is xls file

	          if(fileExtensionName.equals(".xls")){

	            //If it is xls file then create object of XSSFWorkbook class

	            workbook = new HSSFWorkbook(inputStream);

	        }    

	    //Read excel sheet by sheet name    

	    HSSFSheet sheet = workbook.getSheet(sheetName);

	    //Get the current count of rows in excel file

	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

	    //Get the first row from the sheet

	    Row row = sheet.getRow(0);

	    //Create a new row and append it at last of sheet

	    Row newRow = sheet.createRow(rowCount+1);

	    //Create a loop over the cell of newly created Row

	    for(int j = 0; j < row.getLastCellNum(); j++){

	        //Fill data in row

	        Cell cell = newRow.createCell(j);

	        cell.setCellValue(dataToWrite[j]);

	    }

	    //Close input stream

	    inputStream.close();

	    //Create an object of FileOutputStream class to create write data in excel file

	    FileOutputStream outputStream = new FileOutputStream(file);

	    //write data in the excel file

	    workbook.write(outputStream);

	    //close output stream

	    outputStream.close();
		
	    }
}