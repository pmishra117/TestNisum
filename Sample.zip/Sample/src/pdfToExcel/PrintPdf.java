package pdfToExcel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PrintPdf {
 
    public static void main(String[] args) throws IOException {
    	boolean header=false;
 	   XSSFWorkbook workbook = new XSSFWorkbook();
      	  XSSFSheet sheet = workbook.createSheet( " Employee Info ");
      	    Map <Integer, Object[] > empinfo = null;
      	    
      	  //Create row object
      	      XSSFRow row;
      	      String date = null;
      	        String Date_Narration=null;
      	      String  ChqRefNo  = null;
      	     String  ValueDt  = null;
      	     String  Withdrawal_Amt  = null; 
      	     String  Deposit_Amt   =null;
      	     String   Closing_Balance  = null;
      	   FileOutputStream out = null;
      	  
    	  
        try (PDDocument pdfDocument = PDDocument.load(new File("C:\\PdfBox_Examples\\Sample_Statement.pdf"))) {
 
            pdfDocument.getClass();
 
            if (pdfDocument.isEncrypted()) {
               
             
                PDFTextStripperByArea pdfTextStripperByArea = new PDFTextStripperByArea();
                pdfTextStripperByArea.setSortByPosition(Boolean.TRUE);
 
                PDFTextStripper pdfTextStripper = new PDFTextStripper();
 
                String pdfFileInText = pdfTextStripper.getText(pdfDocument);
               
                String lines[] = pdfFileInText.split("\\r?\\n");
                int count=0;
                for (String line : lines) {
                 String[] data=line.split(" ");
                 
                 
                	 if(null != data[0] &&  null==data[3] && header==true) {
                  		  empinfo.put( count, new Object[] {
                  				Date_Narration+data[1], ChqRefNo, ValueDt,Withdrawal_Amt, Deposit_Amt, Closing_Balance});
                  	  }
                   	 
                 	   
                 	    if(null != data[0] && data[2]!=null && header==true){ 
                 	   date=data[0]; 	Date_Narration=data[1];    ChqRefNo=data[2];  
                 	   if(null==data[4] ||  data[4].isEmpty()) Withdrawal_Amt= 0.0+""; else Withdrawal_Amt =data[4];
                 		  if(null==data[5] || data[5].isEmpty()) Deposit_Amt=0.0+""; else Deposit_Amt =data[5];
                 			  ValueDt=data[3];
                 			 if(null==data[6] || data[6].isEmpty()) Closing_Balance=0.0+""; else Closing_Balance=data[6];
               		  empinfo.put( ++count, new Object[] {
               			date,	Date_Narration, ChqRefNo, ValueDt,Withdrawal_Amt, Deposit_Amt, Closing_Balance});
                    
                     }
                 	   
                 	   if(header!=true &&  !line.isEmpty()) {
                      	 empinfo = new TreeMap <Integer, Object[] >();
                      	 empinfo.put( ++count, new Object[] {
                          		"Date","Date_Narration", "Chq_Ref_No", "Value_Dt","Withdrawal_Amt", "Deposit_Amt", "Closing_Balance"}         	 
                          );
                      	   header=true;
                             
                       }
                }
                
                 	 //Iterate over data and write to sheet
                 	    Set<Integer> keyid = empinfo.keySet();
                 	    int rowid = 0;
                 	    
                 	    for (Integer key : keyid) {
                 	       row = sheet.createRow(++rowid);
                 	       Object [] objectArr = empinfo.get(key);
                 	       int cellid = 0;
                 	       
                 	       for (Object obj : objectArr){
                 	          Cell cell = row.createCell(cellid++);
                 	          cell.setCellValue((String)obj);
                 	       }
                 	    }
                 	    //Write the workbook in file system
                 	    if(out == null) {
                 	    		
                 	    		  out = new FileOutputStream(
                 	       new File("C:\\poiexcel\\Writesheet.xlsx"));
                 	    }
                 	    
                 	    workbook.write(out);
                 	    out.close();
                 	    System.out.println("Writesheet.xlsx written successfully");
                 	  	   }
                 		 
                 
                }
 
            }
 
        }
 
     
 