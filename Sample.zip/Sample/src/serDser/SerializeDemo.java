package serDser;
import java.io.*;
public class SerializeDemo {
		public static void main(String [] args) {
		Employee e = new Employee();
		e.name = "Rahul Jain";
		e.address = "epip, Bangalore";
		e.SSN = 114433;
		e.number = 131;
		try {
		FileOutputStream fileOut =
		new FileOutputStream("C:\\tmp\\employee.ser");
		ObjectOutputStream out = new ObjectOutputStream(fileOut);
		out.writeObject(e);
		out.close();
		fileOut.close();
		System.out.printf("Serialized data saved in /tmp/employee.ser");
		} catch (IOException i) {
		i.printStackTrace();
}
}
}