package Math;

import java.util.Scanner;

public class ArrayDemo {
public static void main(String[] args) {
	int a[]={0,1,0,0,1,1,1,1,0,0,0,1};
	sort(a);
	}

public static void sort(int[]a){
	int c=0;
	int b[]= new int[a.length];
	for(int i=0;i<a.length;i++){
		if(a[i]==0) c++;
		
	}
	for(int i=0;i<a.length;i++){
		if(i<=c){
			b[i]=0;
		
	}
		else {
			b[i]=1;
		}
	
	}
	for(int i=0;i<b.length;i++){
		System.out.println(b[i]);
		
	}
	
	
	
}
}
