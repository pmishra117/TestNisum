package java.Math;
public class PermutationCombination {
public static void main(String[] args) {
	int MOD = (int) (1e9 + 7);
	int  [][] ncr;
	precompute();
	pl(ncr[4892][231]);
}

public PermutationCombination(){
	ncr=new int[5005][5005];
}

static void precompute()
{
	int k;
	for (int i = 0; i < 5001; i++)
	{
		ncr[i][0] = ncr[i][i] = 1;
		k = i >> 1;
		for (int j = 1; j < k + 1; j++)
			ncr[i][j] = ncr[i][i - j] = (ncr[i - 1][j] + ncr[i - 1][j - 1]) % MOD;
	}
}

}
