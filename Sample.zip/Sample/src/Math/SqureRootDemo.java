package Math;

public class SqureRootDemo {
public static void main(String [] args) {
	System.out.println("Squre root is  "+sqrt(10));
}


public static double sqrt(int number) {
	double t;
 
	double squareRoot = number / 2;
 
	do {
		t = squareRoot;
		squareRoot = (t + (number / t)) / 2;
	} while ((t - squareRoot) != 0);
 
	return squareRoot;
}
}
