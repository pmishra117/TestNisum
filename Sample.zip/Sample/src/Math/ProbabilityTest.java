package Math;

public class ProbabilityTest {
public static void main(String[] args) {
	System.out.println(ProbabilityDemo(5));
}

public static double ProbabilityDemo ( int n) {
double x = 1 ;
for ( int i =0; i <n ; i ++) {
x += (365.0- i ) /365.0 ;
}
double pro = Math . round((1-x ) * 100) ;
return pro /100;
}
}
