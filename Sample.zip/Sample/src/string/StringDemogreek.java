package string;

public class StringDemogreek {

public static void main(String[] args) {
	
	String c = "abcd";
			try {
			   c.substring(0);
			}

			catch(Exception e) {
			   //

			} finally{

			   c.substring(1);

			   System.out.println(c); // what will be the output
			}
}
static int a = 1; 
new StringDemogreek().new B().printA();

static class B {
   public void printA() {
      System.out.println("a: "+a);
   }
}
}