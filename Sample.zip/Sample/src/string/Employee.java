package oldJavaDS.string;

import java.io.Serializable;

public class Employee implements Serializable
{
   private String firstName;
   public transient String lastName;
   private static final long serialVersionUID = 5462223600l;
}