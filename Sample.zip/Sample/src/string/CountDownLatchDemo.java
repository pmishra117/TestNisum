package string;

import java.util.concurrent.*;

class DoSomethingInAThread implements Runnable {
	CountDownLatch latch;

	public DoSomethingInAThread(CountDownLatch latch) {
		this.latch = latch;
	}

	public void run() {
		try {
			System.out.println("Do some thing");
			latch.countDown();
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
}

public class CountDownLatchDemo {
	public static void main(String[] args) {
		try {
			int numberOfThreads = 5;
		/*	if (args.length < 1) {
				System.out.println("Usage: java CountDownLatchDemo numberOfThreads");
				return;
			}*/
			try {
				numberOfThreads = Integer.parseInt("3");
			} catch (NumberFormatException ne) {
			}
			CountDownLatch latch = new CountDownLatch(numberOfThreads);
			for (int n = 0; n < numberOfThreads; n++) {
				Thread t = new Thread(new DoSomethingInAThread(latch));
				t.start();
			}
			latch.await();
			System.out.println("In Main thread after completion of " + numberOfThreads + "threads");
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
}