package oldJavaDS;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import geeks.array.SpiralPrintDemo;

public class RefDemo {
	
public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
	getData();
}

public static void getData() throws IllegalArgumentException, IllegalAccessException, InvocationTargetException{
	
	//SpiralPrintDemo SpiralPrintDemo=Class.forName("geeks.array.SpiralPrintDemo").newInstance();
	
	Class obj;
	try {
		obj = Class.forName("geeks.array.SpiralPrintDemo");

		Method [] methods = obj.getMethods();
		

		System.out.println(methods[1].isAccessible());

	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
;