
public class PraseInt {
public static void main(String [] args){
	System.out.print(parseInteger("123"));
}

public static int parseInteger(String stringNumber) {
    int sum=0;
    int position=1;
    for (int i = stringNumber.length()-1; i >= 0 ; i--) {
       int number=stringNumber.charAt(i) - '0';
       sum+=number*position;
       position=position*10;

    }
    return sum;
}
}
