package com.java.core.collection;
import java.util.*;
 
  class Synch {
    // Sleeps for 5 seconds
    private static void do_stuff() {
        try {
            Thread.sleep(5000);
        } catch(InterruptedException e) {}
    }
    public synchronized static void m1() {
        do_stuff();
    }
    public synchronized static void m2() {
        do_stuff();
    }
   
}
  class Task implements Runnable {
	    private void do_stuff() {
	        try {
	            Thread.sleep(5000);
	        } catch(InterruptedException e) {}
	    }
	    public void run() {
	        do_stuff();
	    }
	}
public class OOMDemo {
	/* public static void main(String[] args) {
	        ArrayList<ArrayList<Integer>> array =
	            new ArrayList<ArrayList<Integer>>();
	        for(int i=0; i<10000; i++) {
	            try {
	                array.add(new ArrayList<Integer>(1000000));
	            } catch (OutOfMemoryError e) {
	                System.out.println(i);
	                break;
	            }
	        }*/
	
	
	 public static void main(String[] args) {
	       /* Thread t1 = new Thread() {
	                public void run() {
	                    Synch s = new Synch();
	                    s.m1();
	                }
	            };
	        Thread t2 = new Thread() {
	                public void run() {
	                    Synch s = new Synch();
	                    s.m2();
	                }
	            };
	        t1.start();
	        t2.start();
	        System.out.println("Done");*/
		  Thread[] task_array = {new Thread(new Task()),
                  new Thread(new Task()),
                  new Thread(new Task()),
                  new Thread(new Task())};
task_array[0].start();
task_array[1].start();
task_array[2].start();
task_array[3].start();
System.out.println("Done");
}
	    }
 

 
