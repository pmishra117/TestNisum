/*
 * sort Employe on basis of Name, Salary and joining Date
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
 
//Implement Comparable to sort Employe on basis of Name, Salary and joining Date
class Employe implements Serializable,Comparable<Employe> {
    String name;
    Integer salary;
    Date JoiningDate;
 
    public Employe() {
    }
 
    public Employe(String n, Integer f, Date d) {
           name = n;
           salary = f;
           JoiningDate = d;
    }
 
    public String toString() {
           return "\n name=" + name + ",salary=" + salary + ",JoiningDate="
                        + JoiningDate;
    }
 
    public int compareTo(Employe o) {
           return this.name.compareTo(o.name) + (this.salary.compareTo(o.salary))
                        + (this.JoiningDate.compareTo(o.JoiningDate));
    }
}
 
public class SortingObj {
 
    public static void main(String[] args) {
 
           Employe emp1 = new Employe("ank", 2000, new Date(2016 - 1900, 11, 14));
           Employe emp2 = new Employe("dav", 500, new Date(2016 - 1900, 11, 23));
           Employe emp3 = new Employe("ank", 1000, new Date(2016 - 1900, 11, 22));
           Employe emp4 = new Employe("sam", 9000, new Date(2016 - 1900, 11, 29));
           Employe emp5 = new Employe("ank", 1000, new Date(2016 - 1900, 11, 19));
 
           List<Employe> l = new ArrayList<Employe>();
           l.add(emp1);
           l.add(emp2);
           l.add(emp3);
           l.add(emp4);
           l.add(emp5);
 
           Collections.sort(l); // SORT
 
           System.out.println(l); // Display list
 
    }
 
}
 
/*OUTPUT
 
[
 name=ank,salary=2000,JoiningDate=Wed Dec 14 00:00:00 IST 2016,
 name=ank,salary=1000,JoiningDate=Mon Dec 19 00:00:00 IST 2016,
 name=ank,salary=1000,JoiningDate=Thu Dec 22 00:00:00 IST 2016,
 name=dav,salary=500,JoiningDate=Fri Dec 23 00:00:00 IST 2016,
 name=sam,salary=9000,JoiningDate=Thu Dec 29 00:00:00 IST 2016]
 
*/


