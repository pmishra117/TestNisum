package com.java.core.collection;

import java.util.HashMap;
import java.util.Map;
 


class A {
	public void add() {
		System.out.println("Add");
	}
}

class B extends A {
	public void add(int s) {
		System.out.println("Add in B");
	}
}
public class StupidDemo {
	public static void main(String[] args) {
		//new SortingInSort().sort();
		A a=new B();
		//a. add(2);
	   Map<String,String> map=new HashMap<String,String>();
	   map.put("P","Pradeep");
	   map.put("Q","Qashim");
	   map.put("R","Ram");
	   String str=new String("P");
	   System.out.println(map.get(str));
	   
	}
}
