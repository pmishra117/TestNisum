package geeks;

public class CallDemo {
public static void main(String[] args) {
	//new CallDemo().sort(null);   ambiguows
	new CallDemo().sort(1);
	new CallDemo().sort("ram");
}

void sort(String s){System.out.println("String"); }
void sort(Integer I){System.out.println("Integer"); }
void sort(Object o){ System.out.println("Object");}

}
