package demoJava.string;
class A{
static {
System.out.println("STAT");
}

{
System.out.println("1");
}


public A(){
System.out.println("constructor");
}

{
System.out.println("new ");
}

public void method1(){
System.out.println("method1");
}

}
  class MsLunch {
    private long c1 = 0;
    private long c2 = 0;
    private Object lock1 = new Object();
    private Object lock2 = new Object();

    public void inc1() {
        synchronized(lock1) {
            c1++;
            System.out.println(c1);
        }
    }

    public void inc2() {
        synchronized(lock2) {
            c2++;
            System.out.println(c2);
        }
    }
}

 
public class SynchronizationTest {
public static void main(String[] args) {

A B= new A();
//B.method1();
System.out.println("hello...");
A c = new A();
//c.method1();

MsLunch ms= new MsLunch();

ms.inc1();
ms.inc2();
}
}
