

import java.util.ArrayList;
import java.util.Collections;

class Link1

{
	public int iData; // data item (key)
	public double dData; // data item
	public Link1 next; // next Link1 in list

	public Link1(int id) // constructor
	{
		iData = id; // initialize data
	//	dData = dd; // ('next' is automatically
	} // set to null)

	public void displayLink1() // display ourself
	{
		System.out.print("{" + iData + "} ");
	}
} // end class Link1
// //////////////////////////////////////////////////////////////

class LinkList {
	private Link1 first; // ref to first Link1 on list
	private Link1 last;
	ArrayList<Integer>list1=new ArrayList<Integer>();

	public LinkList() // constructor
	{
		first = null; // no items on list yet
		last = null;
	}

	public boolean isEmpty() // true if list is empty
	{
		return ((first == null)||(last== null));
	}

	// insert at start of list
	public void insertFirst(int id) { // make new Link1
		Link1 newLink1 = new Link1(id);
		newLink1.next = first; // newLink1 --> old first
		first = newLink1; // first --> newLink1
	}
	public void intersect(LinkList l1, LinkList l2){
		Link1 current=l1.first;
		Link1 current1=l2.first;
	 	while(current.next != null){
			int data=current.iData;
					list1.add(data);
					current=current.next;
			
		}
		Collections.sort(list1);
		while(current1.next != null){
			int data=current1.iData;
			if(list1.contains(data)){
				System.out.println("Found...."+data);
			}
			current1=current1.next;
			
		 	
		}
	
	  	
	}
	public void insertLast(int dd) // insert at end of list
	{
	Link1 newLink1 = new Link1(dd); // make new Link1
	if( isEmpty() ) // if empty list,
	{
		first = newLink1; // first --> newLink1
	}
	else
	{
		last.next = newLink1; // old last --> newLink1
	}
	 last = newLink1; // newLink1 <-- last
	}

	public Link1 deleteFirst() // delete first item
	{ // (assumes list not empty)
		Link1 temp = first; // save reference to Link1
		first = first.next; // delete it: first-->old

		return temp; // return deleted Link1
	}

	
	public Link1 insertInSortedList(int iData){
		Link1 current=first;
		Link1 temp=null;
		Link1 newLink=new Link1(iData);
		
		while(current != null) {
			temp=current;
			current=current.next;
			if(temp.iData > iData &&  current.iData <=iData) {
				temp.next=newLink;
				newLink.next=current;
	
			}
		}
			return first;
	}
	
	public void displayList() {
		System.out.print("List (first-->last): ");
		Link1 current = first; // start at beginning of list
		while (current != null) // until end of list,
		{
			current.displayLink1(); // print data
			current = current.next; // move to next Link1
		}
		System.out.println("");
	}
	/* Function to swap Nodes x and y in linked list by
    changing links */
 public Link1 swapNodes(int x, int y)
 {
     // Nothing to do if x and y are same
     if (x == y) return null;

     // Search for x (keep track of prevX and CurrX)
     Link1 prevX = null, currX = first;
     while (currX != null && currX.iData != x)
     {
         prevX = currX;
         currX = currX.next;
     }

     // Search for y (keep track of prevY and currY)
     Link1 prevY = null, currY = first;
     while (currY != null && currY.iData != y)
     {
         prevY = currY;
         currY = currY.next;
     }

     // If either x or y is not present, nothing to do
     if (currX == null || currY == null)
         return null;

     // If x is not head of linked list
     if (prevX != null)
         prevX.next = currY;
     else //make y the new head
         first = currY;

     // If y is not head of linked list
     if (prevY != null)
         prevY.next = currX;
     else // make x the new head
         first = currX;

     // Swap next pointers
     Link1 temp = currX.next;
     currX.next = currY.next;
     currY.next = temp;
     
     return first;
 }
 
 public Link1 swapAdj(){
	 Link1 current=first;
	 Link1 temp=null;;
	 while(current.next!=null){
		 temp=current.next;
		 current=temp;
		 current=current.next;
		 
	 }
	 return first;
 }

	
	 
	 

} // end class Link1List
// //////////////////////////////////////////////////////////////

public class LinkedListDemo {
	public static void main(String[] args) {

		LinkList theList = new LinkList(); // make new list
		theList.insertFirst(11); // insert four items
		theList.insertFirst(22);
		theList.insertFirst(33);
		theList.insertFirst(44);
		theList.insertFirst(66);
		theList.insertFirst(88); 
		 theList.displayList(); // display list
		 
		 theList.insertInSortedList(55);
		 
		 theList.displayList();
		 
		 //Swpping 33 with 66
		  
		 theList.swapNodes(33, 66);
		theList.displayList();
		 
		 // swapiing two adjacent
		 
		 theList.swapAdj();
		 theList.displayList();
		 
		//theList.reverse();
		/*while (!theList.isEmpty()) // until it's empty,
		{
			Link1 aLink1 = theList.deleteFirst(); // delete Link1
			System.out.print("Deleted "); // display it
			aLink1.displayLink1();
			System.out.println("");
		}*/  
		//theList.reverseList(); // display list
	  // end main()
} 
}//

