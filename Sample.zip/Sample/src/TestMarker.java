package geeks;

public interface TestMarker {

}
