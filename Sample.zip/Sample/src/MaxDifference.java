package others;
public class MaxDifference {
	private boolean flag=false;
public static void main(String[] args) {
	int[] A = { 10, 3, 6, 8, 9, 4, 1 };
	int arr1[]={1,2,3,4,5};
	int arr2[]={1,2,3,4,0};
	System.out.println(new MaxDifference().missingNum(arr1,arr2));
}

/*public int solution(int[] A, int N)
	{
	    if (N < 1) return 0;
	    int max = 0;
	    int result = 0;
	    int min=0;
	 
	    for(int i = 0; i <A.length; i++)
	    {
	    	for(int j=1;j<A.length;j++) {
	    		if((A[i]-A[j])>max) {
	    			max=A[i]-A[j];
	    		}
	    		 
	    	}
	    
	}
	    return max;
		 }*/

public int missingNum(int []a,int[]b) {
	for(int i=0;i<a.length;i++){
		for(int j=0;j<b.length;j++) {
			flag=false;
			if(a[i] == b[j]){
				flag=true;
			break;
			}
			else {
				System.out.println("");
			}
		//System.out.println("found"+a[i]);
		} 
		if(flag==false){
			System.out.println("Not found..."+a[i]);
		}
		
	}
	
	return 0;
}

}