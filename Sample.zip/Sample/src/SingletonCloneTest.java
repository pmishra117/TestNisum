package javaXML;
public final class SingletonCloneTest implements Cloneable {

    /**
     * @param args
     * @return
     */
    private static SingletonCloneTest instance = null;

    private SingletonCloneTest() {
     System.out.println("Pradeep Mishra");
    }

    public static SingletonCloneTest getInstance() {

        if (instance == null) {
            instance = new SingletonCloneTest();
            return instance;
        }
        return instance;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {

        // TODO Auto-generated method stub
        /*
         * Here forcibly throws the exception for preventing to be cloned
         */
        throw new CloneNotSupportedException();
        // return super.clone();
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
    	SingletonCloneTest test1 = SingletonCloneTest.getInstance();

        try {
        	SingletonCloneTest test2 = (SingletonCloneTest) test1.clone();
        } catch (CloneNotSupportedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}

