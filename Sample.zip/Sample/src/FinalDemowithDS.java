package geeks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class FinalDemowithDS implements TestMarker{
	int id;
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public final ArrayList al;
	
	public FinalDemowithDS(){
		al= new ArrayList();
	}

	
public static void main(String args[]){
  Map m=new HashMap();
  TestMarker testMarker =new FinalDemowithDS();
  testMarker.getClass();
  
  

  System.out.println(  testMarker.getClass());
  
  
  
}


}
