package geeks;

class ProdConsDemo{
	boolean f;
	int[]a=new int[1];
	public void consume(int i){
		if(f){
			try{
				wait();
				
			}catch(Exception e){}
			 System.out.println("getting"   +a[0]);
			 a[0]=-1;
			 f=true;
			 notifyAll();
		}
	}

public void produce(int i){
	if(f==false){
		try{
			wait();
			
		}catch(Exception e){}
		a[0]=i;
		 System.out.println("putting"   +i);
		 f=false;
		 notifyAll();
	}
}
}
class Prod extends Thread {
	public ProdConsDemo prodConsDemo;
	 public Prod(ProdConsDemo prodConsDemo){
		 this.prodConsDemo=prodConsDemo;
		 }
	 
	 public void run(){
		 for(int i=0;i<5;i++){
			 prodConsDemo.produce(i);
		 }
	 }
	
}

class Cons extends Thread {
	public ProdConsDemo prodConsDemo;
	 public Cons(ProdConsDemo prodConsDemo){
		 this.prodConsDemo=prodConsDemo;
		 }
	 
	 public void run(){
		 for(int i=0;i<5;i++){
			 prodConsDemo.consume(i);
		 }
	 }
}
public class ProdConsumerDemo {
	public static void main(String[] args) {
		ProdConsDemo ProdConsDemo=new ProdConsDemo();
		  Prod p= new Prod(ProdConsDemo);
   Cons c=new Cons(ProdConsDemo);
   p.start();
   c.start();
	}
}
