package util;
public class SyncronizationDemo {
    public static void main(String[] args) throws Exception {
        new Thread(new Runnable() {
            public void run() {
                try {
                	SyncronizationDemo.m1();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
       Thread.sleep(1000);
 
        new Thread(new Runnable() {
            public void run() {
                new SyncronizationDemo().m2();
            }
        }).start();
    }
 
    public static synchronized void m1() throws Exception {
        // The following code is actually synchronized on Test.class object.
        System.out.println("m1 is started...");
        Thread.sleep(2000);
        System.out.println("m1 is completed...");
    }
 
    public void m2() {
        // This code is not synchronized.
    	  synchronized(SyncronizationDemo.class) {
        System.out.println("m2 is working....");
    }
    }}

