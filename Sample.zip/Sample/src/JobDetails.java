package quartz;

public class JobDetails {
private String name;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getJobClass() {
	return jobClass;
}
public void setJobClass(String jobClass) {
	this.jobClass = jobClass;
}
private String jobClass;
}
