import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;


class Perso {    String name;    int age;    Perso(String name, int age) {        this.name = name;      this.age = age;    }     public String toString() {        return name;    }
 

}
public class JavaStreamDemo {
	public static void main(String[] args) {
		

Stream<List<String>> namesOriginalList = Stream.of(
	Arrays.asList("Pankaj"), 
	Arrays.asList("David", "Lisa"),
	Arrays.asList("Amit"));
//flat the stream from List<String> to String stream
Stream<String> flatStream = namesOriginalList
	.flatMap(strList -> strList.stream());

flatStream.forEach(System.out::println);

		List<Perso> persos =
			    Arrays.asList(
			        new Perso("Max", 18),
			        new Perso("Peter", 23),
			        new Perso("Pamela", 23),
			        new Perso("David", 12));
		
		Map<Integer, List<Perso>> personsByAge = persos
			    .stream()
			    .collect(Collectors.groupingBy(p -> p.age));

			personsByAge
			    .forEach((age, p) -> System.out.format("age %s: %s\n", age, p));

	 
	List<String> myList =
		    Arrays.asList("a1", "a2", "b1", "c2", "c1");

		myList
		    .stream()
		    .filter(s -> s.startsWith("c"))
		    .map(word->word.toUpperCase())
		    .sorted()
		    .forEach(System.out::println);
		
		int reduced =
				  IntStream.range(1, 4).reduce(10,(a, b) -> a + b);
		System.out.println(reduced);
}
}