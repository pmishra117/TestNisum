package src.com.demoJava.Ds;

public class BubbleSort {
	  public static void main(String[] args) {
			int number = 10;
			int[] array = new int[]{2,3,5,7,8,10};
			new BubbleSort().getNum(array, number);
		
	    int[] a = new int[] { 2, 6, 3, 8, 4, 9, 1}  ;
	    int[] b = new int[] { 2, 6, 3,7,4,2};
	    int arr[][]={{1,1,1,0,1},{0,0,0,1,1},{0,1,1,1,1},{0,1,1,1,1},{1,1,1,1,1}};
        int count=new BubbleSort().getCount(arr);
	    System.out.println("count "+count);
	    int []c=new BubbleSort().merge(a, b);
	   
	    
	     for (int i : c) {
	      System.out.print(i+" , ");
	    } 
	     }
	  int c=0;
	  int max=0;	  
	  
	  public int getCount(int [][]a){
		  for(int i=0;i<a.length;i++){
			  c=0;
			  int []b=a[i];
			  for(int j=0;j<b.length;j++){
				  if(b[j]==1)
					  c++;
				  }
			  
			  if(max<c){
			  max=c;
			  }
			  
		  }
		  return max;
	  }
	 /*   System.out.println();
	    bubbleSort(intArray);

	    for (int i : intArray) {
	      System.out.print(i);
	    }

	  }

	  public static void bubbleSort(int[] intArray) {
	    int out, in;
	    for (out = intArray.length - 1; out > 0; out--) {
	      for (in = 0; in < out; in++) {
	        if (intArray[in] > intArray[in + 1]) {
	          swap(intArray, in, in + 1);
	        }
	      }
	    }
	  }

	  private static void swap(int[] intArray, int one, int two) {
	    int temp = intArray[one];
	    intArray[one] = intArray[two];
	    intArray[two] = temp;
	  }
	}*/
		public void getNum(int[] arr,int num) {
			
			
			for(int i =0 ;i<arr.length;i++)
			{
		         for(int j=0;j<arr.length;j++) {
		        	 if((arr[i]+arr[j])==num) {
		        		 System.out.println("numbers are "+arr[i]+" , "+arr[j]);
		        		
		        	 }
		         }
		         break; }
		}
	 
		 public int[] merge(int[] a, int[] b) {
				int N = a.length+b.length;
				int [] c = new int[N];

				int count=0;
				for(int i=0;i<a.length;i++) {
					c[count++]=a[i];
					if(count==a.length) {
						for(int j=0;j<b.length;j++) {
							c[count++]=b[j];
						
							if(count==N)
								return c;
					}
				}
				}
				
			
				/*for (int k=0, i=0, j=0; k < N; k++) {
					if (i == a.length)
						c[k] = b[j++];
					else if (j == b.length)
						c[k] = a[i++];
					else if (a[i] > b[j])	
						c[k] = b[j++];
					else
						c[k] = a[i++]; 	
				}
*/
			 
				return c;
		 }	
	 }
	 
 
