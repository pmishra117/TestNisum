package geeks.sortingSearching;

public class MergeSortDemo {
	  public static void main(String[] args) {
		   	        int []a = {2,15,22,47,51};
		  	        int []b = {14,18,26,45,49,56,78};
		   	         
		   	        // Array C of sum of size of the two sorted array A and B
		   	        int []c = new int[a.length+b.length];
		   	         
		   	        merge(a,b,c);
		   	        System.out.print("Array a: ");
		   	        printArray(a);
		   	        System.out.println();
		   	        System.out.print("Array b: ");
		   	        printArray(b);
		   	        System.out.println();
		   	        System.out.print("Array c: ");
		   	        printArray(c);
		   	    }
		   	 
		   	    public static void merge(int []a, int []b, int []c){
		   	        int newA = 0,newB = 0,newC = 0;
		   	        int sizeA = a.length;
		   	        int sizeB = b.length;
		   	         
		   	        // Runs until neither array is empty
		   	        while(newA < sizeA && newB < sizeB){
		   	            // Compare the items of two arrays and copy the smaller item into to third array
		   	            if(a[newA] < b[newB]){
		  	                c[newC++] = a[newA++];
		  	            }else{
		   	                c[newC++] = b[newB++];
		   	            }
		   	        }
		   	         
		   	        // If array B's cursor scanned and compared all the items of the array
		   	        // but array A's is not
		   	        while(newA < sizeA){
		   	            c[newC++] = a[newA++];
		    	        }
		   	         
		   	        // If array A's cursor scanned and compared all the items of the array
		   	        // but array B's is not
		   	        while(newB < sizeB){
		   	            c[newC++] = b[newB++];
		   	        }
		   	    }
		   	     
		   	    public static void printArray(int []array){
		   	        for(int i : array){
		   	            System.out.print(i+" ");
		   	        }
		   	    }
		   	}
 
