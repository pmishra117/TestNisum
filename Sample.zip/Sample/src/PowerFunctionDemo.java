package com.java.Math;

import java.util.Scanner;

public class PowerFunctionDemo {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	int number=sc.nextInt();
	int power=sc.nextInt();
	int value=calculatePower(number,power);
    System.out.println(value);
}

 static int calculatePower(int number,int power) {
	 int multiplication=0;
	for(int i=power;i>=0;i--){
		   if(i==0) {
			 return 1;
		 }
		 else if(i==1) {
			 return number;
		 }
		 else {
			 multiplication=number*number;
		 }
		 power--;
	 }
	 return multiplication;
 }

}
