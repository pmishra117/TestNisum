//package  com.demoJava;
class PrintEvenOdd {
	private boolean flag=false;
	public synchronized void printEven(int i){ 
	 try {
		if(flag==true)
		wait();
	} catch(InterruptedException e){}
		System.out.println("even.."+i);
		notifyAll();
		flag=true;
		
	}
public synchronized void printOdd(int i){ 
	try {
		 if(flag==false)
			  wait();
	}catch(InterruptedException e) {}
	System.out.println("odd.."+i);
	   notifyAll();
       flag=false;
       }
}
class Thread1 extends Thread {
	PrintEvenOdd print;
	
	public Thread1(PrintEvenOdd p) {
		// TODO Auto-generated constructor stub
	   this.print=p;
	}
	 public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++){
			if(i%2 != 0)
			print.printOdd(i);
		}
	}
	 
	
}
class Thread2 extends Thread  {
	PrintEvenOdd print;
		
	public Thread2(PrintEvenOdd p) {
		// TODO Auto-generated constructor stub
	   this.print=p;
	}
 	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++){
			if(i%2 == 0)
				
			print.printEven(i);
		}
	}
	 
	
}
public class Test {
public static void main(String[] args) {
	PrintEvenOdd print=new PrintEvenOdd();
    Thread1 th1 =new Thread1(print);
    Thread2 th2=new Thread2(print);
	    th1.start();
        th2.start();
	 
}
}
