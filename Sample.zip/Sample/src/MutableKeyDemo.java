import java.util.HashMap;
import java.util.Map;

public class MutableKeyDemo {
	
	  private String name;
	  public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void main(String[] args) {
		  MutableKeyDemo test = new MutableKeyDemo();
	        test.testMutableKey();
	    }
	  
	  public void testMutableKey(){
	        Map testMap = new HashMap();
	        MutableKeyDemo mutableKey = new MutableKeyDemo();
	        mutableKey.setName("TestName");
	        testMap.put(mutableKey, new Object());
	        Object o = testMap.get(mutableKey);
	        System.out.println("before changing key = " + o);
	        mutableKey.setName("abc");    
	        o = testMap.get(mutableKey);
	        System.out.println("after changing key = " + o);
	    }


}
