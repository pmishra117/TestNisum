package geeks;

class EvenOddPrinting {
	public volatile boolean flag;

	public synchronized void printeven(int i) {
		try {
			if (flag == false) {
				wait();
			}
		} catch (InterruptedException e) {
		}
		System.out.println("even.." + i);
		notifyAll();
		flag = false;
	}

	public synchronized void printOdd(int i) {
		try {
			if (flag == true) {
				wait();
			}
		} catch (InterruptedException e) {
		}
		System.out.println("odd.." + i);
		notifyAll();
		flag = true;
	}
}

// In case of Accessing same instance by multiple thread we need to write a
// class by implementing runnable

class Threads implements Runnable {
	EvenOddPrinting evenOddPrinting;

	public Threads(EvenOddPrinting c) {
		this.evenOddPrinting = c;
	}

	public void run() {
		for (int i = 1; i < 11; i++) {
			if (i % 2 == 0)
				evenOddPrinting.printeven(i);
			else
				evenOddPrinting.printOdd(i);
		}
	}
}

public class EvenOdd {

	public static void main(String[] args) {
		EvenOddPrinting evenOddPrinting = new EvenOddPrinting();
		Threads th = new Threads(evenOddPrinting);
		Thread eventhread = new Thread(th);
		Thread oddthread = new Thread(th);

		eventhread.start();
		oddthread.start();
	}
}
