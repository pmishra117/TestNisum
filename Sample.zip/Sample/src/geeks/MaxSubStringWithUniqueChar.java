package geeks;

import java.util.HashMap;

public class MaxSubStringWithUniqueChar {
public static void main(String[] args) {
	String input="pmishrapkmishra";
	System.out.println(maxSubString(input));
}
static int maxSubString(String input) {
	HashMap<Character,Integer>map=new HashMap<Character,Integer>();
	int max = 0;
	for(int i=0,j=0;i<input.length();++i) {
		if(map.containsKey(input.charAt(i))) {
			j=Math.max(j, map.get(input.charAt(i))+1);
		}
		map.put(input.charAt(i),i);
		max=Math.max(max,i-j+1);
	}
	return max;
}


}
