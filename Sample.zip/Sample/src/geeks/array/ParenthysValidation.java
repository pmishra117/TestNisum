package geeks.array;

import java.util.Stack;

public class ParenthysValidation {
public static void main(String[] args) {
	String str1="({))",str2="[{()}]",str3="{[]}";
	
	 System.out.println(Validate(str1));
	// System.out.println(Validate(str2));
	//System.out.println(Validate(str3));
}

private static String Validate(String str1) {
	
  if(str1==null || str1.length()==0) return null;
	int lenght=str1.length();
	Stack<Character> st= new Stack<Character>();
	 for(int i=0;i<lenght/2;i++) {
		 if(str1.charAt(i)=='{' || str1.charAt(i)=='('  || str1.charAt(i)==']') {
			 st.push(str1.charAt(i));
		 }
	 }
		 for(int j=lenght/2;j<lenght;j++) {
			 Character poped=st.pop();
			 if (poped == '(' && str1.charAt(j) == ')') 
		        continue; 
		       else if (poped == '{' && str1.charAt(j) == '}') 
		    	   continue; 
		       else if (poped == '[' && str1.charAt(j) == ']') 
		    	   continue; 
		       else
		         return "No"; 
		    } 
			 
	 	 if(st.isEmpty())  return "YES";
		 else return "No";
		
}
}
