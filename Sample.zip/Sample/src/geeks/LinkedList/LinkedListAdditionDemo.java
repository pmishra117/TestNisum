package geeks.LinkedList;

class Link{
	public int iData; // data item (key)
	public double dData; // data item
	public Link next; // next link in list
	public Link(int id) 	{	iData = id;		}
	public void displayLink() {	System.out.print("{" + iData + "} ");
	}
}
class LinkedList {
	Link first;
	public LinkedList(){
		first=null;
	}
	public void addFirst(int iData){
		Link newLink=new Link(iData);
		if(first==null) {
			first=newLink;
			return;
		}
		else {
			Link current=first;
			newLink.next=current;
			first=newLink;
		}
	}
	
	public void addInSortedList(int iData){
		Link newLink=new Link(iData);
		Link current=first;
		Link prev=null;
		
		while(current != null){
			if(current.iData >iData){
			prev=current;
			current=current.next;
		}
	
		newLink.next=current;
		prev.next=newLink;
		//return first; 
	}
	}
	
	public Link reverse() {
		Link prev=null;
		Link current=first;
		Link nextNode=null;
		while(current != null){
			nextNode=current.next;
			current.next=prev;
			prev=current;
			current=nextNode;
			
		}
		return prev;
		
				
	}
	public void display() {
		Link current=first;
		while(current!=null){
			current.displayLink();
			current=current.next;
		}
	}		

}

public class LinkedListAdditionDemo {
public static void main(String[] args) {
  LinkedList ll=new LinkedList();
  ll.addFirst(11);  ll.addFirst(22);  ll.addFirst(33);  ll.addFirst(55);  ll.addFirst(66);  ll.addFirst(88);  ll.display();
  Link lReverse=ll.reverse();lReverse.displayLink();
  
}
}
