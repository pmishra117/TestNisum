package geeks.LinkedList;

public class MergingLinkedList {
	public static void main(String[] args) {
		LinkedList l1=new LinkedList();
		LinkedList l2=new LinkedList();
		l1.addFirst(1);l1.addFirst(3);l1.addFirst(5);l1.addFirst(7);l1.addFirst(9);
		l1.display();
		l2.addFirst(2);l2.addFirst(4);l2.addFirst(6);l2.addFirst(8);l2.addFirst(10);
		l2.display();
		
		Link revS=merge(l1.first, l2.first);
		System.out.println("After merge   ");
		displayData(revS);
	    
		
	}

		public static Link merge(Link headA, Link headB) {
		     // This is a "method-only" submission. 
		     // You only need to complete this method 
		    if (headA == null)
		        return headB;
		    else if (headB == null)
		        return headA;
		    else if (headA.iData <= headB.iData){
		        headA.next = merge(headA.next, headB);
		        return headA;
		    } else {
		        headB.next = merge(headA, headB.next);
		        return headB;
		    }
		}
	  
	public static Link reverseToSpecificLen(LinkedList head,int n){
		Link link=head.first;
		Link prev=null;
		int ptr=1;
		while(link != null){
			if(ptr==n){
				Link rev =reverse(link);
				prev.next=rev;
				break;
			}
			prev=link;
			link =link.next;
			ptr++;
		}
		System.out.println(link);
		return prev;
	}

	public static Link reverse(Link ll) {
		Link prev=null;
		Link current=ll;
		Link next=null;
		while(current != null){
			next=current.next;
			current.next=prev;
			prev=current;
			current=next;
		}
		return prev;
	}

	public static void displayData(Link ll){
		while(ll != null) {
			System.out.println(ll.iData); 
			ll=ll.next;
			
		}
	}
	}

