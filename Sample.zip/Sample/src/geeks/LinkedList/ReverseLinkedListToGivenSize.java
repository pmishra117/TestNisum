package geeks.LinkedList;

import java.util.LinkedList;

public class ReverseLinkedListToGivenSize {
public static void main(String[] args) {
	LinkedList ll=new LinkedList();
	ll.addFirst(11);	ll.addFirst(12);	ll.addFirst(13);	ll.addFirst(14);	ll.addFirst(15);
	ll.addFirst(21);	ll.addFirst(22);	ll.addFirst(23);	ll.addFirst(24);	ll.addFirst(25);
	ll.display();
	Link revS=reverseToSpecificLen(ll, 4);
	System.out.println("After call");
	displayData(revS);
}

public static Link reverseToSpecificLen(LinkedList head,int n){
	Link link=head.first;
	Link prev=null;
	int ptr=1;
	while(link != null){
		if(ptr==n){
			Link rev =reverse(link);
			prev.next=rev;
			break;
		}
		prev=link;
		link =link.next;
		ptr++;
	}
	System.out.println(link);
	return prev;
}

public static Link reverse(Link ll) {
	Link prev=null;
	Link current=ll;
	Link next=null;
	while(current != null){
		next=current.next;
		current.next=prev;
		prev=current;
		current=next;
	}
	return prev;
}

public static void displayData(Link ll){
	while(ll != null) {
		System.out.println(ll.iData); 
		ll=ll.next;
		
	}
}
}
