package geeks.LinkedList;


public class AddingNumberLinkedList {

	private static class Node
	{
	   int data;
	   Node next;
	   Node(int d) {data = d; next = null; }
	 
	}

	 

  Node root;


	public static void main(String args[])
	{
		 Node node1  = new Node(1);
		   node1.next = new Node(2);
		   node1.next.next = new Node(3);
		   
		   Node node2  = new Node(2);
		   node2.next = new Node(3);
		   node2.next.next = new Node(4);
		
		 addition(node1,node2);	   
	     
	 
	}
	
	static Node addition(Node n1,Node n2) {
		System.out.println("Original   ");
		display(n1);
		System.out.println("Reverse....");
		Node node1=reverse(n1);
	    display(node1);
		System.out.println("Original   ");
		display(n2);
		Node node2=reverse(n2);
		System.out.println("Reverse....");
	    display(node2);
		//LOGIC FOR ADDITION
        Node res=new Node(0);
        
        while(node1 !=null && node2 !=null) {
        	int sum=node1.data+node2.data;
        	res=new Node(sum);
        	res=res.next;
        	
        	node1=node1.next;
        	node2=node2.next;
        }
	    
	    
	    //END
	    
	    return null;
	}
	
	static Node reverse(Node data) {
		Node current=data;
		Node prev=null;
		Node next=null;
		
		while(current!= null) {
			next=current.next;
			current.next=prev;
			prev=current;
			current=next;
		}
		return prev;
	}
	
	static void display(Node data) {
		Node current=data;
		while(current!=null) {
			System.out.print(current.data+"-->");
			current=current.next;
		}
		System.out.println();
	}

}
