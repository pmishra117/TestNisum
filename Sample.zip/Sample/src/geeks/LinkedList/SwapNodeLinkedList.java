package geeks.LinkedList;

public class SwapNodeLinkedList {
public static void main(String[] args) {
	Link l=new Link(1);
    l.next=new Link(2);
    l.next.next=new Link(3);
    l.next.next.next=new Link(4);
    l.next.next.next.next=new Link(5);
  //  l.next.next.next.next.next=new Link(62);
   // l.next.next.next.next.next.next=new Link(18);
       display(l);  
       swap(2,4,l);
       display(l);
}

/* public void pairWiseSwap()
{
    Link temp = head;

    while (temp != null && temp.next != null) {

        int k = temp.data;
        temp.data = temp.next.data;
        temp.next.data = k;
        temp = temp.next.next;
     }
} */


public static void display(Link ll){
	while(ll != null){
		System.out.print(ll.iData+"  ");
		ll=ll.next;
	}
}

public static void swap(int data1,int data2,Link l){
	if(data1==data2) {return; }
	else{
		Link prevFirst=null;
		Link currX=l;
		while(currX.next != null && currX.iData != data1) {
			prevFirst=currX;
			currX=currX.next;
		}
		
		Link prevSecond=null;
		Link currY=l;
		while(currY.next != null && currY.iData != data2) {
			prevSecond=currY;
			currY=currY.next;
		}
		
		 // If either x or y is not present, nothing to do
        if (currX == null || currY == null)
            return;
 
        // If x is not head of linked list
        if (currX != null)
            currX.next = currY;
        else //make y the new head
            l = currY;
 
        // If y is not head of linked list
        if (prevSecond != null)
        	prevSecond.next = currX;
        else // make x the new head
            l = currX;
 
        // Swap next pointers
        Link temp = currX.next;
        currX.next = currY.next;
        currY.next = temp;
    }
}
		
	
}

