package geeks.LinkedList;
import java.util.HashMap;
import java.util.Map;

	 
	class LinkedList11 {
	 
	    static Node head1, head2;
	    static Map<String,String>mapData=new HashMap<String,String>();
	 
	    static class Node {
	 
	        int data;
	        Node next;
	 
	        Node(int d) {
	            data = d;
	            next = null;
	        }
	    }
	 
	    /*function to get the intersection point of two linked
	    lists head1 and head2 */
	    Node getNode() {
	        int c1 = getCount(head1);
	        int c2 = getCount(head2);
	        int d;
	 
	        if (c1 > c2) {
	            d = c1 - c2;
	            return _getUnionList(d, head1, head2); }
	       /* } else {
	            d = c2 - c1;
	            return _getIntesectionNode(d, head2, head1);
	        }*/
	        return null;
	    }
	 
	    /* function to get the intersection point of two linked
	     lists head1 and head2 where head1 has d more nodes than
	     head2 */
	    Node  _getUnionList(int d, Node node1, Node node2) {
	        int i;
	        Node current1 = node1;
	        Node current2 = node2;
	    
	        
	        while(current1 !=null){
	      mapData.put(current1.data+"", "value");
	      current1=current1.next;
	       }
	       
	       
	        while (current2 != null) {
	        	   System.out.println("current2"+current2.data);
	   	    	
	            if (!mapData.containsKey(current2.data+"")) {
	            	 mapData.put(current2.data+"", "value");
	                //return current2.data;
	            }
	            //current1 = current1.next;
	            current2 = current2.next;
	        }
	 
	        return (Node) mapData;
	    }
	 
	    /*Takes head pointer of the linked list and
	    returns the count of nodes in the list */
	    int getCount(Node node) {
	        Node current = node;
	        int count = 0;
	      
	        while (current != null) {
	           count++;
	            current = current.next;
	        }
	 
	        return count;
	    }
	}
	
	public class UnionOfLinkedList {
		// Java program to get intersection point of two linked list

	    public static void main(String[] args) {
	        LinkedList1 list = new LinkedList1();
	 
	        // creating first linked list
	        list.head1 = new geeks.LinkedList.LinkedList1.Node(3);
	        list.head1.next = new geeks.LinkedList.LinkedList1.Node(6);
	        list.head1.next.next = new geeks.LinkedList.LinkedList1.Node(15);
	        list.head1.next.next.next = new geeks.LinkedList.LinkedList1.Node(25);
	        list.head1.next.next.next.next = new geeks.LinkedList.LinkedList1.Node(30);
	 
	        // creating second linked list
	        list.head2 = new geeks.LinkedList.LinkedList1.Node(10);
	        list.head2.next = new geeks.LinkedList.LinkedList1.Node(6);
	        list.head2.next.next = new geeks.LinkedList.LinkedList1.Node(30);
	 
	        System.out.println("The Union of two linkedlist is " + list.getNode());
	 
	    }
	}


