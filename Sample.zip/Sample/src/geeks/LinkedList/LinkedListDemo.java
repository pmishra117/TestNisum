package geeks.LinkedList;



public class LinkedListDemo {
private static class Link{
public int val; // data item (key)
public Link next; // next Link in list
public Link(int id) { val = id; }
public static void displayLink(Link ll) {
// TODO Auto-generated method stub
}
 
}
public static void main(String[] args) {
Link ll=new Link(12);ll.next=new Link(13);ll.next.next=new Link(14);ll.next.next.next=new Link(15);
displayLink(ll);
 
//Delete element other than front or rear
 
System.out.println("After deleting........."+delete(ll,13));
displayLink(ll);
Link l2=new Link(22);l2.next=new Link(33);l2.next.next=new Link(11);l2.next.next.next=new Link(15);
//System.out.println(nthFromEndInN(ll,2));
//int point =new LinkedListDemo().getIntersectionLink(ll, l2).val;
// System.out.println(point);
 
}

public static Link delete(Link root,int data) {
	Link current=root;
	Link prev=null;
	while(current != null) {
		if(current.val==data) {
			prev.next=current.next;
			prev=root;
			return prev;
		}
		prev=current;
		current=current.next;
		
	}
	return prev;
}

public  Link getIntersectionLink(Link headA, Link headB) {
    int len1 = 0;
    int len2 = 0;
    Link p1=headA, p2=headB;
    if (p1 == null || p2 == null)  return null;

 /*   while(p1 != null){ len1++; p1 = p1.next;  }
    while(p2 != null){ len2++; p2 = p2.next;  }

    int diff = 0;
    p1=headA;  p2=headB;

    if(len1 > len2){
        diff = len1-len2;
        int i=0;
        while(i<diff){
            p1 = p1.next;
            i++;
        }
    }else{
        diff = len2-len1;
        int i=0;
        while(i<diff){
            p2 = p2.next;
            i++;
        }
    }*/

    while(p1 != null && p2 != null){
        if(p1.val == p2.val){
            return p1;
        }else{

        }
        p1 = p1.next;
        p2 = p2.next;
    }

    return null;
}
public static int nthFromEndInN(Link Link,int ele) {
Link ptr1=Link;
Link ptr2=Link;
int data=0;
int length=0;
while(ptr2 != null) {
ptr2=ptr2.next;
++length;
if(ptr2==null ) {
int elementItr=length-ele;
while(elementItr>0) {
ptr1=ptr1.next;
--elementItr;
}
  data= ptr1.val; 
}
}
return data;
}

private static void displayLink(Link node) {
Link current=node;
while(current!= null) {
System.out.print(current.val+"  -->");
current=current.next;
}
}

}
