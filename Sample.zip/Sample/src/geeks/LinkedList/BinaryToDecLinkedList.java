package geeks.LinkedList;
 
public class BinaryToDecLinkedList {
	 
 
/* Linked list Node*/
private static class Node
{
   int data;
   Node next;
   Node(int d) {data = d; next = null; }
 
}

 



/* Drier program to test above functions */
public static void main(String args[])
{
	 Node node  = new Node(1);
	   node.next = new Node(0);
	   node.next.next = new Node(1);
	   node.next.next.next = new Node(1);
	   
   
      System.out.println("Converting Binary To Decimal  "+BinaryToDec(node));
 
}



private static int BinaryToDec(Node node) {
	Node current=node;
	
	int sum=0;
	int i=0;
	while(current != null) {
		//(current.data)*((int) Math.pow(2,i++))+sum;
	 	sum=sum*10+current.data;
		current=current.next;
	}
	// TODO Auto-generated method stub
	return Integer.parseInt(sum+"",2);
}
   
}
 
