package geeks.LinkedList;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

import geeks.sortingSearching.MergeKLists;

public class MergeTwoSortedLinkedList {
	public Node root;

	private static class Node {

		int data;
		Node next;

		public Node(int item) {
			data = item;

		}
	}

	public static void main(String[] args) {
    	Node ll = new Node(1);
		ll.next = new Node(4);
		ll.next.next = new Node(7);
		 
		Node l2 = new Node(2);
		l2.next = new Node(6);
		l2.next.next = new Node(10);
		ll.next.next.next = new Node(14);
		
		Node l3 = new Node(3);
		l3.next = new Node(6);
		l3.next.next = new Node(9);
		l3.next.next.next = new Node(11);
		 
		Node merged = merge(ll, l2);
		System.out.println("...............After merging .....");
		
	    display(merged);
		System.out.println("...............After deleting duplicates.....");
		Node unique = distinctLinkedList(merged);
		ArrayList<Node> list=new ArrayList<Node>(3);
		   list.add(ll);list.add(l2);list.add(l3);
			
		display(unique);
		
		//Merger K
		

		Node mergedK = mergeKLists(list.toArray());
		display(mergedK);
	}

	public static Node merge(Node l1, Node l2) {
		if (l1 == null)
			return l2;
		if (l2 == null)
			return l1;
		if (l1.data <= l2.data) {
			l1.next = merge(l1.next, l2);
			return l1;
		}

		else {
			l2.next = merge(l1, l2.next);
			return l2;
		}
	}
	
	
	public static Node mergeKLists(Object[] lists) {
	    if(lists==null||lists.length==0)
	        return null;
	 
	    PriorityQueue<Node> queue = new PriorityQueue<Node>(new Comparator<Node>(){
	        public int compare(Node l1, Node l2){
	            return l1.data - l2.data;
	        }
	    });
	 
	    Node head = new Node(0);
	    Node p = head;
	 
	    for(Object list: lists){
	        if(list!=null) 
	            queue.offer((Node)list);
	        
	    }    
	 
	    while(!queue.isEmpty()){
	        Node n = queue.poll();
	        p.next = n;
	        p=p.next;
	 
	        if(n.next!=null)
	            queue.offer(n.next);
	    }    
	 
	    return head.next;
	 
	}
	
	public static Node distinctLinkedList(Node list) {
		 
	        /*Another reference to head*/
	        Node current = list; 
	         while(current.next != null) {
	    	   if(current.data==current.next.data) {
	         	current.next=current.next.next;
	           }
	     	   else
	       	current=current.next;
	     
	       }
	       return list;
	}
	
	public static void display(Node n) {
		while (n != null) {
			System.out.print("  "+ n.data);
			n = n.next;
		}
		System.out.println();
	}

}
