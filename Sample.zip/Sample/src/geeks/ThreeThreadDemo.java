package geeks;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ThreeThreadDemo {

    Semaphore lock1=new Semaphore(0);
    Semaphore lock2=new Semaphore(0);
    Semaphore lock3=new Semaphore(1);
    
    private ArrayList<Integer>list1=new ArrayList<Integer>();
    private ArrayList<Integer>list2=new ArrayList<Integer>();
    private ArrayList<Integer>list3=new ArrayList<Integer>();
    
    private void init()
    {
        int[] a={1,2,3,4,5,6,7};
        for(int i:a)
            list1.add(i);
        
        int[] b={11,22,33,44,55,66,77};
        for(int i:b)
            list2.add(i);
        
        int[] c={111,222,333,444,555,666,777};
        for(int i:c)
            list3.add(i);
        
        
    }
    
    public ThreeThreadDemo()
    {
        init();
    }
    
    
    
    public void first(int index) throws InterruptedException
    {
    
        lock3.acquire();
        try{
            
        Thread.sleep(1000);    
        System.out.println("First"+list1.get(index));
        }
        finally{
        lock1.release();
    }
}

    public void second(int index) throws InterruptedException
    {
        lock1.acquire();
        try{
            Thread.sleep(1000);
        System.out.println("Second"+list2.get(index));
        }
        finally{
        lock2.release();
        }
        
    }

    
    public void third(int index) throws InterruptedException
    {
        lock2.acquire();
        try{
            Thread.sleep(100);
        System.out.println("Third"+list3.get(index));
        }
        finally{
        lock3.release();
        }
        
    }
    public static void main(String [] args) throws InterruptedException
    {
        final ThreeThreadDemo semaphore=new ThreeThreadDemo();
        
        Thread one=new Thread(new Runnable() {
            int index=0;
             public void run() {
                try { for(int i=1;i<5;i++){ semaphore.first(index++);} } catch (InterruptedException e) {  e.printStackTrace(); }
                           
            }
        });
        
        Thread two=new Thread(new Runnable() {
            int index=0;
            public void run() {
            
                try { for(int i=1;i<5;i++){ semaphore.second(index++);} } catch (InterruptedException e) {  e.printStackTrace(); }
                
            }
        });
        
        Thread three=new Thread(new Runnable() {
            int index=0;
            public void run() {
            
                try { for(int i=1;i<5;i++){ semaphore.third(index++);} } catch (InterruptedException e) {  e.printStackTrace(); }
                
               }
        });
        
        one.start();
        two.start();
        three.start();
       // one.join();
       // two.join();
       // three.join();
    
    }
}
