package geeks.tree;

	// A binary tree node
	class Nodee {
	     
	    int data;
	    Nodee left, right;
	     
	    Nodee(int d) {
	        data = d;
	        left = right = null;
	    }
	}
	 
	class BinaryTreeD {
		    static Nodee root;
	 
	    /* A function that constructs Balanced Binary Search Tree 
	     from a sorted array */
	    Nodee sortedArrayToBST(int arr[], int start, int end) {
	 
	        /* Base Case */
	        if (start > end) {
	            return null;
	        }
	 
	        /* Get the middle element and make it root */
	        int mid = (start + end) / 2;
	        Nodee node = new Nodee(arr[mid]);
	 
	        /* Recursively construct the left subtree and make it
	         left child of root */
	        node.left = sortedArrayToBST(arr, start, mid - 1);
	 
	        /* Recursively construct the right subtree and make it
	         right child of root */
	        node.right = sortedArrayToBST(arr, mid + 1, end);
	         
	        return node;
	    }
	    
	  
	   
	 
	    /* A utility function to print preorder traversal of BST */
	    void preOrder(Nodee node) {
	        if (node == null) {
	            return;
	        }
	        System.out.print(node.data + " ");
	        preOrder(node.left);
	        preOrder(node.right);
	    }
	     
	    
	    void postOrder( Nodee node){
	    	
	    	if(node ==null) return;
	    	
	    	postOrder(node.right);
	    	postOrder(node.left);
	    	
	    	System.out.print(node.data+"  ");
	    }
	    
	    Nodee mirror(Nodee node)
	    {
	        if (node == null)
	            return node;
	 
	        /* do the subtrees */
	        Nodee left = mirror(node.left);
	        Nodee right = mirror(node.right);
	 
	        /* swap the left and right pointers */
	        node.left = right;
	        node.right = left;
	 
	        return node;
	    }
	    
	    static  boolean find(Nodee node, int data)
	    {
	        if (node == null)
	            return false;
	 
	        /* do the subtrees */
	        
	        if(node.data== data) return true;
	        
return (find(node.left,data)|| find(node.right,data));
	    }
	
	}
	
	
	public class BinaryTreeCreation {
		  public static void main(String[] args) {
		        BinaryTreeD tree = new BinaryTreeD();
		        int arr[] = new int[]{1, 2, 3, 4, 5, 6, 7};
		        int n = arr.length;
		        
		        //sortedArrayToBST recursively
		     Nodee root = tree.sortedArrayToBST(arr, 0, n - 1);
		
		     //Searhing in Tree
		        
		        boolean found = BinaryTreeD.find(root,40);
		        System.out.println(found);
		        //Mirror Image of Tree
		       Nodee image = tree.mirror(root);
		       
		        System.out.println("Preorder traversal of constructed BST");
		       tree.preOrder(image);
		        
		      //  System.out.println("Post traversal of constructed BST");
		      //  tree.postOrder(root);
		    }
	}
