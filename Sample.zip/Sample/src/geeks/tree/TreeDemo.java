package geeks.tree;

import java.util.LinkedList;
import java.util.Queue;

public class TreeDemo {

  private static class Node {
	int iData;
 	
	public Node(int data) {
		this.iData=data;
	}
	Node leftChild;
	Node rightChild;
	
}

static class Tree {
	public Node root; // the only data field in Tree

	public Node getRoot() {
		return root;
	}
 

	public Node find(int key) {
		Node current = root; // start at root
		while (current.iData != key) // while no match,
		{
			if (key < current.iData) // go left?
				current = current.leftChild;
			else
				current = current.rightChild; // or go right?
			if (current == null) // if no child,
				return null; // didn't find it
		}
		return current; // found it
	}

	public void insert(int id) {
		Node newNode = new Node(1); // make new node
		newNode.iData = id; // insert data
	 	if (root == null) // no node in root
			root = newNode;
		else // root occupied
		{
			Node current = root; // start at root
			Node parent;
			while (true) // (exits internally)
			{
				parent = current;
				if (id < current.iData) // go left?
				{
					current = current.leftChild;
					if (current == null) // if end of the line,
					{ // insert on left
						parent.leftChild = newNode;
						return;
					}
				} // end if go left
				else // or go right?
				{
					current = current.rightChild;
					if (current == null) // if end of the line
					{ // insert on right
						parent.rightChild = newNode;
						return;
					}
				} // end else go right
			} // end while
		} // end else not root
	}

	public void delete(int id) {
	}
	// various other methods
	
	public static  int countLeftNodes(Tree theTree){
	 	int count=0;
	 	Node current=theTree.root;
		while(current.leftChild != null){
			count++;
			current=current.leftChild;
		}
		return count;
	}
	
	public static   int countAllNodes(Tree theTree){
	 	int count=0;
		Node current=theTree.root;
		Node current1=theTree.root;
		
		while(current.leftChild != null){
			count++;
			current=current.leftChild;
		}
		while(current1.rightChild != null){
			count++;
			current1=current1.rightChild;
		}
		return count;
	}
	
	public Node addElementInTree(int data) {
		if(root == null) return null;
		Queue<Node> queue =new LinkedList<Node>();
		queue.add(root);
		while(!queue.isEmpty()) {
			Node tmp =queue.poll();
			if(tmp.leftChild != null) queue.add(tmp.leftChild);
			else {
				Node newNode= new Node(data);
				tmp.leftChild=newNode;
				return root;
				
			}
			
			if(tmp.rightChild != null) queue.add(tmp.rightChild);
			else {
				Node newNode= new Node(data);
				tmp.rightChild=newNode;
				return root;
				
			}
		}
		
		return root;
	}

}


	public static void main(String[] args) {
		Tree theTree = new Tree(); // make a tree
		theTree.insert(5); // insert 3 nodes
		theTree.insert(25);
		
	 	theTree.insert(75);
		 
		int count=Tree.countLeftNodes(theTree);
		System.out.println("No of left Nodes are..."+count);
		
		int counta=Tree.countAllNodes(theTree);
		System.out.println("No of total  Nodes are..."+counta);
	
		/*Node found = theTree.find(25); // find node with key 25
		if (found != null)
			System.out.println("Found the node with key 25");
		else
			System.out.println("Could not find node with key 25");
	} */// end main()
		
	 theTree.addElementInTree(20);
	 			 int countb=Tree.countAllNodes(theTree);
			System.out.println("No of total Nodes after Adding are..."+countb);
		
   } 
	}
