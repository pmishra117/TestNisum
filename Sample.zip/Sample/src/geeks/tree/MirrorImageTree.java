package geeks.tree;

	// Java program to convert binary tree into its mirror
	 
	/* Class containing left and right child of current
	   node and key value*/
	class Noda
	{
	    int data;
	    Noda left, right;
	 
	    public Noda(int item)
	    {
	        data = item;
	        left = right = null;
	    }
	}
	 
	class BinaryTrea
	{
	    Noda root;
	 
	    void mirror()
	    {
	        root = mirror(root);
	    }
	 
	    Noda mirror(Noda node)
	    {
	        if (node == null)
	            return node;
	 
	        /* do the subtrees */
	        Noda left = mirror(node.left);
	        Noda right = mirror(node.right);
	 
	        /* swap the left and right pointers */
	        node.left = right;
	        node.right = left;
	 
	        return node;
	    }
	 
	    void inOrder()
	    {
	        inOrder(root);
	    }
	 
	    /* Helper function to test mirror(). Given a binary
	       search tree, print out its data elements in
	       increasing sorted order.*/
	    void inOrder(Noda node)
	    {
	        if (node == null)
	            return;
	 
	        inOrder(node.left);
	        System.out.print(node.data + " ");
	 
	        inOrder(node.right);
	    }
	}
	    public class MirrorImageTree  {
	    /* testing for example nodes */
	    public static void main(String args[])   {
	        /* creating a binary tree and entering the nodes */
	        BinaryTrea tree = new BinaryTrea();
	        tree.root = new Noda(1);
	        tree.root.left = new Noda(2);
	        tree.root.right = new Noda(3);
	        tree.root.left.left = new Noda(4);
	        tree.root.left.right = new Noda(5);
	 
	        /* print inorder traversal of the input tree */
	        System.out.println("Inorder traversal of input tree is :");
	         tree.inOrder();
	        System.out.println("");
	 
	        /* convert tree to its mirror */
	        tree.mirror();
	 
	        /* print inorder traversal of the minor tree */
	        System.out.println("Mirror traversal of binary tree is : ");
	        tree.inOrder();
	 
	    }
	
}
