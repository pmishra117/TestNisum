package geeks.tree;

//Java program to find sum of all left leaves
class NodeS {
	int data;
	NodeS left, right;

	NodeS(int item) {
		data = item;
		left = right = null;
	}
}

// Passing sum as accumulator and implementing pass by reference
// of sum variable
class Sum {
	int sum = 0;
}

class BinaryTreee {
	NodeS root;

	/* Pass in a sum variable as an accumulator */
	void leftLeavesSumRec(NodeS node, boolean isleft, Sum summ) {
		if (node == null)
			return;

		// Check whether this node is a leaf node and is left.
		if (node.left == null && node.right == null && isleft)
			summ.sum = summ.sum + node.data;

		// Pass true for left and false for right
		leftLeavesSumRec(node.left, true, summ);
		leftLeavesSumRec(node.right, false, summ);
	}

	// A wrapper over above recursive function
	int leftLeavesSum(NodeS node) {
		Sum suum = new Sum();

		// use the above recursive function to evaluate sum
		leftLeavesSumRec(node, false, suum);

		return suum.sum;
	}
}

public class SumOfLeafBinaryTree {

	// Driver program
	public static void main(String args[]) {
		BinaryTreee tree = new BinaryTreee();
		tree.root = new NodeS(1);
		tree.root.left = new NodeS(2);
		tree.root.right = new NodeS(3);
		tree.root.left.right = new NodeS(4);
		tree.root.left.left = new NodeS(5);
		tree.root.right.left = new NodeS(6);
		//tree.root.right.right = new NodeS(7);
		//tree.root.left.right.right = new NodeS(8);
		//tree.root.right.right.left = new NodeS(9);

		System.out.println("The sum of leaves is " + tree.leftLeavesSum(tree.root));
	}
}
