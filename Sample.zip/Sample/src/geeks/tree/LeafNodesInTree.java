package geeks.tree;

public class LeafNodesInTree {
	Node root;
	static int count=0;

	private static class Node {
		int data;
		Node left;
		Node right;

		Node(int i) {
			this.data = i;
			left = null;
			right = null;

		}
	}

	
	public static void  noOfLeafNodes(Node node) {
		 	if (node == null) return;
	 
			if(node.left==null && node.right==null) {
		 
			count++;
		}
		else if(node.left != null) noOfLeafNodes(node.left);
		else noOfLeafNodes(node.right);
		
	
	}
	public static void main(String[] args) {

		
		Node node  = new Node(1);
		node.left = new Node(2);
		node.right = new Node(3);
		node.left.left = new Node(4);
		node.left.right = new Node(5);
		
		noOfLeafNodes(node);
		System.out.println(count);
	}
}
