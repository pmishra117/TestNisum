package geeks.tree;
 
import java.util.LinkedList;
import java.util.Queue;


/*
 
                10
              /   \
            5      20
           / \     / \ 
          3   8   15 25 
             /  
            7
*/
      
public class CheckTwoNodesAreCousinsInBinaryTree {
 
    public static void main(String[] args) {
 
        Node rootNode=null; 
        rootNode  = addNode(rootNode, 10, true);
        rootNode  = addNode(rootNode, 5, true);
        rootNode  = addNode(rootNode, 20, true);
        rootNode  = addNode(rootNode, 3, true);
        rootNode  = addNode(rootNode, 8, true);
        rootNode  = addNode(rootNode, 7, true);
        rootNode  = addNode(rootNode, 15, true);
        rootNode  = addNode(rootNode, 25, true);    
 
        int a = 15;
        int b = 25;
 
        System.out.println(checkCousinRecursive(rootNode, a, b));
    }
     
    private static boolean checkCousinRecursive(Node start, int node1Data, int node2Data){
        int levelNode1 = findLevel(start, node1Data, 0);
        int levelNode2 = findLevel(start, node2Data, 0);
         
        if(levelNode1 == -1 || levelNode2 == -1){
            return false;
        }
         
        if(levelNode1 != levelNode2){
            return false;
        }
         
        return isCousin(start, node1Data, node2Data);
    }
 
    private static boolean isCousin(Node startNode, int node1Data, int node2Data){
        if(startNode==null){
            return false;
        }
         
        if(startNode.left!=null && startNode.right!=null){
            if( (startNode.left.data == node1Data && startNode.right.data == node2Data) ||
                    (startNode.left.data == node2Data && startNode.right.data== node1Data) ){
                return false; //if both node have same parent then they are sibling and not cousin
            }
        }
         
        boolean left = isCousin(startNode.left, node1Data, node2Data);
        if(!left){
            return false;
        }
        boolean right = isCousin(startNode.left, node1Data, node2Data);
        if(!right){
            return false;
        }
         
        return true;
    }
 
    private static int findLevel(Node startNode, int nodeData, int level){
        if(startNode==null){
            return 0;
        }
         
        if(startNode.data == nodeData){
            return level;
        }
         
        int left = findLevel(startNode.left, nodeData, level+1);
        if(left != 0) return left;
         
        int right = findLevel(startNode.right, nodeData, level+1);
        if(right != 0) return right;
         
        return 0;
    }
 
    private static Node addNode(Node rootNode, int i, boolean isRootNode) {
        if(rootNode==null){
            return new Node(i);
        }else{
            if(i > rootNode.data){
                if(isRootNode){
                    Node nodeToAdd = addNode(rootNode.right, i, isRootNode);
                    rootNode.right=nodeToAdd;
                }else{
                    Node nodeToAdd = addNode(rootNode.left, i, isRootNode);
                    rootNode.left=nodeToAdd;
                }
 
            }else{
                if(isRootNode){
                    Node nodeToAdd = addNode(rootNode.left, i, isRootNode);
                    rootNode.left=nodeToAdd;
                }else{
                    Node nodeToAdd = addNode(rootNode.right, i, isRootNode);
                    rootNode.right=nodeToAdd;
                }
            }
        }
        return rootNode;
    }
 
}