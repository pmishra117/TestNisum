package geeks.tree;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class TreeTraversalAlphabets {

 
	private static class NodeD {
		char iData;
		NodeD leftChild;
		NodeD rightChild;
		public NodeD(char data) {
			this.iData=data;
		}
	}
	
	private static class TreeD {
		NodeD root;
		public TreeD() {
			
		}
	}
	
	
public static void main(String [] args){
	TreeD th =new TreeD();
	th.root =new NodeD('A');
	th.root.leftChild=new NodeD('H');
	th.root.rightChild=new NodeD('B');
	th.root.leftChild.leftChild=new NodeD('G');
	th.root.leftChild.rightChild=new NodeD('I');
	 	th.root.rightChild.rightChild=new NodeD('C');
	 	th.root.rightChild.rightChild.leftChild=new NodeD('D');
		th.root.leftChild.rightChild.leftChild=new NodeD('F');
		th.root.leftChild.rightChild.rightChild=new NodeD('E');


	 //inOrder(th.root);
	 levelOrder(th.root);
}

public static void levelOrder(NodeD d){
	System.out.println("Level order.....");
	if(d==null)  return;
	Queue<NodeD> queue=new LinkedList<NodeD>();
	queue.add(d);
	NodeD temp=null;
	while(!queue.isEmpty()){
		temp = queue.poll();
		System.out.print(temp.iData+"   ");
		
		if(temp.leftChild != null)  queue.add(temp.leftChild);
		if(temp.rightChild != null)  queue.add(temp.rightChild);
		
	}
}
}
