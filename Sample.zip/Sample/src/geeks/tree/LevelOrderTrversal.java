package geeks.tree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

 
public class LevelOrderTrversal {
	private static class NodeD {
		int iData;
		NodeD leftChild;
		NodeD rightChild;
		public NodeD(int data) {
			this.iData=data;
		}
	}
	
	private static class TreeD {
		NodeD root;
		public TreeD() {
			
		}
	}
public static void main(String [] args){
	TreeD th =new TreeD();
	th.root =new NodeD(1);
	th.root.leftChild=new NodeD(2);
	th.root.rightChild=new NodeD(3);
	th.root.leftChild.leftChild=new NodeD(4);
	th.root.leftChild.rightChild=new NodeD(5);
	th.root.rightChild.leftChild=new NodeD(6);
	th.root.rightChild.rightChild=new NodeD(7);
	 //inOrder(th.root);
	 levelOrder(th.root);
}

public static void inOrder(NodeD d){
	if(d==null)  return;
	
	System.out.print(d.iData+" ");
	inOrder(d.leftChild);
	inOrder(d.rightChild);
	
}


// for Level Order traversal

public static void levelOrder(NodeD d){
	System.out.println("Level order.....");
	if(d==null)  return;
	Queue<NodeD> queue=new LinkedList<NodeD>();
	queue.add(d);
	NodeD temp=null;
	while(!queue.isEmpty()){
		temp = queue.poll();
		System.out.print(temp.iData+"   ");
		
		if(temp.leftChild != null)  queue.add(temp.leftChild);
		if(temp.rightChild != null)  queue.add(temp.rightChild);
		
	}
}



}
