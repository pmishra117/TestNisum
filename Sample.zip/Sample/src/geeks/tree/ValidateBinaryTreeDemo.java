package geeks.tree;


public class ValidateBinaryTreeDemo {
	private Node root;
	int prevVal=-1;
	
	
	private static class Node {
	 
		    int data;
		    Node left, right;
		 
		    public Node(int item)
		    {
		        data = item;
		        left = right = null;
		    }
		}
		 	
	 
	public boolean validateBinaryTree(Node node) {
		if(node==null) return true;
		prevVal=node.data;
		if(node.left.data<prevVal) return false;
		
		
		return false;
	}

public static void main(String[] args) {
	ValidateBinaryTreeDemo tree = new ValidateBinaryTreeDemo();
      tree.root = new Node(1);
      tree.root.left = new Node(2);
      tree.root.right = new Node(3);
      tree.root.left.left = new Node(4);
      tree.root.left.right = new Node(5);
      tree.root.right.left = new Node(6);
      tree.root.right.right = new Node(7);
   
}
}
