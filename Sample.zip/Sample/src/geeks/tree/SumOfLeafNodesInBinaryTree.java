package geeks.tree;

public class SumOfLeafNodesInBinaryTree {
private static class Node {
	int data;
	Node left;
	Node right;
	public Node(int data) {
		this.data=data;
		left=null;
		right=null;
	}
}
private static class TreeOperations {
	Node root;
	static int sum=0;
	static int min=1;
	
	public static int sumOfLeafNodes(Node root) {
		if(root == null) return sum;
	  	
			
			if(root.left ==null && root.right == null) 
				sum+=root.data;
			
			    sumOfLeafNodes(root.left);			
				sumOfLeafNodes(root.right);
			 
			
	 
		return sum;
	}
	
	public static void printLeafNodes(Node root) {
		if(root == null)
			return;
		
				if(root.left ==null && root.right == null) 
				System.out.println(" Leaf Nodes  "  +root.data);
				
				printLeafNodes(root.right);
				printLeafNodes(root.left);			
				
			
			
		
		 
	}
	
	public static int minElement(Node root) {
		if(root == null) return min;
		
		   //    if(root.data > min) min=root.data;
		       
				if(root.left != null && root.left.data < min) {
				min=root.left.data;
			minElement(root.left);
				}
			if(root.left != null && root.right.data < min)
				{
				min=root.right.data;
				
			minElement(root.right);
				}
		
		return min;
	}
	
	public static int maxElement(Node root) {
		if(root == null) return min;
		
		   //    if(root.data > min) min=root.data;
		       
				if(root.left != null && root.left.data > min) {
				min=root.left.data;
			minElement(root.left);
				}
			if(root.left != null && root.right.data > min)
				{
				min=root.right.data;
				
			minElement(root.right);
				}
		
		return min;
	}

}


public static void main(String[] args) {
	Node tree= new Node(1);
	tree.left=new Node(2);
	tree.right=new Node(3);
	tree.left.left=new Node(4);
	tree.left.right=new Node(5);
	tree.right.left=new Node(6);
	tree.right.right=new Node(7);
	
	//System.out.println(TreeOperations.sumOfLeafNodes(tree));
	
	//System.out.println("Min Element in Tree "+TreeOperations.minElement(tree));
	
	//System.out.println("Max Element in Tree "+TreeOperations.maxElement(tree));
	TreeOperations.printLeafNodes(tree);
}
}
