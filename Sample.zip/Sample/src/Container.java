package com.demoJava.Dp;

import java.util.Iterator;

public interface Container {
	   public Iterator getIterator();
	}