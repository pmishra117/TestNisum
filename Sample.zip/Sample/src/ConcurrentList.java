package com.demoJava.others;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
 
public class ConcurrentList {
 
	public static void main(String[] args) {
    	
    	String s="abasjnabmzcmskciowecmsncjfgewtcjn";
    	char[]c=s.toCharArray();
    	TreeSet<Character>ts= new TreeSet<Character>();
    	for(int i=0;i<c.length;i++) {
    		ts.add(c[i]);
    	}
    	Iterator itr= ts.iterator();
    	while(itr.hasNext()){
    	System.out.println(itr.next());
    	}
    	
    	
        List<String> list = new CopyOnWriteArrayList<>();
        list.add("1");
        list.add("2");
        list.add("5");
        list.add("4");
        list.add("5");
        int res =  "Mishre".compareToIgnoreCase("MISHRA");
        System.out.println(res+"res");
       
        // get the iterator
        Iterator<String> it = list.iterator();
         
        //manipulate list while iterating
        while(it.hasNext()){
            System.out.println("list is:"+list);
            String str = it.next();
            System.out.println(str);
           list.remove("5");
            Iterator<String> itra = list.iterator();
            
           while(itra.hasNext())
            System.out.println("new value....."+itra.next());
          //  if(str.equals("3"))list.add("3 found");
            //below code don't throw ConcurrentModificationException
            //because it doesn't change modCount variable of list
           // if(str.equals("4")) list.set(1, "4");
        }
    }
    
   
 
}
