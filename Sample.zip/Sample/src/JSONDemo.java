package javaXML;

public class JSONDemo {

}
