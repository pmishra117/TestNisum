package demoJava.others;
import java.util.HashMap;
import java.util.Map;

public class MemoryLeakEx {
private Map cache = new HashMap();
public int square(int i) {
int result = i * i;
cache.put(i, result);
return result;
}
public static void main(String[] args) throws Exception {
MemoryLeakEx calc = new MemoryLeakEx();
while (true) {
System.out.println("Enter a number between 1 and 100");
int i = 10; //not shown
System.out.println("Answer " + calc.square(i));
}
}
}
 
