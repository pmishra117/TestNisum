import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

class Talk implements Comparable<Object> {
	String title;
	String name;
	int timeDuration;
	boolean scheduled = false;
	String scheduledTime;

	public Talk(String title, String name, int time) {
		this.title = title;
		this.name = name;
		this.timeDuration = time;
	}

	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	public boolean isScheduled() {
		return scheduled;
	}

	public void setScheduledTime(String scheduledTime) {
		this.scheduledTime = scheduledTime;
	}

	public String getScheduledTime() {
		return scheduledTime;
	}

	public int getTimeDuration() {
		return timeDuration;
	}

	public String getTitle() {
		return title;
	}

	@Override
	public int compareTo(Object obj) {
		Talk talk = (Talk) obj;
		if (this.timeDuration > talk.timeDuration)
			return -1;
		else if (this.timeDuration < talk.timeDuration)
			return 1;
		else
			return 0;
	}
}

public class ConferenceManagement {

	public static void main(String[] args) throws Exception {
		String file = "D:\\input.txt";
		ConferenceManagement conferenceManagement = new ConferenceManagement();
		try {
			conferenceManagement.schedulingConference(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<List<Talk>> schedulingConference(String fileName)
			throws Exception {
		List<String> talkList = getTalkListFromFile(fileName);
		return scheduleConference(talkList);
	}

	public List<List<Talk>> scheduleConference(List<String> talkList)
			throws Exception {
		List<Talk> talksList = validateAndCreateTalks(talkList);
		return getScheduleConferenceTrack(talksList);
	}

	public List<String> getTalkListFromFile(String fileName) {
			 
		List<String> talkList = new ArrayList<String>();
		try {
			FileInputStream fin = new FileInputStream(fileName);
			InputStreamReader in = new InputStreamReader(fin);
			BufferedReader br = new BufferedReader(in);
			String data = br.readLine();
			while (data != null) {
				talkList.add(data);
				data = br.readLine();
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return talkList;
	}

	private List<Talk> validateAndCreateTalks(List<String> talkList) {
		if (talkList == null)
			System.out.println("Talk list is Empty.....");

		List<Talk> validTalksList = new ArrayList<Talk>();
		String minuteSuffix = "min";
		String lightningSuffix = "lightning";
		int talkCount = -1;

		for (String talk : talkList) {
			int lastSpaceIndex = talk.lastIndexOf(" ");
			if (lastSpaceIndex == -1)
				System.out.println("The talk is not Valid , " + talk);

			String name = talk.substring(0, lastSpaceIndex);
			String timeData = talk.substring(lastSpaceIndex + 1);

			if (name.equalsIgnoreCase(""))
				System.out.println("The talk is not Valid , " + talk);

			else if (!timeData.endsWith(minuteSuffix)
					&& !timeData.endsWith(lightningSuffix))
				System.out.println("The talk time is Invalid, " + talk);

			talkCount++;
			int time = 0;

			try {
				if (timeData.endsWith(minuteSuffix)) {
					time = Integer.parseInt(timeData.substring(0,
							timeData.indexOf(minuteSuffix)));
				} else if (timeData.endsWith(lightningSuffix)) {
					String lightningTime = timeData.substring(0,
							timeData.indexOf(lightningSuffix));
					if (lightningTime.equalsIgnoreCase(" "))
						time = 5;
					else
						time = Integer.parseInt(lightningTime) * 5;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			validTalksList.add(new Talk(talk, name, time));
		}

		return validTalksList;
	}

	private List<List<Talk>> getScheduleConferenceTrack(List<Talk> talksList)
			throws Exception {

		int perDayMinTime = 6 * 60;
		int totalTalksTime = getTotalTalksTime(talksList);
		int totalPossibleDays = totalTalksTime / perDayMinTime;

		List<Talk> talksListForOperation = new ArrayList<Talk>();
		talksListForOperation.addAll(talksList);
		Collections.sort(talksListForOperation);

		List<List<Talk>> combForMornSessions = combiningSession(
				talksListForOperation, totalPossibleDays, true);

		for (List<Talk> talkList : combForMornSessions) {
			talksListForOperation.removeAll(talkList);
		}
		List<List<Talk>> combForEveSessions = combiningSession(
				talksListForOperation, totalPossibleDays, false);

		for (List<Talk> talkList : combForEveSessions) {
			talksListForOperation.removeAll(talkList);
		}

		int maxSessionTimeLimit = 240;
		if (!talksListForOperation.isEmpty()) {
			List<Talk> scheduledTalkList = new ArrayList<Talk>();
			for (List<Talk> talkList : combForEveSessions) {
				int totalTime = getTotalTalksTime(talkList);

				for (Talk talk : talksListForOperation) {
					int talkTime = talk.getTimeDuration();

					if (talkTime + totalTime <= maxSessionTimeLimit) {
						talkList.add(talk);
						talk.setScheduled(true);
						scheduledTalkList.add(talk);
					}
				}

				talksListForOperation.removeAll(scheduledTalkList);
				if (talksListForOperation.isEmpty())
					break;
			}
		}

		if (!talksListForOperation.isEmpty()) {
			System.out.println("Unable to schedule all task for conferencing.");
		}

		return getScheduledTalksList(combForMornSessions, combForEveSessions);
	}

	private List<List<Talk>> combiningSession(List<Talk> talksListForOperation,
			int totalPossibleDays, boolean morningSession) {
		int minSessionTimeLimit = 180;
		int maxSessionTimeLimit = 240;

		if (morningSession)
			maxSessionTimeLimit = minSessionTimeLimit;

		int talkListSize = talksListForOperation.size();
		List<List<Talk>> possibleCombinationsOfTalks = new ArrayList<List<Talk>>();
		int possibleCombinationCount = 0;
		for (int count = 0; count < talkListSize; count++) {
			int startPoint = count;
			int totalTime = 0;
			List<Talk> possibleCombinationList = new ArrayList<Talk>();

			while (startPoint != talkListSize) {
				int currentCount = startPoint;
				startPoint++;
				Talk currentTalk = talksListForOperation.get(currentCount);
				if (currentTalk.isScheduled())
					continue;
				int talkTime = currentTalk.getTimeDuration();
				if (talkTime > maxSessionTimeLimit
						|| talkTime + totalTime > maxSessionTimeLimit) {
					continue;
				}

				possibleCombinationList.add(currentTalk);
				totalTime += talkTime;

				if (morningSession) {
					if (totalTime == maxSessionTimeLimit)
						break;
				} else if (totalTime >= minSessionTimeLimit)
					break;
			}

			boolean validSession = false;
			if (morningSession)
				validSession = (totalTime == maxSessionTimeLimit);
			else
				validSession = (totalTime >= minSessionTimeLimit && totalTime <= maxSessionTimeLimit);
			if (validSession) {
				possibleCombinationsOfTalks.add(possibleCombinationList);
				for (Talk talk : possibleCombinationList) {
					talk.setScheduled(true);
				}
				possibleCombinationCount++;
				if (possibleCombinationCount == totalPossibleDays)
					break;
			}
		}

		return possibleCombinationsOfTalks;
	}

	private List<List<Talk>> getScheduledTalksList(
			List<List<Talk>> combForMornSessions,
			List<List<Talk>> combForEveSessions) {
		List<List<Talk>> scheduledTalksList = new ArrayList<List<Talk>>();
		int totalPossibleDays = combForMornSessions.size();

		for (int dayCount = 0; dayCount < totalPossibleDays; dayCount++) {
			List<Talk> talkList = new ArrayList<Talk>();
			Date date = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mma ");
			date.setHours(9);
			date.setMinutes(0);
			date.setSeconds(0);

			int trackCount = dayCount + 1;
			String scheduledTime = dateFormat.format(date);

			System.out.println("Track " + trackCount + ":");
			List<Talk> mornSessionTalkList = combForMornSessions.get(dayCount);
			for (Talk talk : mornSessionTalkList) {
				talk.setScheduledTime(scheduledTime);
				System.out.println(scheduledTime + talk.getTitle());
				scheduledTime = getNextScheduledTime(date,
						talk.getTimeDuration());
				talkList.add(talk);
			}

			int lunchTimeDuration = 60;
			Talk lunchTalk = new Talk("Lunch", "Lunch", 60);
			lunchTalk.setScheduledTime(scheduledTime);
			talkList.add(lunchTalk);
			System.out.println(scheduledTime + "Lunch");

			scheduledTime = getNextScheduledTime(date, lunchTimeDuration);
			List<Talk> eveSessionTalkList = combForEveSessions.get(dayCount);
			for (Talk talk : eveSessionTalkList) {
				talk.setScheduledTime(scheduledTime);
				talkList.add(talk);
				System.out.println(scheduledTime + talk.getTitle());
				scheduledTime = getNextScheduledTime(date,
						talk.getTimeDuration());
			}
			Talk networkingTalk = new Talk("Networking Event",
					"Networking Event", 60);
			networkingTalk.setScheduledTime(scheduledTime);
			talkList.add(networkingTalk);
			System.out.println(scheduledTime + "Networking Event\n");
			scheduledTalksList.add(talkList);
		}

		return scheduledTalksList;
	}

	public static int getTotalTalksTime(List<Talk> talksList) {
		if (talksList == null || talksList.isEmpty())
			return 0;

		int totalTime = 0;
		for (Talk talk : talksList) {
			totalTime += talk.timeDuration;
		}
		return totalTime;
	}

	private String getNextScheduledTime(Date date, int timeDuration) {
		long timeInLong = date.getTime();
		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mma ");

		long timeDurationInLong = timeDuration * 60 * 1000;
		long newTimeInLong = timeInLong + timeDurationInLong;

		date.setTime(newTimeInLong);
		String str = dateFormat.format(date);
		return str;
	}

}
