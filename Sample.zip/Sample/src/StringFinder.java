package com.demoJava.string;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class StringFinder {

public static void main(String[] args)
{
    double count = 0,countBuffer=0,countLine=0;
    String lineNumber = "";
    String filePath = "demoStr.txt";
    BufferedReader br;
    String inputSearch = "Pradeep";
    String inputSearch1 = "Kumar";
    String inputSearch2 = "Mishra";
    
    String line = "";

    try {
        br = new BufferedReader(new FileReader(filePath));
        try {
            while((line = br.readLine()) != null)
            {
                countLine++;
                //System.out.println(line);
                String[] words = line.split(" ");

                for (String word : words) {
                  if (word.equals(inputSearch)||word.equalsIgnoreCase(inputSearch1)||word.equalsIgnoreCase(inputSearch2)) {
                	  if(null != inputSearch){
                	  System.out.println("Name found at--"+lineNumber+"   "+inputSearch);
                	  }
                	  if(null != inputSearch1){
                    	  System.out.println("Name found at--"+lineNumber+"  "+inputSearch1);
                    	  }
                	  if(null != inputSearch2){
                    	  System.out.println("Name found at--"+lineNumber +inputSearch2);
                    	  }
                	  
                	  //System.out.println("Name found at--"+lineNumber);

                	  count++;
                    countBuffer++;
                  }
                }

                if(countBuffer > 0)
                {
                    countBuffer = 0;
                    lineNumber += countLine + ",";
                }

            }
            br.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

 }
}
