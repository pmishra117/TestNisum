// Java program for reversing the linked list
 
public class LinkedListReverseDemo {
 
    static Node head;
 
    static class Node {
 
        int data;
        Node next;
 
        Node(int d) {
            data = d;
            next = null;
        }
    }
 
    /* Function to reverse the linked list */
    Node reverse(Node node) {
        Node prev = null;
        Node current = node;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
         
        return prev;
    }
    
    //Reverse by Naman
    
    Node reverseByNaman(Node node) {
        Node p1 = node;
        Node p2 = p1.next;
        Node p3 = p2.next;
        
        while (p2.next!= null) {
            p2.next = p1;
            p1 = p2;
            p2 = p3;
            p3 = p3.next;
        }
        p1.next = null;
        return p1;
    }
 
    // prints content of double linked list
    void printList(Node node) {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
    }
 
    public static void main(String[] args) {
    	LinkedListReverseDemo list = new LinkedListReverseDemo();
        list.head = new Node(1);
        list.head.next = new Node(2);
        list.head.next.next = new Node(3);
        list.head.next.next.next = new Node(4);
        list.head.next.next.next.next = new Node(5);
            
        System.out.println("Given Linked list");
        list.printList(head);
        head = list.reverseByNaman(head);
        System.out.println("");
        System.out.println("Reversed linked list ");
        list.printList(head);
    }
}