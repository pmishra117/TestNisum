package com.demoJava.collection;

import java.util.*;

class Person implements Comparator<Person> {
	private String lastName;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	private String firstName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Person() {

	}

	private int age;

	public Person(String last, String first, int a) {
		lastName = last;
		firstName = first;
		age = a;
	}

	public String toString() {
		return "Last name: " + lastName + " First name: " + firstName
				+ " Age: " + age;
	}

	public int compare(Person o1, Person o2) {

		int firstNameCmp = o1.getFirstName().compareTo(o2.getFirstName());
		return ((firstNameCmp == 0) ? o1.getLastName().compareTo(
				o2.getLastName()) : firstNameCmp);

	}
}

public class NamesSort {
	public static void main(String[] args) {
			    List<Person> list = new ArrayList<Person>();
		
		Person p1 = new Person();
		p1.setFirstName("PradeeP");
		p1.setLastName("Mishra");

		Person p2 = new Person();
		p2.setFirstName("Dileep");
		p2.setLastName("Mishra");

		Person p3 = new Person();
		p3.setFirstName("Pradeep");
		p3.setLastName("Singh");

		list.add(p1);
		list.add(p2);
		list.add(p3);
		System.out.println("The sorted list is as follows");

		Collections.sort(list, new Person());

		Iterator<Person> iterator = list.iterator();
		while (iterator.hasNext()) {
			Person tempDTO = iterator.next();
			System.out.println(tempDTO.getFirstName() + "  "
					+ tempDTO.getLastName());
		} 
	} 
}
/*
 * insertionSort(persons);
 * 
 * System.out.println("After sorting:"); for (Person p : persons) {
 * System.out.println(p); } }
 * 
 * public static void insertionSort(Person[] persons) { int in, out;
 * 
 * for (out = 1; out < persons.length; out++) { Person temp = persons[out]; in =
 * out;
 * 
 * while (in > 0 && persons[in - 1].getLast().compareTo(temp.getLast()) > 0) {
 * persons[in] = persons[in - 1]; --in; } persons[in] = temp; } } }
 */