package demoJava.others;
public class DemoSingleton {
private  static final DemoSingleton instance=new DemoSingleton() ;
	public static void main(String[] args) {
		 instance.getInstance(instance);
		 System.out.println(instance);
		instance.getInstance(instance);
}
	private DemoSingleton(){}
	public static DemoSingleton getInstance(DemoSingleton instance) 
	{
		if(instance == null) {
			instance =new DemoSingleton();
			return instance;
		}
		else 
		{
			return instance;
		}
	}
}
