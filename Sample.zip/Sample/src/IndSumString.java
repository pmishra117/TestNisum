package geeks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class IndSumString {
public static void main(String[] args) {
	indSumString("pradeep");
}

public static void indSumString(String str)
{
	String input=str;
	char[]charData=input.toCharArray();
	ArrayList<Character>ct=new ArrayList<Character>();
	for(int i=0;i<charData.length;i++){
		ct.add(charData[i]);
	}
	
	Collections.sort(ct);
	
	Set s = new HashSet(ct);
	
	Iterator<Character>itrIn=ct.iterator();
	Iterator<Character> itrOut=s.iterator();
	while(itrOut.hasNext()){
	int c=0;
	char data=itrOut.next();
	while(itrIn.hasNext()){
		char dataIn=itrIn.next();
	
		 if(data==dataIn) {c++;}
		 else {
			 break;
		 }
	} 
		 System.out.println(data + " is  "+c);
	}
}	
}
