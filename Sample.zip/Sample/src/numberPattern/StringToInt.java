package geeks.numberPattern;

import java.util.HashSet;

public class StringToInt {
	    public int ConvertStringToInt(String s) throws NumberFormatException
	    { 
	    	int sum=0;
	    	    int position=1;
	    	    for (int i = s.length()-1; i >= 0 ; i--) {
	    	       int number=s.charAt(i) - '0';
	    	       sum+=number*position;
	    	       position=position*10;

	    	  
	    	}
	          
	        return sum;  
	        }
	        /*
	    	
	        HashSet<StringToInt> gs= new HashSet<StringToInt>();
		    
		    StringToInt obj1 =new StringToInt();
		    StringToInt obj2 =new StringToInt();
		    StringToInt obj3 =new StringToInt();
		    StringToInt obj4 =new StringToInt();
		    StringToInt obj5 =new StringToInt();
		    StringToInt obj6 =new StringToInt();
		    StringToInt obj7 =new StringToInt();
		    StringToInt obj8 =new StringToInt();
		    StringToInt obj9 =new StringToInt();
		    StringToInt obj10 =new StringToInt();
		       gs.add(obj1);
		       gs.add(obj2);
		       gs.add(obj3);
		       gs.add(obj4);
		       gs.add(obj5);
		       gs.add(obj6);
		       gs.add(obj7);
		       gs.add(obj8);
		       gs.add(obj9);
		       gs.add(obj10);
		       
		       System.out.println(gs.size());
		       
	    }
	   */ 
	    

	    public static void main(String[]args)
	    {
	        StringToInt obj = new StringToInt();
	       int i=obj.ConvertStringToInt("1234123");
	         System.out.println(i);
	    }
	    
	
		

	}

