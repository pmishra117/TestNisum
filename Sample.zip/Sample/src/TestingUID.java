import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

 class TestSUID implements Serializable {
    private static final long serialVersionUID = 1L;
    private int someId;

    public TestSUID (int someId) {
        this.someId = someId;
    }

    public int getSomeId() {
        return someId;
    }
}
class ColorCircle {
	int ii;
	public int getIi() {
		return ii;
	}
	public void setIi(int ii) {
		this.ii = ii;
	}
	public int getJj() {
		return jj;
	}
	public void setJj(int jj) {
		this.jj = jj;
	}
	int jj;
	public ColorCircle(int i,int j) {
		ii=i;
		jj=j;
		
	}
}
 


public class TestingUID {
    public static void main(String args[]) throws Exception {
        Map myHashMap =new HashMap();   
          //SortingLt.BruteForceSearch(arr,6);
        ColorCircle key = new ColorCircle(10,11); //assume hashCode=1234
        myHashMap.put(key, "value");

        // Below code will change the key hashCode() and equals()
        // but it's location is not changed.
         key.setIi(100);
         key.setJj(200);//assume new hashCode=7890

        //below will return null, because HashMap will try to look for key
        //in the same index as it was stored but since key is mutated,
        //there will be no match and it will return null.
      // System.out.println(myHashMap.get(new ColoredCircle(10,11))); 
       System.out.println(myHashMap.get(key)); 
   	
    	
    	
    	File file = new File("temp.ser");
        FileOutputStream fos = new FileOutputStream(file);
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        TestSUID writeSUID = new TestSUID(1);
        oos.writeObject(writeSUID);
        oos.close();

        FileInputStream fis = new FileInputStream(file);
        ObjectInputStream ois = new ObjectInputStream(fis);

        TestSUID readSUID = (TestSUID) ois.readObject();
        System.out.println("someId : " + readSUID.getSomeId());
        ois.close();
    }
}


