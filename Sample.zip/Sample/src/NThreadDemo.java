class NThreadDemoRun implements Runnable {

    private static final int LIMIT = 20;
    private static volatile int counter = 0;
    private int id;

    public NThreadDemoRun(int id) {
        this.id = id;
    }

    public void run() {
        outer:
        while(counter < LIMIT) {
            while (counter++ % 4 != id) {
                if(counter == LIMIT) break outer;
            }
            System.out.println("Thread "+Thread.currentThread().getName()+ " printed " + counter);
           }
    }
}
   public class  NThreadDemo{
	   public static void main(String[] args) {
		   NThreadDemoRun t1= new NThreadDemoRun(1);
		   NThreadDemoRun t2= new NThreadDemoRun(2);
			
		   NThreadDemoRun t3= new NThreadDemoRun(3);
			
		   NThreadDemoRun t4= new NThreadDemoRun(4);
			new Thread(t1).start();
			new Thread(t2).start();
			new Thread(t3).start();
			new Thread(t4).start();
			char [] array= {'a','a','b','b','a','d'};
		
	}
    	
    }
 