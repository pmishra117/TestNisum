package geeks;

class Link{
	int i;
	Link next;

	//public Link(int i){
	//	this.i=i;
	//}
	
}
public class MergeSortOfLinkedList {
	public static void main(String[] args) {
		
	}
	//The main function
	public Link merge_sort(Link head) {
	    if(head == null || head.next == null) { return head; }
	    Link middle = getMiddle(head);      //get the middle of the list
	    Link sHalf = middle.next; middle.next = null;   //split the list into two halfs

	    return merge(merge_sort(head),merge_sort(sHalf));  //recurse on that
	}

	//Merge subroutine to merge two sorted lists
	public Link merge(Link a, Link b) {
	    Link dummyHead, curr; dummyHead = new Link(); curr = dummyHead;
	    while(a !=null && b!= null) {
	        if(a.i <= b.i) { curr.next = a; a = a.next; }
	        else { curr.next = b; b = b.next; }
	        curr = curr.next;
	    }
	    curr.next = (a == null) ? b : a;
	    return dummyHead.next;
	}

	//Finding the middle element of the list for splitting
	public Link getMiddle(Link head) {
	    if(head == null) { return head; }
	    Link slow, fast; slow = fast = head;
	    while(fast.next != null && fast.next.next != null) {
	        slow = slow.next; fast = fast.next.next;
	    }
	    return slow;
	}
}
