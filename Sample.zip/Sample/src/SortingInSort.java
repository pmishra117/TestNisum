package com.java.javaDS.hclTest;

public class SortingInSort {
	int noOfZeros=0;
	int noOf1=0;
	int []b;// need to declare b[] of size of array

public static void main(String[] args) {
	 new SortingInSort().sort();
	 
}

 

public SortingInSort() {
	b=new int[10];
}
public void sort(){
	int array[]={0,0,1,0,1,0,0,0,1,1};
	int size=array.length;
		for(int i=0;i<size;i++){
		if(array[i]==0){
	noOfZeros++;
	}
  	  noOf1=size-noOfZeros;
	
 
//System.out.println(noOfZeros);
//System.out.println(noOf1);
for(int j=0;j<10;j++) {
	if(j<4){
		b[j]=0;
	}
	else b[j]=1;
}
//System.out.println(b.length);
for(int k=0;k<b.length;k++) {
	System.out.println(b[k]);
}
}
}
} 