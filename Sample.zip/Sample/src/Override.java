
public class Override {
public int aa(int a){
	return 0;
	
}

public double aa(int b){
	return 0;
	
}
}
