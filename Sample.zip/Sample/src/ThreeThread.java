
public class ThreeThread {
      int status=1;
      public static void main(String[] args) {
     ThreeThread ob = new ThreeThread(); Th1 t1 = new Th1(ob,"Th1"); Th2 t2 = new Th2(ob,"Th2"); Th3 t3 = new Th3(ob,"Th3"); t1.start(); t2.start(); t3.start();
 }
}

class Th1 extends Thread{
	private ThreeThread ob;
      public Th1(ThreeThread o, String t){
            super(t);
            ob=o;
     }
     
      public void run(){
            synchronized(ob){
                  for(int a=1; a<10;a=a+3){
                        try {
                              while(ob.status!=1){
                                    ob.wait();
                              }
                              String t1 = Thread.currentThread().getName();

                              System.out.println(t1+" "+a);

                              ob.status=2;

                              ob.notifyAll();

                        } catch (InterruptedException e) {

                              e.printStackTrace();

                        }

                       

                  }

            }

      }

}

 

class Th2 extends Thread{

     

      private ThreeThread ob;

      public Th2(ThreeThread o, String t){

            super(t);

            ob=o;

      }

     

   
      public void run(){

            synchronized(ob){

                  for(int a=2; a<21;a=a+3){

                        try {

                              while(ob.status!=2){

                                    ob.wait();

                              }

                              String t1 = Thread.currentThread().getName();

                              System.out.println(t1+" "+a);

                              ob.status=3;

                              ob.notifyAll();

                        } catch (InterruptedException e) {

                              e.printStackTrace();

                        }

                       

                  }

            }

      }

}

 

class Th3 extends Thread{
      private ThreeThread ob;

      public Th3(ThreeThread o, String t){
          super(t);
           ob=o;
    }
      public void run(){

            synchronized(ob){

                  for(int a=3; a<22;a=a+3){

                        try {

                              while(ob.status!=3){

                                    ob.wait();

                              }

                              String t1 = Thread.currentThread().getName();

                              System.out.println(t1+" "+a);

                              System.out.println();

                              ob.status=1;

                              ob.notifyAll();

                        } catch (InterruptedException e) {

                              e.printStackTrace();

                        }

                       

                  }

            }

      }

}