
public class TestTry {
public static void main(String[] args) {
	System.out.println(test());
}

public static String test() {
	try {
		System.out.println("Hi   ");
		return "abc";
	}catch(Exception e) {
		return "b";
		
	}
	finally {
		System.out.println("Hello");
		return "naman";
	}
}
}
