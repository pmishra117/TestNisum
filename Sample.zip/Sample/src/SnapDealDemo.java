package oldJavaDS;

import java.util.ArrayList;

public class SnapDealDemo {
static ArrayList<String>mainList=new ArrayList<String>();
static ArrayList<String>updatedList=new ArrayList<String>();

	public static void main(String[] args) {
	String data="Pradeep";
	System.out.println(readStream(data));

	String data1="Dileep";
	System.out.println(readStream(data1));


	String data2="Pradeep";
	System.out.println(readStream(data2));
	
	String data3="Dev";
	System.out.println(readStream(data3));

	String data4="Dileep";
	System.out.println(readStream(data4));


	}


public static String readStream(String data){
	while(!data.isEmpty())
	{
		if(mainList.isEmpty()){
			mainList.add(data);
			return mainList.get(0);
		}
		else if(!mainList.isEmpty() && !mainList.contains(data)) {
			mainList.add(data);
			return mainList.get(mainList.indexOf(data)-1);
		}
		else {
			return mainList.get(mainList.indexOf(data)+1);
		}
	}
	return null;
}
}
