package WalmartLab;

public class StringDemo {
public static void main(String[] args) {
	String[] words={"RBR","BBR","RRR"};//,"RBR","BBR","RRR"};
	System.out.println("String length is..  "+countWords(words));
}
public static int countWords(String[] words){
	char data=words[0].charAt(0);
	String newString="";
	for(int i=0;i<words.length;i++){
		if(data==words[i].charAt(words[i].length()-1)){
			newString+=words[i];
		}
		
	}
	int stringlength=newString.length();
	return stringlength;
}
}
