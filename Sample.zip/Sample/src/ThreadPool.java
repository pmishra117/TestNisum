package com.demoJava.Concurrency;

import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class ThreadPool {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

	    int amountOfThreads = 2;
	    ExecutorService threadPool = Executors.newFixedThreadPool(amountOfThreads);
	    ExecutorCompletionService<Long> tasks = new ExecutorCompletionService<Long>(threadPool);

	    //Start all of my tasks which will return long values.
	    for(int i=0; i < amountOfThreads; i++) {
	        tasks.submit(new Callable<Long>() {

	            @Override
	            public Long call() throws Exception {
	                long startTime = System.currentTimeMillis();

	                for(int i=0; i < 9999999; i++) {
	                    //Do some stuff.
	                }

	                long endTime = System.currentTimeMillis();
	                return endTime-startTime;
	            }
	        });
	    }

	    FileWriter out = null;

	    //Output the long values of all my tasks in order of completion.
	    try {
	        out = new FileWriter("Success.txt");
	        for(int i=0; i < amountOfThreads; i++) {
	            Future<Long> task = tasks.take();
	            out.write("Task " + task + " completed in " + task.get().longValue() + "ms" + System.getProperty("line.separator"));
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        if(out!=null) {
	            try {
	                out.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    threadPool.shutdown();

	} 
}