


abstract class A{
	public void method() {
		System.out.println("Hi In Abstract");
	}
	public abstract void method1();
}


public class AbstactDemo extends A {
 

	public static void main(String[] args) {
		A a =new AbstactDemo();
		a.method();
	 	
	}
	
	public void method() {
			System.out.println("Hi In Abstract");
	}
	
	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
	}
}
	
 
