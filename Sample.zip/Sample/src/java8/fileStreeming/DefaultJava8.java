package java8.fileStreeming;

 
 
interface I1 {
	  abstract void method();
	}
	 
	interface I2 {
	  abstract void method();
	}
	 
	public class DefaultJava8 implements I1, I2 {
	 
	  @Override
	  public void method() {
	    System.out.println("hello world");
	  }
	 
	  public static void main(String[] a) {
	    DefaultJava8 mi = new DefaultJava8();
	    I1 i1 = new DefaultJava8();
	    I2 i2 = new DefaultJava8();
	    mi.method();
	    i1.method();
	    i2.method();
	  }
}
