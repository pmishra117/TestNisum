package java8.fileStreeming;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamTest {
	public static void main(String[] args) {
		List<Employee> empList = populateList();
		int totalSal = empList.stream().collect(Collectors.summingInt(Employee::getSalary));
		System.out.println("Total salary is : " + totalSal);
		
		Double d = empList.stream().collect(Collectors.averagingDouble(Employee::getSalary));
		System.out.println("Average salary in double: " + d);
		
		System.out.println(""+empList.stream().collect(Collectors.counting()));
		
		System.out.println(""+empList.stream().collect(Collectors.averagingDouble(Employee::getSalary)));

		//Collectors.joining()
		System.out.println(empList.stream().map(Employee::getName).collect(Collectors.joining(", ")));
		
		//Collectors.summaryStatistics() Example
		IntSummaryStatistics summary = empList.stream().collect(Collectors.summarizingInt(Employee::getSalary));
		System.out.println("Average : " + summary.getAverage());
		System.out.println("Min : " + summary.getMax());
		System.out.println("Mix : " + summary.getMin());
		System.out.println("Count : " + summary.getCount());
		System.out.println("Sum : " + summary.getSum());
		System.out.println("summary : " + summary);
		
		//Collectors.partition() Example
		List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9); 
		Map<Boolean, List<Integer>> evenAndOddNumbers = list.stream().collect(Collectors.partitioningBy(n -> n % 2 == 0));
		System.out.println("Even Numbers : " + evenAndOddNumbers.get(true));
		System.out.println("Odd Numbers : " + evenAndOddNumbers.get(false));
		
		
		Map<Integer, Integer> m = empList.stream().collect(Collectors.toMap(Employee::getId, Employee::getSalary));
		System.out.println("Map : " + m);
				
		List<Employee> empList1 = populateList1();
		List<Employee> newEmp = empList1.stream().map(e -> {
			e.setSalary(m.get(e.getId()));
			return e;
		}).collect(Collectors.toList());
		newEmp.stream().forEach(System.out::println);
		
	}

	public static List<Employee> populateList() {
		List<Employee> employees = Arrays.asList(new Employee(1, 1000, "Chandra Shekhar", 6000),
				new Employee(4, 1000, "Rajesh", 8000), new Employee(2, 1004, "Rahul", 9000),
				new Employee(5, 1001, "Suresh", 12000), new Employee(3, 1004, "Satosh", 8500));
		return employees;
	}

	public static List<Employee> populateList1() {
		List<Employee> employees = Arrays.asList(new Employee(1, 1000, "Chandra Shekhar"),
				new Employee(4, 1000, "Rajesh"), new Employee(2, 1004, "Rahul"),
				new Employee(5, 1001, "Suresh"), new Employee(3, 1004, "Satosh"));
		return employees;
	}

}

class Employee {
	private int id;
	private int deptId;
	private String name;
	private int salary;

	public Employee(int id, int deptId, String name, int salary) {
		super();
		this.id = id;
		this.deptId = deptId;
		this.name = name;
		this.salary = salary;
	}

	public Employee(int id, int deptId, String name) {
		super();
		this.id = id;
		this.deptId = deptId;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", deptId=" + deptId + ", name=" + name + ", salary=" + salary + "]";
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getDeptId() {
		return deptId;
	}

}