public class ThreadRunDemo {
	public static synchronized void main(String[] args) {
		Thread t = new Thread() {
			public void run() {
				kong();
			}
		};
		t.run();
		System.out.print("King");
	}

	public static synchronized void kong() {
		System.out.print("Kong");
	}
}
