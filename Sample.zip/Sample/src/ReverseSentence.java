package geeks;

import java.util.StringTokenizer;

public class ReverseSentence {
	// TODO Auto-generated constructor stub
public static void main(String[] args){
	String data="Pradeep is Name My";
	System.out.print(getReverse(data));
	
}

public static String getReverse(String data){
	String sentAct="";
	StringTokenizer str=new StringTokenizer(data);
	String []a=data.split("");
	for(int i=a.length-1;i>=0;i--){
		sentAct+=a[i];
	}
	
	return sentAct;
}
}
