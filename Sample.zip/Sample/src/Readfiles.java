import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;


public class Readfiles {
public static void main(String[] args) throws IOException {
	Reader fin=new FileReader(new File("D:/file.txt"));
	BufferedReader br =new BufferedReader(fin);
	while(br.ready()){
		String data=br.readLine();
		//data.charAt(70);
		System.out.println(data+"');");
	}
	
}
}
