
public interface TestIn {
public void a();
public void b();
public void c();
}
