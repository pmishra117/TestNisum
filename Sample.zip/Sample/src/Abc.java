import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Abc {
    static Consumer lambdaWrapperMethod(Consumer consumer) {
        return i -> {
            try {
                consumer.accept(i);
            } catch (ArithmeticException e) {
                System.err.println("Arithmetic Exception occured : " + e.getMessage());
            }
        };
    }
 
    public static void main(String[] ar) {
        List integers = Arrays.asList(3, 9, 7, 0, 10, 20);
       // integers.forEach(lambdaWrapperMethod(i -> System.out.println(50 /(int) i)));
        

Stream<String> names2 = Stream.of("aBc", "d", "ef", "amg");
List<String> reverseSorted = names2.filter(data->data.startsWith("a")).sorted(Comparator.reverseOrder()).collect(Collectors.toList());
System.out.println(reverseSorted); // [ef, d, aBc, 123456]

Stream<String> names3 = Stream.of("aBc", "d", "ef", "123456");
List<String> naturalSorted = names3.sorted().collect(Collectors.toList());
System.out.println(naturalSorted); //[123456, aBc, d, ef]



Stream<List<String>> namesOriginalList = Stream.of(
		Arrays.asList("Pankaj"), 
		Arrays.asList("David", "Lisa"),
		Arrays.asList("Amit"));
	//flat the stream from List<String> to String stream
	Stream<String> flatStream = namesOriginalList
		.flatMap(strList -> strList.stream());

	flatStream.forEach(System.out::println);

 
    }
 
}