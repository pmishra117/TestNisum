package com.java.core.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

public class WordReadingDemo {
public static void main(String[] args) {
	String data="Pradeep Dileep Dileep Arati Pradeep Pradeep Dileep Amar Dileep Pradeep Amar Pradeep Pradeep Dileep Amar Dileep Pradeep Amar Pradeep Dileep Pradeep Amar Dileep Pradeep Amar Pradeep Dileep Dileep Pradeep Amar Pradeep Dileep Dileep Pradeep Amar Rajesh Ravi Sanjay Praveen Sharma Ashana ,Nisha Preeti Pradeep Dileep Dileep Pradeep Amar Rajesh Ravi Sanjay Praveen Sharma Ashana ,Nisha Preeti Rajesh Ravi Sanjay Praveen Sharma Ashana ,Nisha Preeti Amar Rajesh Ravi Sanjay Praveen Sharma Ashana ,Nisha Preeti";
	countWords(data);
}

static void countWords(String data) {
	String[] dataN=data.split(" ");
	TreeSet<String> uniqueData=new TreeSet<String>();
	ArrayList<String>allData=new ArrayList<String>();
	for(int i=0;i<dataN.length;i++){
		uniqueData.add(dataN[i]);
		allData.add(dataN[i]);
	}
	
	Collections.sort(allData);
	
	Iterator<String> it=uniqueData.iterator();
		
	while(it.hasNext()){
		  int count=0;
			
	  String value=it.next();
	  Iterator<String> itr=allData.iterator();
	  while(itr.hasNext()){
		  String value1=itr.next();
		  if(value.equals(value1)) {
			  count++;
		  }
	  }
	  System.out.println(value +"  is "+count+" times....");
	  	 
	}
}
}
