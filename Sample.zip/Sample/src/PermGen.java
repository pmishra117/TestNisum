
public class PermGen {
public static void main(String[] args) {
	 System.out.println(reverseStringUsingRecursionSample("PradeeP"));
	  
}
public static String reverseStringUsingRecursionSample(String sampleStr)

{
String rightString = "";String leftString = "";

int len = sampleStr.length();

if (len <= 1) return sampleStr;

leftString = sampleStr.substring(0, len / 2);

rightString = sampleStr.substring(len / 2, len);

return reverseStringUsingRecursionSample(rightString) + reverseStringUsingRecursionSample(leftString);
}

}