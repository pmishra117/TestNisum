public class UrlShortener {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int    BASE     = ALPHABET.length();

    
    public static void main(String[] args) {
		System.out.println(encode(123412341));
		System.out.println(decode(encode(123412341)));
	}
    public static String encode(int num) {
        StringBuilder sb = new StringBuilder();
        while ( num > 0 ) {
        	int index=num % BASE;
            sb.append( ALPHABET.charAt( index ) );
            num /= BASE;
        }
        return sb.reverse().toString();   
    }

    public static int decode(String str) {
        int num = 0;
        for ( int i = 0; i < str.length(); i++ ) {
        //	System.out.println("BASE   "+BASE);
        	//System.out.println(" ALPHABET.indexOf(str.charAt(i)  "+ ALPHABET.indexOf(str.charAt(i)));
            num = num * BASE + ALPHABET.indexOf(str.charAt(i));
        }
        return num;
    }   
}