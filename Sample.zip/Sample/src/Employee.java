package test3;

import java.io.Serializable;

public class Employee implements Serializable{
	
	private int empid;
	
	private String empName;

	
	@Override
	public boolean equals(Object obj) {
		return false;
	}
	
	@Override
	public int hashCode() {
		return 11;
	}

}
