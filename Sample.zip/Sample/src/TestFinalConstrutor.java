
public class TestFinalConstrutor {
 TestFinalConstrutor() {
	 //static and final cannot be constructor
	
}
}
