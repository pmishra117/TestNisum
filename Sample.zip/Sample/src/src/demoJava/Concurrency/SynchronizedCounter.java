package demoJava.Concurrency;

 	public class SynchronizedCounter implements Runnable {
	    private int c = 0;
	    

	    public synchronized void increment() {
	        System.out.println(c++ +"..increment(); ");
	    }

	    public synchronized int decrement() {
	        System.out.println(c-- +"..decrement(); ");
	  	  
	        return c--;
	    }

	    public synchronized int value() {
	         return c;
	    }
	    
	    
	    public static void main(String[] args) {
	    	SynchronizedCounter synchronizedCounter=new SynchronizedCounter();
	       	Thread th1= new Thread(synchronizedCounter);
	    	Thread th2= new Thread(synchronizedCounter);
		      th1.start();
		      th2.start();
	  	}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i=1;i<11;i++){
				increment();
				decrement();
			}
			
		}
	}
 
