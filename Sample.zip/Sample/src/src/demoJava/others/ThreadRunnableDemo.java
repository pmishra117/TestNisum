  package com.demoJava.others;   
 	  class RunnableThread implements Runnable {
		 public void run() throws RuntimeException{
		  System.out.println("MyThread run called");
		  for(int i=0;i<=5;i++){
		   System.out.println(i);
		  }
		  throw new NullPointerException();
		 }
		}


		public class ThreadRunnableDemo {

		 public static void main(String args[]){
		  RunnableThread  runnableThread = new RunnableThread();
		  Thread thread = new Thread(runnableThread);
		  try{
		   thread.start();
		  }catch(Exception e){
		   System.out.println("caugth");
		   e.printStackTrace();
		  }
		  System.out.println("Runnable thread started");
		 }
		}
 
