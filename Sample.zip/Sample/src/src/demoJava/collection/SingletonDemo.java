package com.demoJava.collection;

public class SingletonDemo {
private static SingletonDemo uniqueObj;
// Private Constructor so that no instance can be created.
private SingletonDemo(){
}
public static SingletonDemo getInstance(){
     if(uniqueObj==null){
           uniqueObj = new SingletonDemo(); 
    }
         return uniqueObj;
    }
} 