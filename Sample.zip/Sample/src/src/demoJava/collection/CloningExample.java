package com.demoJava.collection;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


class ColoredCircle implements Serializable
{
    private int x;
    private int y;

    public ColoredCircle(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return x;
    }

    public void setX(int x){
        this.x = x;
    }

    public void setY(int y){
        this.y = y;
    }
    public int getY(){
        return y;
    }

     
}

	class Subject {

		  private String name;

		  public String getName() {
		    return name;
		  }

		  public void setName(String s) {
		    name = s;
		  }

		  public Subject(String s) {
		    name = s;
		  }
		}

		class Student implements Cloneable {
		  //Contained object
		  private Subject subj;

		  private String name;

		  public Subject getSubj() {
			return subj;
		  }

		  public String getName() {
			return name;
		  }

		  public void setName(String s) {
			name = s;
		  }

		  public Student(String s, String sub) {
			name = s;
			subj = new Subject(sub);
		  }

		  public Object clone() {
			//shallow copy
			try {
			  return super.clone();
			} catch (CloneNotSupportedException e) {
			  return null;
			}
		  }
		}

		public class CloningExample {

		  public static void main(String[] args) throws IOException {
			// shallow Copy Starts
			  //Original Object
			 /*
			Student stud = new Student("John", "Algebra");

			System.out.println("Original Object: " + stud.getName() + " - "
				+ stud.getSubj().getName());

			//Clone Object
			Student clonedStud = (Student) stud.clone();

			System.out.println("Cloned Object: " + clonedStud.getName() + " - "
				+ clonedStud.getSubj().getName());

			stud.setName("Dan");
			stud.getSubj().setName("Physics");

			System.out.println("Original Object after it is updated: " 
				+ stud.getName() + " - " + stud.getSubj().getName());

			System.out.println("Cloned Object after updating original object: "
				+ clonedStud.getName() + " - " + clonedStud.getSubj().getName());
  
			  */
			  
			  
			  
			  
			  
			  // DEEP Copy  Starts
			  ObjectOutputStream oos = null;
		        ObjectInputStream ois = null;

		        try
		        {
		            // create original serializable object
		            ColoredCircle c1 = new ColoredCircle(100,100);
		            // print it
		            System.out.println("Original = " + c1.getX());

		            ColoredCircle c2 = null;

		            // deep copy
		            ByteArrayOutputStream bos = new ByteArrayOutputStream(); 
		            oos = new ObjectOutputStream(bos); 
		            // serialize and pass the object
		            oos.writeObject(c1);   
		            oos.flush(); 
		            
		            
		      
		            ByteArrayInputStream bin = 
					        new ByteArrayInputStream(bos.toByteArray()); 
		            ois = new ObjectInputStream(bin);                  
		            // return the new object
		            c2 = (ColoredCircle) ois.readObject(); 

		            // verify it is the same
		            System.out.println("Copied   = " + c2.getX());
		        //    System.out.println("Copied   = " + c2.getY());
			          
		            // change the original object's contents
		            c1.setX(200);
		            c1.setY(200);
		            // see what is in each one now
		            System.out.println("Original = " + c1.getX());
		            System.out.println("Copied   = " + c2.getX());
		        }
		        catch(Exception e)
		        {
		            System.out.println("Exception in main = " +  e);
		        }
		        finally
		        {        
		            oos.close();
		            ois.close();
		        }
		    }
			  
		  }
		
 
