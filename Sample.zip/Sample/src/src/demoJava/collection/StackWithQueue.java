package com.demoJava.collection;

import java.util.LinkedList;

public class StackWithQueue<E> {
	LinkedList<E> queue1=new LinkedList<E>();
	LinkedList<E> queue2=new LinkedList<E>();
	
	public void push(E e){
		queue2.add(e);
		while(!queue1.isEmpty()){
			queue2.add(queue1.removeFirst());
		}
		while(!queue2.isEmpty()){
			queue1.add(queue2.removeFirst());
		}	
	}
	
	public E pop(){
		return queue1.removeFirst();
	}
	
	public static void main(String[] args){
		StackWithQueue<Integer> swq=new StackWithQueue<Integer>();
		
		swq.push(1);
		swq.push(2);
		swq.push(3);
		swq.push(4);
		
		
		System.out.println(swq.pop());
		System.out.println(swq.pop());
		System.out.println(swq.pop());
		System.out.println(swq.pop());		
	}
}
