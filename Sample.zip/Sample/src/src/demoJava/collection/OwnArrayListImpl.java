package demoJava.collection;

public class OwnArrayListImpl {
public static void main(String[] args) {
	String str="pradeep";
new OwnArrayListImpl().distict(str);
}

public void distict(String str) {
 for(int i=0;i<str.length();i++) {
		int count =0;

	 char c=str.charAt(i);
	 for(int j=0;j<str.length();j++) {
       if(c==str.charAt(j)) {
    	   count++;
    	   if(count<=1) {
    		   System.out.println("Distince chars are "+str.charAt(j));
    	   }
       }
	 }
	 }
 } 
}

