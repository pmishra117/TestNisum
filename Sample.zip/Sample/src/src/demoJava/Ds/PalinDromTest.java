package com.demoJava.Ds;

import java.util.Scanner;
import java.util.StringTokenizer;

public class PalinDromTest {
	 
	 
    public static void main(String args[]){
     
      ///  Scanner scanner = new Scanner(System.in);      
      //  int number = scanner.nextInt();
        isPalindrome(null);
                 
    }

    private static void isPalindrome(String s) {
    	         s="pradeep kumar pradeep";
    	      String repeated="";
    	     StringTokenizer st=new StringTokenizer(s," ");
    	     int c=0;
    	     while(st.hasMoreTokens()) {
    	    	 String str=st.nextToken();
    	    	String[] ss=s.split(" ");
    	        for(String word:ss) {
    	        	if(str.equalsIgnoreCase(word)){
    	        	c++;
    	        	if(c>1){
    	        		System.out.println("Repeted........."+str);
    	        		//break;
    	        	}
    	        	}
    	     }
    	     break;}
    	           }
    	  // return repeated;
    	  //  }
 
     
    private static int reverse(int number){
        int reverse = 0;
     
        while(number != 0){
          reverse = reverse*10 + number%10;
          number = number/10;
        }
             
        return reverse;
    }

}

 
 
