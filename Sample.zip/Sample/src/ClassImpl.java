
public class ClassImpl extends TestInExtend {
public static void main(String[] args) {
	new ClassImpl().c();
}
	 
	public void c() {
		System.out.println("hi");
		
	}

	 

}
