package util;

import java.sql.DriverManager;
import java.sql.SQLException;


public class TestConnection {
	public static   TestConnection testConnection;
	 static java.sql.Connection conn=null;
	 	 
public static java.sql.Connection getConnection() throws SQLException, ClassNotFoundException {
	
	 Class.forName("oracle.jdbc.driver.OracleDriver");
	   conn=  DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","system","H"
	   		+ "eaven#123");
 	return conn;
	 
}

public static void main(String[] args) {
	String str="name";
	String str1=new String("name");
	System.out.println(str==str1.intern());
			
			
}



}
