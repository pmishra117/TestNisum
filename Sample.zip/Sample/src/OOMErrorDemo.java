package javaXML;

import java.util.ArrayList;
import java.util.Stack;


public class OOMErrorDemo {
public static void main(String[] args) {
	Stack<String>al=new Stack<String>();
	int c=0;
	do {
		al.add("Hello Man!!!!");
		System.out.println(c);
		c++;
	} while(true);
}
}
