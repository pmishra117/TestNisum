import java.util.Arrays;

public class TestJava8 {
public static void main(String[] args) {
	int[] arr = {1,2,3};
	
	  sumExpectCurrent(arr);
	//int min=Arrays.stream(arr).boxed().mapToInt(i->i).sum();
	//System.out.println(min);
}
static void sumExpectCurrent(int [] a) {
   int[] res = new int[a.length];
    int x = 0;
    res[0] = 0;
    for (int i=1;i<a.length;i++){
        res[i]=res[i-1]+a[i-1];
        System.out.println("res[i]  "+res[i-1]+" a[i-1]  "+a[i-1]);
    }
    for (int i=a.length-1;i>0;i--){
        x += a[i];
        res[i-1]=x+res[i-1];
        System.out.println("res[i-1]  "+res[i-1]);
    }
    for (int i=0;i<res.length;i++){
        System.out.println("Sum of rest...." +res[i]);
    }
}
}