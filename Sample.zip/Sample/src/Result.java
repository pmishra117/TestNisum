import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;



class Result {

    /*
     * Complete the 'sortDates' function below.
     *
     * The function is expected to return a STRING_ARRAY.
     * The function accepts STRING_ARRAY dates as parameter.
     */

    public static List<String> sortDates(List<String> dates) {
        
    // Write your code here

   Collections.sort(dates, new Comparator<String>() {
       DateFormat format =new SimpleDateFormat("dd mmm yyyy");
       @Override
       public int compare(String s1,String s2) {
           try{
               return format.parse(s1).compareTo(format.parse(s2));
           }catch(ParseException e) {
               throw e;
           }
       }

   });
    return dates;
}
}

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int datesCount = Integer.parseInt(bufferedReader.readLine().trim());

        List<String> dates = new ArrayList<>();

        for (int i = 0; i < datesCount; i++) {
            String datesItem = bufferedReader.readLine();
            dates.add(datesItem);
        }

        List<String> result = Result.sortDates(dates);

        for (int i = 0; i < result.size(); i++) {
            bufferedWriter.write(result.get(i));

            if (i != result.size() - 1) {
                bufferedWriter.write("\n");
            }
        }

        bufferedWriter.newLine();

        bufferedReader.close();
        bufferedWriter.close();
    }
}
