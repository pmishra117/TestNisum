package com.java.core.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

class Employee implements Comparator<Employee>{
	private String id;
	private String fName;
	private String lName;
	private String salary;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	  
	public int compare(Employee o1, Employee o2) {
		 Employee p1 =   o1;
		 Employee p2 =   o2;
         int res =  p1.getfName().compareToIgnoreCase(p2.getfName());
         if (res != 0)
             return res;
         return p1.getlName().compareToIgnoreCase(p2.getlName());
     }
	}
public class ComparableImpl {
	public static void main(String[] args) {
	  ArrayList<Employee> listOfEmployee=new ArrayList<Employee>();
	  Employee  employee= new Employee();
	  Employee  employee1= new Employee();
	  
	 // employee.setfName("Pradeep");
	  //employee1.setfName("Pradeep");
	//  System.out.println(employee.equals(employee1));
	  employee.setfName("Pradeep");
	  employee1.setfName("Dilip");
	    
	  employee.setlName("Mishra");
	  employee1.setlName("Singh");
	  listOfEmployee.add(employee);
	  listOfEmployee.add(employee1);
	 Collections.sort(listOfEmployee,new Employee());
	// Collections.sort(al, new SizeComparator());
	  for(int i=0;i<listOfEmployee.size();i++){
		  System.out.println(listOfEmployee.get(i).getfName()+"  "+listOfEmployee.get(i).getlName());
	}
		
	}
	

}
