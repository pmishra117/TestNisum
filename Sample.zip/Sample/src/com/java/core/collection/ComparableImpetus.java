package com.java.core.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

class User implements Comparator<User>{
	private int id;
	private String status;
	private String month;
	
	public User(int id, String status, String month) {
		super();
		this.id = id;
		this.status = status;
		this.month = month;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	 
 
	  
	public int compare(User o1, User o2) {
		User p1 =   o1;
		User p2 =   o2;
         int res =  p1.getStatus().compareToIgnoreCase(p2.getStatus());
         if (res != 0)
             return res;
         return p1.getMonth().compareToIgnoreCase(p2.getMonth());
     }
	 
	}
public class ComparableImpetus {
	public static void main(String[] args) {
	  ArrayList<User> listOfEmployee=new ArrayList<User>();
	  User  employee= new User(1,"Active","JAN");
	  User  employee1= new User(2,"Active","Mar");
	  
	 // employee.setfName("Pradeep");
	  //employee1.setfName("Pradeep");
	//  System.out.println(employee.equals(employee1));
	   listOfEmployee.add(employee);
	  listOfEmployee.add(employee1);
	 //Collections.sort(listOfEmployee,new User());
	 // Collections.sort(al, new SizeComparator());
	  for(int i=0;i<listOfEmployee.size();i++){
		  System.out.println(listOfEmployee.get(i).getMonth()+"  "+listOfEmployee.get(i).getStatus());
	}
		
	}
	

}
