package com.demoJava.Ds;

public class SortingLt {
	public static void main(String[] args) {
		
	
    int[] arr = {2, 4, 6, 8, 2, 12, 14, 16};
    SortingLt.BruteForceSearch(arr,6);
	}
 

public static void BruteForceSearch(int A[],int K)
{
int i = 0, j = 0;
for (i = 0; i < A.length; i++)
{
for(j = i; j < A.length; j++)
{
if(A[i]+A[j] == K)
{
System.out.println("Items Found   "+A[i]+", "+A[j]);
return;
}
}
}
System.out.println("Items not found: No such elements");
}
}