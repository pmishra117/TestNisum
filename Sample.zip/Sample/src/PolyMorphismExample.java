
abstract class TestD {
	public abstract void add(int a,double d);  
	public abstract void add(int a,int b);

}

public class PolyMorphismExample extends TestD {
  public static void main(String[] args) {
	TestD d = new PolyMorphismExample();
	d.add(1, 2.5);
	d.add(1, 2);

}
	 	public void add(int a, int b) {
		System.out.println("Add Int");
		
	}

 	public void add(int a, double d) {
		System.out.println("Add double");
		
	}

}
