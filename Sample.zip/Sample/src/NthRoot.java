package geeks;

public class NthRoot {
public static void main(String[] args) {
	System.out.println(isNthRoot(4, 2));
}

private static double isNthRoot(int value, int n) {
    double a = Math.pow(value, 1.0 / n);
    //return Math.pow(Math.round(a), n) == value;
    
    return a;
    
}
}
