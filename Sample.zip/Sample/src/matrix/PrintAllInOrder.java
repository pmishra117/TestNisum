package geeks.matrix;

public class PrintAllInOrder {
public static void main(String[] args) {
	 int [][]mat = { {10, 20, 30, 40},
             {15, 25, 35, 45},
             {27, 29, 37, 48},
             {32, 33, 39, 50},
           };
System.out.println(search(mat, 39));

}

/* Searches the element x in mat[][]. If the element is found, 
    then prints its position and returns true, otherwise prints 
    "not found" and returns false */
public static boolean search(int[][] matrix, int target) {
	    int m=matrix.length-1;
	    int n=matrix[0].length-1;
	 
	    int i=m; 
	    int j=0;
	 
	    while(i>=0 && j<=n){
	        if(target < matrix[i][j]){
	            i--;
	        }else if(target > matrix[i][j]){
	            j++;
	        }else{
	            return true;
	        }
	    }
	 
	    return false;
	}
}
