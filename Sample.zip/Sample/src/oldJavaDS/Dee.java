package oldJavaDS;

import java.util.HashMap;
import java.util.Map;

class Base {
	
	  Base(){
		System.out.println("Static ..");
	}
}
abstract class   Baseb extends Base {
	 
	  protected abstract int add(int a,int b);
	  
}

public class Dee extends Baseb {
	public static void main(String[] args) {
		Map<String,String> map= new HashMap<String,String>();
		String str="Pradeep";
		String str1=new String("Pradeep");
		map.put(str,str);
		map.put(str1,str1);
		System.out.println(map.size());
		 Dee d=new Dee();
		
		 
	} 
	
	 public int add(int a,int b) {
		  return a+b;
	  }
}

 
