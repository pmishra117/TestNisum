
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class App1 {
	
	 

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		
		 String[] str1="Pradeep Kumar Mishra".split("");
		 String[] str2="Dileep Kumar".split("");
		for(int i=0;i<str1.length;i++) {
			map.put(str1[i],str1[i]);
		}

	}
}
