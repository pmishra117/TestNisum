package javaXML;
interface AA {
	int a=10;
}
public class TesTLength implements AA{
public static void main(String[] args) {
	findl("Pradeep");
	System.out.println(a);
	
	 int seed[] = {1, 100, 2, 105, -10, 30, 80};
     int maxDiff=Integer.MIN_VALUE, maxNumber = Integer.MIN_VALUE;

     for (int i = (seed.length-1); i >=0 ; i--){
         if(maxNumber < seed[i]) 
             maxNumber = seed[i];

         maxDiff = Math.max(maxDiff, (maxNumber - seed[i]));
     }
     System.out.println(maxDiff);
}

public static int findl(String g) {
	int j=0;
	try {
		for(int i=0;i>=0;i++) {
			char c=g.charAt(i);
			j++;
		}
	}catch(Exception e) {
		System.out.println("length is  " +j);
	}
	
	return 1;
}
}
