package com.demoJava.others;
import java.util.*;
import java.util.concurrent.*;

public class CallableDemo {

  public static class WordLengthCallable  implements Callable<Integer> {

	  private String word;
    
	  public WordLengthCallable(String word) {
      this.word = word;
    }
     
	  public Integer call() {
      return Integer.valueOf(word.length());
    }
  }
  
  public static class StringTask implements Callable<String> {
	   public String call(){
	      //Long operations
//System.out.println("gg");
	      return "Run";
	   }
	}

 	


  public static void main(String args[]) throws Exception {
	/*ExecutorService pool = Executors.newFixedThreadPool(1);
    Set<Future<Integer>> set = new HashSet<Future<Integer>>();
   // for (String word: args) {
      Callable<Integer> callable = new WordLengthCallable("wordjjjjjjjjjjjjjjjjjjdfffffffffffff");
      Future<Integer> future = pool.submit(callable);
      set.add(future);
    //}
    int sum = 0;
    for (Future<Integer> future1 : set) {
      sum += future1.get();
    }
    System.out.printf("The sum of lengths is %s%n", sum);
    System.exit(sum);*/
	  
	  
	  ExecutorService pool = Executors.newFixedThreadPool(4);

		for(int i = 0; i < 5; i++){
			Future<String> future =pool.submit(new StringTask());
		   System.out.println(future.get());
		}
  }
}
 
